import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
  memo,
} from 'react';
import {
  View,
  Text,
  FlatList,

  StyleSheet,
  Dimensions,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  ListRenderItemInfo,
} from 'react-native';
import { Image } from 'expo-image';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Settings, Grid3x3 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { fetchFullProfile, fetchUserPosts } from '@/services/api';
import { FollowButton } from '@/components/social';
import { AnimatedPressable, FadeIn, triggerHaptic } from '@/utils/interactions';
import { offlineCache } from '@/utils/offlineCache';

// ─── Constants ────────────────────────────────────────────────────────────────

const { width: SCREEN_W } = Dimensions.get('window');
const COLUMN_COUNT        = 3;
const GAP                 = 2;
const CELL_SIZE           = (SCREEN_W - GAP * (COLUMN_COUNT - 1)) / COLUMN_COUNT;
const PAGE_SIZE           = 24; // 8 rows of 3

// ─── Types ────────────────────────────────────────────────────────────────────

interface Profile {
  id:         string;
  username:   string;
  avatar_url: string | null;
  bio:        string | null;
}

interface PostThumb {
  id:        string;
  media_url: string;
}

// Pad posts to a multiple of COLUMN_COUNT so the last row fills cleanly
type GridItem = PostThumb | { id: string; placeholder: true };

type ProfileStatus = 'loading' | 'idle' | 'error';
type PostsStatus   = 'loading' | 'idle' | 'loadingMore' | 'error';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isVideo(url: string): boolean {
  return /\.(mp4|mov|webm|m4v)(\?|$)/i.test(url);
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function padToGrid(items: PostThumb[]): GridItem[] {
  const remainder = items.length % COLUMN_COUNT;
  if (remainder === 0) return items;
  const padding = COLUMN_COUNT - remainder;
  const pads: GridItem[] = Array.from({ length: padding }, (_, i) => ({
    id: `pad-${i}`,
    placeholder: true as const,
  }));
  return [...items, ...pads];
}

// ─── useProfile ───────────────────────────────────────────────────────────────

function useProfile(userId: string) {
  const [profile,   setProfile]   = useState<Profile | null>(null);
  const [status,    setStatus]    = useState<ProfileStatus>('loading');
  const [followers, setFollowers] = useState(0);
  const [following, setFollowing] = useState(0);
  const [postCount, setPostCount] = useState(0);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setStatus('loading');

    // Show cached profile instantly if available (including when offline)
    const cached = await offlineCache.getProfile<any>(userId, true);
    if (cached) {
      setProfile({ id: cached.data.id, username: cached.data.username, avatar_url: cached.data.avatar_url, bio: cached.data.bio });
      setFollowers(cached.data.followers);
      setFollowing(cached.data.following);
      setPostCount(cached.data.postCount);
      if (cached.stale) setStatus('idle'); // show stale data, fetch fresh below
      else { setStatus('idle'); return; }  // fresh — no need to refetch
    }

    const meId = (await supabase.auth.getUser()).data.user?.id ?? null;
    setCurrentUserId(meId);

    const { data, error } = await fetchFullProfile(userId);

    if (error) {
      if (!cached) setStatus('error'); // only show error if no cached data
      return;
    }

    // Cache the fresh profile
    await offlineCache.setProfile(userId, data);

    setProfile({ id: data.id, username: data.username, avatar_url: data.avatar_url, bio: data.bio });
    setFollowers(data.followers);
    setFollowing(data.following);
    setPostCount(data.postCount);
    setStatus('idle');
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  const isOwnProfile = currentUserId === userId;
  return { profile, status, followers, following, postCount, isOwnProfile, reload: load };
}

// ─── usePosts ─────────────────────────────────────────────────────────────────

function usePosts(userId: string) {
  const [posts,   setPosts]   = useState<PostThumb[]>([]);
  const [status,  setStatus]  = useState<PostsStatus>('loading');
  const [hasMore, setHasMore] = useState(true);

  // Cursor: created_at of the oldest post loaded (exclusive upper bound for next page)
  const cursorRef   = useRef<string | null>(null);
  const fetchingRef = useRef(false);

  const fetchPage = useCallback(async (reset = false) => {
    if (fetchingRef.current) return;
    fetchingRef.current = true;
    setStatus(reset ? 'loading' : 'loadingMore');

    if (reset) {
      cursorRef.current = null;
      setHasMore(true);
    }

    const { data, error } = await fetchUserPosts(userId, cursorRef.current);

    if (error) { setStatus('error'); fetchingRef.current = false; return; }

    // Advance cursor to the oldest post in this page
    if (data.nextCursor) cursorRef.current = data.nextCursor;
    if (!data.hasMore)   setHasMore(false);

    setPosts(prev => reset ? data.posts : [...prev, ...data.posts]);
    setStatus('idle');
    fetchingRef.current = false;
  }, [userId]);

  const loadMore = useCallback(() => {
    if (hasMore && !fetchingRef.current) fetchPage(false);
  }, [hasMore, fetchPage]);

  const refresh = useCallback(() => fetchPage(true), [fetchPage]);

  useEffect(() => { fetchPage(true); }, [fetchPage]);

  return { posts, status, hasMore, loadMore, refresh };
}

// ─── ProfileHeader — rendered as FlatList ListHeaderComponent ─────────────────

interface ProfileHeaderProps {
  profile:      Profile;
  followers:    number;
  following:    number;
  postCount:    number;
  isOwnProfile: boolean;
  onSettings:   () => void;
}

const ProfileHeader = memo(({
  profile, followers, following, postCount,
  isOwnProfile, onSettings,
}: ProfileHeaderProps) => (
  <FadeIn duration={350} fromY={10}>
    <View style={styles.header}>
    {/* Top bar */}
    <View style={styles.topBar}>
      <Text style={styles.topBarUsername}>@{profile.username}</Text>
      {isOwnProfile && (
        <TouchableOpacity onPress={onSettings} hitSlop={12} activeOpacity={0.7}>
          <Settings size={22} color="#1A1A1A" />
        </TouchableOpacity>
      )}
    </View>

    {/* Avatar + stats row */}
    <View style={styles.avatarStatsRow}>
      {/* Avatar */}
      {profile.avatar_url ? (
        <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
      ) : (
        <View style={[styles.avatar, styles.avatarFallback]}>
          <Text style={styles.avatarInitial}>
            {profile.username?.[0]?.toUpperCase() ?? '?'}
          </Text>
        </View>
      )}

      {/* Stat pills */}
      <View style={styles.statsRow}>
        <StatPill label="Posts"     value={formatCount(postCount)} />
        <StatPill label="Followers" value={formatCount(followers)} />
        <StatPill label="Following" value={formatCount(following)} />
      </View>
    </View>

    {/* Bio */}
    {!!profile.bio && (
      <Text style={styles.bio} numberOfLines={3}>{profile.bio}</Text>
    )}

    {/* CTA button */}
    {isOwnProfile ? (
      <AnimatedPressable style={styles.editBtn} onPress={() => triggerHaptic('light')} haptic={null} pressedScale={0.97}>
        <Text style={styles.editBtnText}>Edit Profile</Text>
      </AnimatedPressable>
    ) : (
      <FollowButton
        targetUserId={profile.id}
        variant="default"
        style={styles.followBtnWrapper}
      />
    )}

    {/* Grid icon divider */}
    <View style={styles.tabRow}>
      <View style={[styles.tab, styles.tabActive]}>
        <Grid3x3 size={20} color="#1A1A1A" />
      </View>
    </View>
  </View>
  </FadeIn>
));

const StatPill = memo(({ label, value }: { label: string; value: string }) => (
  <View style={styles.statPill}>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
));

// ─── GridCell ─────────────────────────────────────────────────────────────────

interface GridCellProps {
  item:    GridItem;
  onPress: (id: string) => void;
}

const GridCell = memo(({ item, onPress }: GridCellProps) => {
  if ('placeholder' in item) {
    return <View style={styles.cell} />;
  }

  const video = isVideo(item.media_url);

  return (
    <TouchableOpacity
      style={styles.cell}
      onPress={() => onPress(item.id)}
      activeOpacity={0.85}
    >
      <Image
        source={{ uri: item.media_url }}
        style={StyleSheet.absoluteFill}
        resizeMode="cover"
      />
      {video && (
        <View style={styles.videoIndicator}>
          <Text style={styles.videoIndicatorText}>▶</Text>
        </View>
      )}
    </TouchableOpacity>
  );
});

// ─── SocialProfileScreen ──────────────────────────────────────────────────────

export default function SocialProfileScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ userId: string }>();

  // Fall back to the signed-in user if no userId param passed (own profile tab)
  const [resolvedId, setResolvedId] = useState<string | null>(params.userId ?? null);

  useEffect(() => {
    if (!resolvedId) {
      supabase.auth.getUser().then(({ data }) => {
        if (data.user?.id) setResolvedId(data.user.id);
      });
    }
  }, [resolvedId]);

  if (!resolvedId) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#1A1A1A" />
      </View>
    );
  }

  return <ProfileContent userId={resolvedId} router={router} />;
}

// ─── ProfileContent — separated so hooks only run after userId is resolved ────

function ProfileContent({ userId, router }: { userId: string; router: ReturnType<typeof useRouter> }) {
  const {
    profile, status: profileStatus,
    followers, following, postCount,
    isOwnProfile, reload: reloadProfile,
  } = useProfile(userId);

  const {
    posts, status: postsStatus,
    hasMore, loadMore, refresh: refreshPosts,
  } = usePosts(userId);

  const onRefresh = useCallback(async () => {
    await Promise.all([reloadProfile(), refreshPosts()]);
  }, [reloadProfile, refreshPosts]);

  const onPostPress = useCallback((id: string) => {
    router.push(`/post/${id}` as any);
  }, [router]);

  // ── Render ─────────────────────────────────────────────────────────────────

  if (profileStatus === 'loading') {
    return (
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.center}><ActivityIndicator color="#1A1A1A" size="large" /></View>
      </SafeAreaView>
    );
  }

  if (profileStatus === 'error' || !profile) {
    return (
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.center}>
          <Text style={styles.errorText}>Failed to load profile.</Text>
          <TouchableOpacity onPress={reloadProfile} style={styles.retryBtn}>
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const gridItems = padToGrid(posts);

  const renderItem = ({ item }: ListRenderItemInfo<GridItem>) => (
    <GridCell item={item} onPress={onPostPress} />
  );

  const keyExtractor = (item: GridItem) => item.id;

  const ListHeader = (
    <ProfileHeader
      profile={profile}
      followers={followers}
      following={following}
      postCount={postCount}
      isOwnProfile={isOwnProfile}
      onSettings={() => router.push('/settings' as any)}
    />
  );

  const ListFooter = postsStatus === 'loadingMore' ? (
    <View style={styles.footer}><ActivityIndicator color="#999" size="small" /></View>
  ) : !hasMore && posts.length > 0 ? (
    <View style={styles.footer}><Text style={styles.endText}>All posts loaded</Text></View>
  ) : null;

  const ListEmpty = postsStatus === 'idle' ? (
    <View style={styles.emptyState}>
      <Text style={styles.emptyEmoji}>📷</Text>
      <Text style={styles.emptyTitle}>No posts yet</Text>
      <Text style={styles.emptySubtext}>
        {isOwnProfile ? 'Share your first post to get started.' : "This user hasn't posted yet."}
      </Text>
    </View>
  ) : postsStatus === 'loading' ? (
    <View style={styles.emptyState}><ActivityIndicator color="#999" /></View>
  ) : null;

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <FlatList
        data={gridItems}
        keyExtractor={keyExtractor}
        renderItem={renderItem}
        numColumns={COLUMN_COUNT}
        columnWrapperStyle={styles.row}
        ListHeaderComponent={ListHeader}
        ListFooterComponent={ListFooter}
        ListEmptyComponent={ListEmpty}
        onEndReached={loadMore}
        onEndReachedThreshold={0.4}
        refreshControl={
          <RefreshControl
            refreshing={postsStatus === 'loading' && posts.length > 0}
            onRefresh={onRefresh}
            tintColor="#1A1A1A"
          />
        }
        showsVerticalScrollIndicator={false}
        // Performance
        removeClippedSubviews
        maxToRenderPerBatch={12}
        windowSize={7}
        initialNumToRender={12}
        getItemLayout={(_, index) => ({
          length: CELL_SIZE,
          offset: CELL_SIZE * Math.floor(index / COLUMN_COUNT),
          index,
        })}
      />
    </SafeAreaView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  center:   { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },

  // Header
  header:        { backgroundColor: '#fff', paddingBottom: 4 },
  topBar:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  topBarUsername:{ fontSize: 17, fontWeight: '700', color: '#1A1A1A' },

  avatarStatsRow:{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, gap: 24, marginBottom: 12 },
  avatar:        { width: 86, height: 86, borderRadius: 43, borderWidth: 2, borderColor: '#E5E5E5' },
  avatarFallback:{ backgroundColor: '#F0F0F0', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontSize: 30, fontWeight: '700', color: '#555' },

  statsRow:  { flex: 1, flexDirection: 'row', justifyContent: 'space-around' },
  statPill:  { alignItems: 'center', gap: 2 },
  statValue: { fontSize: 18, fontWeight: '700', color: '#1A1A1A' },
  statLabel: { fontSize: 12, color: '#888', fontWeight: '500' },

  bio: { paddingHorizontal: 16, fontSize: 14, color: '#333', lineHeight: 20, marginBottom: 12 },

  // Buttons
  editBtn:         { marginHorizontal: 16, marginBottom: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1.5, borderColor: '#DBDBDB', alignItems: 'center' },
  editBtnText:     { fontSize: 14, fontWeight: '600', color: '#1A1A1A' },
  followBtnWrapper:  { marginHorizontal: 16, marginBottom: 12 },

  // Tab row
  tabRow:   { flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#F0F0F0', marginTop: 4 },
  tab:      { flex: 1, paddingVertical: 10, alignItems: 'center' },
  tabActive:{ borderTopWidth: 2, borderTopColor: '#1A1A1A' },

  // Grid
  row:  { gap: GAP, marginBottom: GAP },
  cell: { width: CELL_SIZE, height: CELL_SIZE, backgroundColor: '#F5F5F5', overflow: 'hidden' },

  // Video indicator badge
  videoIndicator:     { position: 'absolute', top: 6, right: 6, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  videoIndicatorText: { color: '#fff', fontSize: 10, fontWeight: '700' },

  // Footer / empty
  footer:      { paddingVertical: 20, alignItems: 'center' },
  endText:     { color: '#bbb', fontSize: 12 },
  emptyState:  { paddingVertical: 60, alignItems: 'center', gap: 10 },
  emptyEmoji:  { fontSize: 40 },
  emptyTitle:  { fontSize: 18, fontWeight: '700', color: '#1A1A1A' },
  emptySubtext:{ fontSize: 14, color: '#888', textAlign: 'center', paddingHorizontal: 40 },

  // Error
  errorText: { fontSize: 15, color: '#555', textAlign: 'center' },
  retryBtn:  { backgroundColor: '#1A1A1A', paddingHorizontal: 24, paddingVertical: 10, borderRadius: 24 },
  retryText: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
