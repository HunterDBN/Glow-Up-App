import React, {
  useState,
  useRef,
  useCallback,
  memo,
  useEffect,
} from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Dimensions,
  ActivityIndicator,
  TouchableOpacity,
  StatusBar,
  RefreshControl,
  ViewToken,
} from 'react-native';
import Animated from 'react-native-reanimated';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Heart, MessageCircle, Share2, BookmarkPlus } from 'lucide-react-native';
import { useFeedStore, useLikesStore, useCommentsStore, FeedPost, FeedStatus } from '@/store';
import { FeedImage, FeedVideo, CommentsSheet } from '@/components/feed';
import {
  useBounce,
  useSpringPress,
  useCounterAnimation,
  AnimatedPressable,
  FadeIn,
  triggerHaptic,
} from '@/utils/interactions';

// ─── Constants ────────────────────────────────────────────────────────────────

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isVideo(url: string): boolean {
  return /\.(mp4|mov|webm|m4v)(\?|$)/i.test(url);
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

// ─── LikeButton — reads from likesStore; only re-renders when this post changes

interface LikeButtonProps {
  postId: string;
}

const LikeButton = memo(({ postId }: LikeButtonProps) => {
  const liked   = useLikesStore(s => s.isLiked(postId));
  const count   = useLikesStore(s => s.getCount(postId));
  const toggle  = useLikesStore(s => s.toggle);
  const [busy, setBusy] = useState(false);

  const { animatedStyle: bounceStyle, bounce } = useBounce({ peakScale: 1.35, haptic: liked ? 'light' : 'medium' });
  const counterStyle = useCounterAnimation(count);

  const handlePress = useCallback(async () => {
    if (busy) return;
    bounce();
    setBusy(true);
    await toggle(postId);
    setBusy(false);
  }, [busy, bounce, toggle, postId]);

  return (
    <TouchableOpacity
      style={styles.actionBtn}
      onPress={handlePress}
      activeOpacity={0.8}
      disabled={busy}
    >
      <Animated.View style={bounceStyle}>
        <Heart
          size={30}
          color={liked ? '#FF3B5C' : '#fff'}
          fill={liked ? '#FF3B5C' : 'transparent'}
          strokeWidth={liked ? 0 : 1.8}
        />
      </Animated.View>
      <Animated.Text style={[styles.actionLabel, liked && styles.actionLabelLiked, counterStyle]}>
        {count > 0 ? formatCount(count) : 'Like'}
      </Animated.Text>
    </TouchableOpacity>
  );
});

// ─── MediaItem — delegates to FeedImage or FeedVideo ─────────────────────────

interface MediaItemProps {
  post:      FeedPost;
  isVisible: boolean;
  index:     number;
}

const MediaItem = memo(({ post, isVisible, index }: MediaItemProps) => {
  if (isVideo(post.media_url)) {
    return (
      <FeedVideo
        uri={post.media_url}
        isVisible={isVisible}
        index={index}
        thumbnailUri={null}  // set to post.thumbnail_url if you store it
        blurhash={null}      // set to post.blurhash if you store it
      />
    );
  }
  return (
    <FeedImage
      uri={post.media_url}
      index={index}
      blurhash={null}  // set to post.blurhash if you store it
      lqip={null}      // set to post.lqip if you store it
    />
  );
});
// ─── PostCard ─────────────────────────────────────────────────────────────────

interface PostCardProps {
  post:      FeedPost;
  isVisible: boolean;
  index:     number;
}

const PostCard = memo(({ post, isVisible, index }: PostCardProps) => {
  const insets            = useSafeAreaInsets();
  const [saved, setSaved] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const commentCount = useCommentsStore(s => s.getCount(post.id));

  return (
    <View style={[styles.card, { height: SCREEN_H }]}>
      <MediaItem post={post} isVisible={isVisible} index={index} />
      <View style={styles.scrim} pointerEvents="none" />

      {/* Right-side action rail */}
      <View style={[styles.actions, { bottom: insets.bottom + 88 }]}>
        {/* Avatar — uses expo-image for caching */}
        <View style={styles.avatarWrapper}>
          {post.profiles.avatar_url ? (
            <Image
              source={{ uri: post.profiles.avatar_url }}
              style={styles.avatar}
              contentFit="cover"
              cachePolicy="memory-disk"
              transition={{ duration: 200 }}
            />
          ) : (
            <View style={[styles.avatar, styles.avatarFallback]}>
              <Text style={styles.avatarInitial}>
                {post.profiles.username?.[0]?.toUpperCase() ?? '?'}
              </Text>
            </View>
          )}
          <View style={styles.followBadge}>
            <Text style={styles.followPlus}>+</Text>
          </View>
        </View>

        {/* Like — isolated component; only it re-renders on like state changes */}
        <LikeButton
          postId={post.id}
          initialLiked={post.user_liked}
          initialCount={post.like_count}
        />

        <ActionButton icon={<MessageCircle size={28} color="#fff" />} label={commentCount > 0 ? String(commentCount) : 'Reply'} onPress={() => setShowComments(true)} />
        <ActionButton
          icon={<BookmarkPlus size={28} color={saved ? '#FFD700' : '#fff'} />}
          label="Save"
          onPress={() => setSaved(p => !p)}
        />
        <ActionButton icon={<Share2 size={28} color="#fff" />} label="Share" onPress={() => {}} />
      </View>

      {/* Username + caption — fade in on mount */}
      <FadeIn delay={100} fromY={6} style={[styles.meta, { bottom: insets.bottom + 88 }]}>
        <Text style={styles.username}>@{post.profiles.username}</Text>
        {!!post.caption && (
          <Text style={styles.caption} numberOfLines={2}>{post.caption}</Text>
        )}
      </FadeIn>

      {/* Comments sheet — mounts inside the card so it overlays only this post */}
      {showComments && (
        <CommentsSheet
          postId={post.id}
          visible={showComments}
          onClose={() => setShowComments(false)}
        />
      )}
    </View>
  );
});

// ─── ActionButton — spring-scale on press with haptic ────────────────────────

interface ActionButtonProps {
  icon:    React.ReactNode;
  label:   string;
  onPress: () => void;
}

const ActionButton = memo(({ icon, label, onPress }: ActionButtonProps) => (
  <AnimatedPressable style={styles.actionBtn} onPress={onPress} haptic="light" pressedScale={0.88}>
    {icon}
    {!!label && <Text style={styles.actionLabel}>{label}</Text>}
  </AnimatedPressable>
));

// ─── ListFooter ───────────────────────────────────────────────────────────────

const ListFooter = memo(({ status, hasMore }: { status: FeedStatus; hasMore: boolean }) => {
  if (status === 'loadingMore') {
    return (
      <View style={styles.footer}>
        <ActivityIndicator color="#fff" size="small" />
      </View>
    );
  }
  if (!hasMore) {
    return (
      <View style={styles.footer}>
        <View style={styles.endDivider} />
        <Text style={styles.endText}>You're all caught up</Text>
        <View style={styles.endDivider} />
      </View>
    );
  }
  return null;
});

const FullScreenSpinner = () => (
  <View style={styles.center}>
    <ActivityIndicator color="#fff" size="large" />
    <Text style={styles.loadingText}>Loading feed…</Text>
  </View>
);

const ErrorScreen = memo(({ message, onRetry }: { message: string; onRetry: () => void }) => (
  <View style={styles.center}>
    <Text style={styles.errorEmoji}>⚠️</Text>
    <Text style={styles.errorText}>{message}</Text>
    <TouchableOpacity onPress={onRetry} style={styles.retryBtn} activeOpacity={0.8}>
      <Text style={styles.retryText}>Try again</Text>
    </TouchableOpacity>
  </View>
));

// ─── FeedScreen ───────────────────────────────────────────────────────────────

export default function FeedScreen() {
  const { posts, status, hasMore, error, fromCache, loadMore, refresh, retry } = usePosts();
  const [visibleId, setVisibleId] = useState<string | null>(null);

  const onViewableItemsChanged = useCallback(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      const top = viewableItems.find(v => v.isViewable);
      setVisibleId(top?.item?.id ?? null);
    },
    [],
  );

  const viewabilityConfig = useRef({
    itemVisiblePercentThreshold: 75,  // 75% of card must be visible
    minimumViewTime: 150,             // must stay visible 150ms — prevents flicker during fast scroll
  }).current;

  const renderItem = useCallback(
    ({ item, index }: { item: FeedPost; index: number }) => (
      <PostCard post={item} isVisible={item.id === visibleId} index={index} />
    ),
    [visibleId],
  );

  const keyExtractor = useCallback((item: FeedPost) => item.id, []);

  if (status === 'loading') return <FullScreenSpinner />;
  if (status === 'error' && posts.length === 0) {
    return <ErrorScreen message={error!} onRetry={retry} />;
  }

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* Subtle badge shown while fresh data loads over cached content */}
      {fromCache && (
        <View style={styles.cacheBadge} pointerEvents="none">
          <ActivityIndicator color="rgba(255,255,255,0.7)" size="small" />
          <Text style={styles.cacheBadgeText}>Updating…</Text>
        </View>
      )}

      <FlatList
        data={posts}
        keyExtractor={keyExtractor}
        renderItem={renderItem}
        pagingEnabled
        snapToInterval={SCREEN_H}
        snapToAlignment="start"
        decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
        onEndReached={loadMore}
        onEndReachedThreshold={0.5}
        ListFooterComponent={<ListFooter status={status} hasMore={hasMore} />}
        refreshControl={
          <RefreshControl
            refreshing={status === 'refreshing'}
            onRefresh={refresh}
            tintColor="#fff"
            colors={['#fff']}
            progressBackgroundColor="#111"
          />
        }
        removeClippedSubviews
        maxToRenderPerBatch={3}
        windowSize={5}
        initialNumToRender={2}
        getItemLayout={(_, index) => ({
          length: SCREEN_H,
          offset: SCREEN_H * index,
          index,
        })}
      />
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root:   { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center', gap: 14 },

  // Cache badge — shown top-right while background refresh runs
  cacheBadge: {
    position:        'absolute',
    top:             52,
    right:           14,
    zIndex:          10,
    flexDirection:   'row',
    alignItems:      'center',
    gap:             5,
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingVertical:   4,
    paddingHorizontal: 10,
    borderRadius:    20,
  },
  cacheBadgeText: {
    color:      'rgba(255,255,255,0.7)',
    fontSize:   11,
    fontWeight: '500',
  },

  card:  { width: SCREEN_W, backgroundColor: '#111', overflow: 'hidden' },
  scrim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'transparent',
    borderBottomWidth: SCREEN_H * 0.45,
    borderBottomColor: 'rgba(0,0,0,0.55)',
    borderTopWidth:    SCREEN_H * 0.55,
    borderTopColor:    'transparent',
  },

  actions:       { position: 'absolute', right: 12, alignItems: 'center', gap: 20 },
  avatarWrapper: { position: 'relative', marginBottom: 4 },
  avatar:        { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: '#fff' },
  avatarFallback:{ backgroundColor: '#333', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { color: '#fff', fontWeight: '700', fontSize: 18 },
  followBadge:   {
    position: 'absolute', bottom: -8, alignSelf: 'center',
    backgroundColor: '#FF3B5C', width: 20, height: 20, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  followPlus:    { color: '#fff', fontSize: 14, fontWeight: '700', lineHeight: 18 },

  actionBtn:        { alignItems: 'center', gap: 4 },
  actionLabel:      { color: '#fff', fontSize: 12, fontWeight: '600' },
  actionLabelLiked: { color: '#FF3B5C' },

  meta:     { position: 'absolute', left: 16, right: 80, gap: 6 },
  username: {
    color: '#fff', fontWeight: '700', fontSize: 15,
    textShadowColor: 'rgba(0,0,0,0.6)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4,
  },
  caption:  {
    color: 'rgba(255,255,255,0.9)', fontSize: 14, lineHeight: 20,
    textShadowColor: 'rgba(0,0,0,0.5)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3,
  },

  footer:     { height: SCREEN_H * 0.12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 10 },
  endDivider: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.15)', maxWidth: 60 },
  endText:    { color: 'rgba(255,255,255,0.4)', fontSize: 12, fontWeight: '500', letterSpacing: 0.4 },

  loadingText: { color: 'rgba(255,255,255,0.5)', fontSize: 13, marginTop: 8 },
  errorEmoji:  { fontSize: 36 },
  errorText:   { color: 'rgba(255,255,255,0.8)', fontSize: 15, textAlign: 'center', paddingHorizontal: 32, lineHeight: 22 },
  retryBtn:    { marginTop: 4, backgroundColor: '#fff', paddingHorizontal: 28, paddingVertical: 11, borderRadius: 28 },
  retryText:   { color: '#000', fontWeight: '700', fontSize: 14 },
});
