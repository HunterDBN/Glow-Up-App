import { describe, test, expect } from "bun:test";
import { api, expectStatus } from "./helpers";

describe("API Integration Tests", () => {
  let productId: string;
  let trackingId: string;
  let upsertTrackingId: string;
  let alertId: string;
  let trendId: string;
  let trendId2: string;
  let templateId: string;
  let savedItemId: string;
  let postId: string;
  let commentId: string;
  let challengeId: string;
  let userId: string;
  const testDeviceId = crypto.randomUUID();

  // Tracked Products - Validation tests
  test("Create tracked product with missing name", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        platform: "shopee",
        currentPrice: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create tracked product with missing platform", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Test Product",
        currentPrice: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create tracked product with missing currentPrice", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Test Product",
        platform: "shopee",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create tracked product with invalid platform enum", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Test Product",
        platform: "invalid_platform",
        currentPrice: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  // Tracked Products - CRUD flow
  test("Create a tracked product", async () => {
    const uniqueId = crypto.randomUUID().substring(0, 8);
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Laptop Computer",
        platform: "shopee",
        currentPrice: 5999999,
        targetPrice: 4999999,
        currency: "IDR",
        url: `https://shopee.co.id/laptop-${uniqueId}`,
        imageUrl: "https://example.com/laptop.jpg",
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.id).toBeDefined();
    expect(data.name).toBe("Laptop Computer");
    expect(data.platform).toBe("shopee");
    productId = data.id;
  });

  test("List all tracked products", async () => {
    const res = await api("/api/tracked-products");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.products).toBeDefined();
    expect(Array.isArray(data.products)).toBe(true);
  });

  test("Get price history for a tracked product", async () => {
    const res = await api(`/api/tracked-products/${productId}/history`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.history).toBeDefined();
    expect(Array.isArray(data.history)).toBe(true);
  });

  // Tracked Products - Check price tests
  test("Check price for a tracked product", async () => {
    const res = await api(`/api/tracked-products/${productId}/check`, {
      method: "POST",
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.product).toBeDefined();
    expect(data.price_changed).toBeDefined();
    expect(typeof data.price_changed).toBe("boolean");
    expect(data.new_price).toBeDefined();
  });

  test("Check price for non-existent product", async () => {
    const res = await api("/api/tracked-products/00000000-0000-0000-0000-000000000000/check", {
      method: "POST",
    });
    await expectStatus(res, 404);
  });

  test("Check price with invalid UUID format", async () => {
    const res = await api("/api/tracked-products/invalid-id/check", {
      method: "POST",
    });
    await expectStatus(res, 400);
  });

  // Tracked Products - Record view tests
  test("Record a product view for a tracked product", async () => {
    const res = await api(`/api/tracked-products/${productId}/view`, {
      method: "POST",
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.success).toBe(true);
  });

  test("Record a product view for non-existent product", async () => {
    const res = await api("/api/tracked-products/00000000-0000-0000-0000-000000000000/view", {
      method: "POST",
    });
    await expectStatus(res, 404);
  });

  test("Record a product view with invalid UUID format", async () => {
    const res = await api("/api/tracked-products/invalid-id/view", {
      method: "POST",
    });
    await expectStatus(res, 400);
  });

  // Tracked Products - Update (PATCH) tests
  test("Update tracked product target_price", async () => {
    const res = await api(`/api/tracked-products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_price: 3999999,
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.id).toBe(productId);
    expect(data.targetPrice).toBeDefined();
  });

  test("Update tracked product in_stock flag", async () => {
    const res = await api(`/api/tracked-products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        in_stock: false,
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.id).toBe(productId);
    expect(data.inStock).toBe(false);
  });

  test("Update tracked product with multiple fields", async () => {
    const res = await api(`/api/tracked-products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_price: 4500000,
        in_stock: true,
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.id).toBe(productId);
    expect(data.inStock).toBe(true);
  });

  test("Update tracked product target_price to null", async () => {
    const res = await api(`/api/tracked-products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_price: null,
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.id).toBe(productId);
  });

  test("Update non-existent product", async () => {
    const res = await api("/api/tracked-products/00000000-0000-0000-0000-000000000000", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_price: 1000000,
      }),
    });
    await expectStatus(res, 404);
  });

  test("Update product with invalid UUID format", async () => {
    const res = await api("/api/tracked-products/invalid-id", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target_price: 1000000,
      }),
    });
    await expectStatus(res, 400);
  });

  // Tracked Products - Error cases
  test("Get price history with invalid UUID format", async () => {
    const res = await api("/api/tracked-products/not-a-uuid/history");
    await expectStatus(res, 400);
  });

  test("Get price history for non-existent product", async () => {
    const res = await api("/api/tracked-products/00000000-0000-0000-0000-000000000000/history");
    await expectStatus(res, 404);
  });

  test("Delete a tracked product", async () => {
    // Create a product to delete
    const createRes = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Product to Delete",
        platform: "lazada",
        currentPrice: 199999,
      }),
    });
    await expectStatus(createRes, 201);
    const createData = await createRes.json();
    const idToDelete = createData.id;

    // Delete it
    const deleteRes = await api(`/api/tracked-products/${idToDelete}`, {
      method: "DELETE",
    });
    await expectStatus(deleteRes, 200);
    const deleteData = await deleteRes.json();
    expect(deleteData.success).toBe(true);

    // Verify it's actually deleted by checking history (should return 404)
    const historyRes = await api(`/api/tracked-products/${idToDelete}/history`);
    await expectStatus(historyRes, 404);
  });

  test("Delete non-existent product", async () => {
    const res = await api("/api/tracked-products/00000000-0000-0000-0000-000000000000", {
      method: "DELETE",
    });
    await expectStatus(res, 404);
  });

  test("Delete with invalid UUID format", async () => {
    const res = await api("/api/tracked-products/invalid-id", {
      method: "DELETE",
    });
    await expectStatus(res, 400);
  });

  test("Create product with all optional fields", async () => {
    const uniqueId = crypto.randomUUID().substring(0, 8);
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Gaming Mouse",
        platform: "tokopedia",
        currentPrice: 299999,
        targetPrice: 249999,
        currency: "IDR",
        url: `https://tokopedia.com/mouse-${uniqueId}`,
        imageUrl: "https://example.com/mouse.jpg",
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.id).toBeDefined();
    expect(data.name).toBe("Gaming Mouse");
    expect(data.platform).toBe("tokopedia");
  });

  test("Create product with tiktok_shop platform", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Wireless Keyboard",
        platform: "tiktok_shop",
        currentPrice: 349999,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.platform).toBe("tiktok_shop");
  });

  test("Create product with manual platform", async () => {
    const res = await api("/api/tracked-products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Manual Product",
        platform: "manual",
        currentPrice: 199999,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.platform).toBe("manual");
  });

  // Products (Alternative Endpoint) - Validation tests
  test("Create product with missing product_name", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        platform: "shopee",
        price: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create product with missing platform", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Test Product",
        price: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create product with missing price", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Test Product",
        platform: "lazada",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Create product with invalid platform enum", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Test Product",
        platform: "invalid_platform",
        price: 99.99,
      }),
    });
    await expectStatus(res, 400);
  });

  // Products - CRUD flow
  test("Create a product", async () => {
    const uniqueId = crypto.randomUUID().substring(0, 8);
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Test Headphones",
        platform: "shopee",
        price: 299999,
        product_url: `https://shopee.co.id/headphones-${uniqueId}`,
        image_url: "https://example.com/headphones.jpg",
        store_name: "Test Store",
        notes: "Good quality headphones",
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.tracking_id).toBeDefined();
    expect(data.product_name).toBe("Test Headphones");
    expect(data.platform).toBe("shopee");
    expect(data.price).toBe(299999);
    trackingId = data.tracking_id;
  });

  test("List all products", async () => {
    const res = await api("/api/products");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.products).toBeDefined();
    expect(Array.isArray(data.products)).toBe(true);
  });

  test("Get product with price history", async () => {
    const res = await api(`/api/products/${trackingId}`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.tracking_id).toBe(trackingId);
    expect(data.product_name).toBe("Test Headphones");
    expect(data.price).toBeDefined();
    expect(data.price_history).toBeDefined();
    expect(Array.isArray(data.price_history)).toBe(true);
  });

  test("Update product price", async () => {
    const res = await api(`/api/products/${trackingId}/price`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        price: 249999,
        note: "Price dropped",
      }),
    });
    await expectStatus(res, 200);
  });

  test("Update product price without note", async () => {
    const res = await api(`/api/products/${trackingId}/price`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        price: 239999,
      }),
    });
    await expectStatus(res, 200);
  });

  test("Update product price with missing price field", async () => {
    const res = await api(`/api/products/${trackingId}/price`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        note: "Some note",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Update price for non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id/price", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        price: 100,
      }),
    });
    await expectStatus(res, 404);
  });

  test("Append note to product", async () => {
    const res = await api(`/api/products/${trackingId}/notes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        note: "This is a test note",
      }),
    });
    await expectStatus(res, 200);
  });

  test("Append note with missing note field", async () => {
    const res = await api(`/api/products/${trackingId}/notes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    await expectStatus(res, 400);
  });

  test("Append note to non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id/notes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        note: "Test note",
      }),
    });
    await expectStatus(res, 404);
  });

  test("Get price history for a product", async () => {
    const res = await api(`/api/products/${trackingId}/history`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.history).toBeDefined();
    expect(Array.isArray(data.history)).toBe(true);
  });

  test("Get history for non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id/history");
    await expectStatus(res, 404);
  });

  test("Get price comparisons for a product", async () => {
    const res = await api(`/api/products/${trackingId}/compare`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.comparisons).toBeDefined();
    expect(Array.isArray(data.comparisons)).toBe(true);
    expect(typeof data.cached).toBe("boolean");
  });

  test("Get price comparisons for non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id/compare");
    await expectStatus(res, 404);
  });

  test("Refresh product metadata", async () => {
    const res = await api(`/api/products/${trackingId}/refresh`, {
      method: "POST",
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.message).toBeDefined();
    expect(data.product).toBeDefined();
  });

  test("Refresh metadata for non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id/refresh", {
      method: "POST",
    });
    await expectStatus(res, 404);
  });

  test("Delete a product", async () => {
    const deleteRes = await api(`/api/products/${trackingId}`, {
      method: "DELETE",
    });
    await expectStatus(deleteRes, 200);
    const data = await deleteRes.json();
    expect(data.success).toBe(true);

    // Verify it's deleted by trying to get it
    const getRes = await api(`/api/products/${trackingId}`);
    await expectStatus(getRes, 404);
  });

  test("Delete non-existent product", async () => {
    const res = await api("/api/products/nonexistent-id", {
      method: "DELETE",
    });
    await expectStatus(res, 404);
  });

  test("Create product with all optional fields", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Keyboard",
        platform: "lazada",
        price: 150000,
        product_url: "https://lazada.co.id/keyboard",
        image_url: "https://example.com/keyboard.jpg",
        store_name: "Electronics Store",
        notes: "RGB keyboard",
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.product_name).toBe("Keyboard");
    expect(data.platform).toBe("lazada");
  });

  test("Create product with minimal fields only", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Simple Product",
        platform: "tiktok_shop",
        price: 99999,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.tracking_id).toBeDefined();
    expect(data.product_name).toBe("Simple Product");
  });

  test("Create product with other platform", async () => {
    const res = await api("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Other Platform Product",
        platform: "other",
        price: 50000,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.platform).toBe("other");
  });

  // Products - Upsert (create or update by URL)
  test("Upsert product - create new product", async () => {
    const uniqueUrl = `https://shopee.co.id/upsert-test-${crypto.randomUUID().substring(0, 8)}`;
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: uniqueUrl,
        product_name: "Upsert Test Product",
        platform: "shopee",
        price: 199999,
        image_url: "https://example.com/upsert.jpg",
        store_name: "Upsert Store",
        notes: "Test note",
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.created).toBe(true);
    expect(data.product).toBeDefined();
    expect(data.product.product_name).toBe("Upsert Test Product");
    expect(data.product.product_url).toBe(uniqueUrl);
    upsertTrackingId = data.product.tracking_id;
  });

  test("Upsert product - update existing product", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: "https://lazada.co.id/upsert-update-test",
        product_name: "Updated Product",
        platform: "lazada",
        price: 275000,
      }),
    });
    await expectStatus(res, 200, 201);
  });

  test("Upsert product with missing product_url", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_name: "Test",
        platform: "shopee",
        price: 100,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Upsert product with missing product_name", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: "https://shopee.co.id/test",
        platform: "shopee",
        price: 100,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Upsert product with missing platform", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: "https://shopee.co.id/test",
        product_name: "Test",
        price: 100,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Upsert product with missing price", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: "https://shopee.co.id/test",
        product_name: "Test",
        platform: "shopee",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Upsert product with invalid platform", async () => {
    const res = await api("/api/products/upsert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_url: "https://invalid.com/test",
        product_name: "Test",
        platform: "invalid_platform",
        price: 100,
      }),
    });
    await expectStatus(res, 400);
  });

  // Alerts - List
  test("List all alerts", async () => {
    const res = await api("/api/alerts");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.alerts).toBeDefined();
    expect(Array.isArray(data.alerts)).toBe(true);
    expect(typeof data.unread_count).toBe("number");

    // Capture first alert ID for later tests
    if (data.alerts.length > 0) {
      alertId = data.alerts[0].id;
    }
  });

  // Alerts - Mark as read
  test("Mark an existing alert as read", async () => {
    if (alertId) {
      const res = await api(`/api/alerts/${alertId}/read`, {
        method: "POST",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    }
  });

  test("Mark non-existent alert as read", async () => {
    const res = await api("/api/alerts/00000000-0000-0000-0000-000000000000/read", {
      method: "POST",
    });
    await expectStatus(res, 404);
  });

  test("Mark alert as read with invalid UUID format", async () => {
    const res = await api("/api/alerts/invalid-uuid/read", {
      method: "POST",
    });
    await expectStatus(res, 400);
  });

  // Profile - Get stats
  test("Get user profile statistics", async () => {
    const res = await api("/api/profile/stats");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.total_tracked).toBeDefined();
    expect(data.total_alerts).toBeDefined();
    expect(data.unread_alerts).toBeDefined();
    expect(data.total_savings).toBeDefined();
    expect(data.platforms_used).toBeDefined();
  });

  // Scraper - Scrape URL
  test("Scrape product information from supported URL", async () => {
    const res = await api("/api/scrape-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: "https://shopee.co.id/laptop",
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.name).toBeDefined();
    expect(data.current_price).toBeDefined();
    expect(data.platform).toBeDefined();
    expect(data.currency).toBeDefined();
    expect(typeof data.in_stock).toBe("boolean");
  });

  test("Scrape with missing URL", async () => {
    const res = await api("/api/scrape-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    await expectStatus(res, 400);
  });

  test("Scrape from unsupported platform", async () => {
    const res = await api("/api/scrape-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: "https://unsupported-platform.com/product",
      }),
    });
    await expectStatus(res, 422);
    const data = await res.json();
    expect(data.error).toBeDefined();
  });

  // Trending - Get trending products
  test("Get trending products", async () => {
    const res = await api("/api/trending");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trending).toBeDefined();
    expect(Array.isArray(data.trending)).toBe(true);
  });

  // Hot Drops - Get products with biggest price drops
  test("Get hot drops with default parameters", async () => {
    const res = await api("/api/hot-drops");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.hot_drops).toBeDefined();
    expect(Array.isArray(data.hot_drops)).toBe(true);
    expect(data.count).toBeDefined();
    expect(typeof data.count).toBe("number");
    expect(data.min_drop_pct).toBeDefined();
    expect(typeof data.min_drop_pct).toBe("number");
  });

  test("Get hot drops with min_drop parameter", async () => {
    const res = await api("/api/hot-drops?min_drop=10");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.hot_drops).toBeDefined();
    expect(Array.isArray(data.hot_drops)).toBe(true);
    expect(data.min_drop_pct).toBeDefined();
  });

  test("Get hot drops with limit parameter", async () => {
    const res = await api("/api/hot-drops?limit=5");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.hot_drops).toBeDefined();
    expect(Array.isArray(data.hot_drops)).toBe(true);
    expect(data.count).toBeDefined();
  });

  test("Get hot drops with both parameters", async () => {
    const res = await api("/api/hot-drops?min_drop=15&limit=10");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.hot_drops).toBeDefined();
    expect(Array.isArray(data.hot_drops)).toBe(true);
    expect(data.count).toBeDefined();
    expect(data.min_drop_pct).toBeDefined();
  });

  // Meta - Extract metadata from URL
  test("Extract metadata from supported URL", async () => {
    const res = await api("/api/meta?url=https://shopee.co.id/test-product");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.platform).toBeDefined();
  });

  test("Get metadata without URL parameter", async () => {
    const res = await api("/api/meta");
    await expectStatus(res, 400);
  });

  test("Get metadata with empty URL parameter", async () => {
    const res = await api("/api/meta?url=");
    await expectStatus(res, 400);
  });

  // Meta - Extract metadata via OpenGraph.io
  test("Extract metadata via OpenGraph from supported URL", async () => {
    const res = await api("/api/meta/opengraph?url=https://shopee.co.id/test-product");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data).toBeDefined();
  });

  test("Get OpenGraph metadata without URL parameter", async () => {
    const res = await api("/api/meta/opengraph");
    await expectStatus(res, 400);
  });

  test("Get OpenGraph metadata with empty URL parameter", async () => {
    const res = await api("/api/meta/opengraph?url=");
    await expectStatus(res, 400);
  });

  // TrendJack - Trends
  test("List all trends", async () => {
    const res = await api("/api/tj/trends");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trends).toBeDefined();
    expect(Array.isArray(data.trends)).toBe(true);
    if (data.trends.length > 0) {
      trendId = data.trends[0].id;
    }
    if (data.trends.length > 1) {
      trendId2 = data.trends[1].id;
    }
  });

  test("List trends with niche filter", async () => {
    const res = await api("/api/tj/trends?niche=fashion");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trends).toBeDefined();
    expect(Array.isArray(data.trends)).toBe(true);
  });

  test("List trends with platform filter", async () => {
    const res = await api("/api/tj/trends?platform=shopee");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trends).toBeDefined();
    expect(Array.isArray(data.trends)).toBe(true);
  });

  test("List trends with search filter", async () => {
    const res = await api("/api/tj/trends?search=product");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trends).toBeDefined();
    expect(Array.isArray(data.trends)).toBe(true);
  });

  test("List trends with multiple filters", async () => {
    const res = await api("/api/tj/trends?niche=fashion&platform=shopee&search=dress");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.trends).toBeDefined();
    expect(Array.isArray(data.trends)).toBe(true);
  });

  // TrendJack - Get trend with templates
  test("Get trend with templates", async () => {
    if (trendId) {
      const res = await api(`/api/tj/trends/${trendId}`);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.trend).toBeDefined();
      expect(data.templates).toBeDefined();
      expect(Array.isArray(data.templates)).toBe(true);
      if (data.templates && data.templates.length > 0) {
        templateId = data.templates[0].id;
      }
    }
  });

  test("Get non-existent trend", async () => {
    const res = await api("/api/tj/trends/nonexistent-trend-id");
    await expectStatus(res, 404);
  });

  // TrendJack - Saved items
  test("Get saved items for a device", async () => {
    const res = await api(`/api/tj/saved?device_id=${testDeviceId}`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.saved).toBeDefined();
    expect(Array.isArray(data.saved)).toBe(true);
  });

  test("Get saved items without device_id", async () => {
    const res = await api("/api/tj/saved");
    await expectStatus(res, 400);
  });

  test("Save a trend", async () => {
    if (!trendId) {
      console.warn("Skipping Save a trend test - no trendId available");
      return;
    }
    const res = await api("/api/tj/saved", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
        trend_id: trendId,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.saved_item).toBeDefined();
    if (data.saved_item && data.saved_item.id) {
      savedItemId = data.saved_item.id;
    }
  });

  test("Save a trend with template", async () => {
    if (!trendId2) {
      console.warn("Skipping Save a trend with template test - no second trendId available");
      return;
    }
    const res = await api("/api/tj/saved", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
        trend_id: trendId2,
        template_id: templateId || null,
      }),
    });
    await expectStatus(res, 201);
    const data = await res.json();
    expect(data.saved_item).toBeDefined();
  });

  test("Save without device_id", async () => {
    const res = await api("/api/tj/saved", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        trend_id: "test-trend-id",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Save without trend_id", async () => {
    const res = await api("/api/tj/saved", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
      }),
    });
    await expectStatus(res, 400);
  });

  test("Delete a saved item", async () => {
    if (savedItemId) {
      const res = await api(`/api/tj/saved/${savedItemId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          device_id: testDeviceId,
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    }
  });

  test("Delete non-existent saved item", async () => {
    const res = await api("/api/tj/saved/nonexistent-saved-id", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
      }),
    });
    await expectStatus(res, 404);
  });

  // TrendJack - Profile
  test("Get user profile for a device", async () => {
    const res = await api(`/api/tj/profile?device_id=${testDeviceId}`);
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.user).toBeDefined();
  });

  test("Get profile without device_id", async () => {
    const res = await api("/api/tj/profile");
    await expectStatus(res, 400);
  });

  test("Update user profile", async () => {
    const res = await api("/api/tj/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
        name: "Test User",
        selected_niches: "fashion,electronics",
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.user).toBeDefined();
  });

  test("Update profile without device_id", async () => {
    const res = await api("/api/tj/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "Test User",
      }),
    });
    await expectStatus(res, 400);
  });

  test("Update profile with only device_id", async () => {
    const uniqueDeviceId = crypto.randomUUID();
    const res = await api("/api/tj/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: uniqueDeviceId,
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.user).toBeDefined();
  });

  test("Update profile with selected_niches only", async () => {
    const res = await api("/api/tj/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: testDeviceId,
        selected_niches: "beauty,fitness",
      }),
    });
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.user).toBeDefined();
  });

  // GlowUp - Profile
  test("Get current user profile", async () => {
    const res = await api("/api/gu/profile");
    // May return 200 or 401 depending on authentication
    await expectStatus(res, 200, 401);
  });

  test("Update user profile (GlowUp)", async () => {
    const res = await api("/api/gu/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: "testuser",
        bio: "Test bio",
      }),
    });
    // May return 200 or 401 depending on authentication
    await expectStatus(res, 200, 401);
  });

  test("Get public user profile", async () => {
    const res = await api("/api/gu/profile/test-user-id");
    // May return 200 or 404
    await expectStatus(res, 200, 404);
  });

  // GlowUp - Posts
  test("List posts", async () => {
    const res = await api("/api/gu/posts");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.posts).toBeDefined();
    expect(Array.isArray(data.posts)).toBe(true);
    if (data.posts.length > 0) {
      postId = data.posts[0].id;
    }
  });

  test("List posts with category filter", async () => {
    const res = await api("/api/gu/posts?category=skincare");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.posts).toBeDefined();
    expect(Array.isArray(data.posts)).toBe(true);
  });

  test("List posts with search filter", async () => {
    const res = await api("/api/gu/posts?search=beauty");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.posts).toBeDefined();
    expect(Array.isArray(data.posts)).toBe(true);
  });

  test("Create post", async () => {
    const res = await api("/api/gu/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: "My first beauty tip!",
        category: "skincare",
        image_url: "https://example.com/image.jpg",
      }),
    });
    // May return 201 or 401 depending on authentication
    await expectStatus(res, 201, 401);
    if (res.status === 201) {
      const data = await res.json();
      expect(data.post).toBeDefined();
      postId = data.post.id;
    }
  });

  test("Create post with missing content", async () => {
    const res = await api("/api/gu/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        category: "skincare",
      }),
    });
    // May return 400 or 401
    await expectStatus(res, 400, 401);
  });

  test("Create post with missing category", async () => {
    const res = await api("/api/gu/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: "Test content",
      }),
    });
    // May return 400 or 401
    await expectStatus(res, 400, 401);
  });

  test("Get single post with comments", async () => {
    if (postId) {
      const res = await api(`/api/gu/posts/${postId}`);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.post).toBeDefined();
      expect(data.comments).toBeDefined();
      expect(Array.isArray(data.comments)).toBe(true);
    }
  });

  test("Get non-existent post", async () => {
    const res = await api("/api/gu/posts/00000000-0000-0000-0000-000000000002");
    await expectStatus(res, 404);
  });

  test("Delete post", async () => {
    // Create a post to delete
    const createRes = await api("/api/gu/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: "Post to delete",
        category: "skincare",
      }),
    });

    if (createRes.status === 201) {
      const createData = await createRes.json();
      const postToDeleteId = createData.post.id;

      // Delete it
      const deleteRes = await api(`/api/gu/posts/${postToDeleteId}`, {
        method: "DELETE",
      });
      await expectStatus(deleteRes, 200, 401);
    }
  });

  test("Delete non-existent post", async () => {
    const res = await api("/api/gu/posts/00000000-0000-0000-0000-000000000003", {
      method: "DELETE",
    });
    // May return 404 or 401
    await expectStatus(res, 404, 401);
  });

  test("Get posts by user", async () => {
    const res = await api("/api/gu/posts/user/test-user-id");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.posts).toBeDefined();
    expect(Array.isArray(data.posts)).toBe(true);
  });

  // GlowUp - Likes
  test("Toggle like on post", async () => {
    if (postId) {
      const res = await api(`/api/gu/posts/${postId}/like`, {
        method: "POST",
      });
      // May return 200 or 401
      await expectStatus(res, 200, 401);
      if (res.status === 200) {
        const data = await res.json();
        expect(data.liked).toBeDefined();
        expect(typeof data.liked).toBe("boolean");
        expect(data.likes_count).toBeDefined();
      }
    }
  });

  // GlowUp - Comments
  test("Create comment on post", async () => {
    if (postId) {
      const res = await api(`/api/gu/posts/${postId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          comment_text: "Great tip!",
        }),
      });
      // May return 201 or 401
      await expectStatus(res, 201, 401);
      if (res.status === 201) {
        const data = await res.json();
        expect(data.comment).toBeDefined();
        commentId = data.comment.id;
      }
    }
  });

  test("Create comment with missing text", async () => {
    if (postId) {
      const res = await api(`/api/gu/posts/${postId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      // May return 400 or 401
      await expectStatus(res, 400, 401);
    }
  });

  test("Delete comment", async () => {
    if (commentId) {
      const res = await api(`/api/gu/comments/${commentId}`, {
        method: "DELETE",
      });
      // May return 200 or 401
      await expectStatus(res, 200, 401);
    }
  });

  test("Delete non-existent comment", async () => {
    const res = await api("/api/gu/comments/00000000-0000-0000-0000-000000000004", {
      method: "DELETE",
    });
    // May return 404 or 401
    await expectStatus(res, 404, 401);
  });

  // GlowUp - Saved posts
  test("Toggle save post", async () => {
    if (postId) {
      const res = await api(`/api/gu/posts/${postId}/save`, {
        method: "POST",
      });
      // May return 200 or 401
      await expectStatus(res, 200, 401);
      if (res.status === 200) {
        const data = await res.json();
        expect(data.saved).toBeDefined();
        expect(typeof data.saved).toBe("boolean");
      }
    }
  });

  test("Get saved posts", async () => {
    const res = await api("/api/gu/saved");
    // May return 200 or 401
    await expectStatus(res, 200, 401);
    if (res.status === 200) {
      const data = await res.json();
      expect(data.posts).toBeDefined();
      expect(Array.isArray(data.posts)).toBe(true);
    }
  });

  // GlowUp - Challenges
  test("List challenges", async () => {
    const res = await api("/api/gu/challenges");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.challenges).toBeDefined();
    expect(Array.isArray(data.challenges)).toBe(true);
    if (data.challenges.length > 0) {
      challengeId = data.challenges[0].id;
    }
  });

  test("List challenges with category filter", async () => {
    const res = await api("/api/gu/challenges?category=fitness");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.challenges).toBeDefined();
    expect(Array.isArray(data.challenges)).toBe(true);
  });

  test("Get challenges user has joined", async () => {
    const res = await api("/api/gu/challenges/joined");
    // May return 200 or 401
    await expectStatus(res, 200, 401);
    if (res.status === 200) {
      const data = await res.json();
      expect(data.challenges).toBeDefined();
      expect(Array.isArray(data.challenges)).toBe(true);
    }
  });

  test("Log challenge entry", async () => {
    if (challengeId) {
      const res = await api(`/api/gu/challenges/${challengeId}/log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          day_number: 1,
          note: "Completed day 1",
        }),
      });
      // May return 201 or 401
      await expectStatus(res, 201, 401);
    }
  });

  test("Log challenge entry with missing day_number", async () => {
    if (challengeId) {
      const res = await api(`/api/gu/challenges/${challengeId}/log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          note: "Some note",
        }),
      });
      // May return 400 or 401
      await expectStatus(res, 400, 401);
    }
  });

  test("Get challenge entries for user", async () => {
    if (challengeId) {
      const res = await api(`/api/gu/challenges/${challengeId}/entries`);
      // May return 200 or 401
      await expectStatus(res, 200, 401);
      if (res.status === 200) {
        const data = await res.json();
        expect(data.entries).toBeDefined();
        expect(Array.isArray(data.entries)).toBe(true);
      }
    }
  });

  // GlowUp - Journal
  test("Get journal prompt", async () => {
    const res = await api("/api/gu/journal/prompt");
    await expectStatus(res, 200);
    const data = await res.json();
    expect(data.prompt).toBeDefined();
    expect(typeof data.prompt).toBe("string");
  });

  test("Create journal entry", async () => {
    const res = await api("/api/gu/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: "How are you feeling today?",
        response: "I'm feeling great!",
        mood: "happy",
      }),
    });
    // May return 201 or 401
    await expectStatus(res, 201, 401);
  });

  test("Create journal entry with missing prompt", async () => {
    const res = await api("/api/gu/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        response: "Test response",
        mood: "happy",
      }),
    });
    // May return 400 or 401
    await expectStatus(res, 400, 401);
  });

  test("Create journal entry with missing response", async () => {
    const res = await api("/api/gu/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: "Test prompt",
        mood: "happy",
      }),
    });
    // May return 400 or 401
    await expectStatus(res, 400, 401);
  });

  test("Create journal entry with missing mood", async () => {
    const res = await api("/api/gu/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: "Test prompt",
        response: "Test response",
      }),
    });
    // May return 400 or 401
    await expectStatus(res, 400, 401);
  });

  test("Get journal entries", async () => {
    const res = await api("/api/gu/journal");
    // May return 200 or 401
    await expectStatus(res, 200, 401);
    if (res.status === 200) {
      const data = await res.json();
      expect(data.entries).toBeDefined();
      expect(Array.isArray(data.entries)).toBe(true);
    }
  });
});
