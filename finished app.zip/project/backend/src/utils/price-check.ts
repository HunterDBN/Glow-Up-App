import type { App } from '../index.js';
import * as schema from '../db/schema/schema.js';
import { eq, lt, isNull, or, and, lte, isNotNull } from 'drizzle-orm';
import { sql } from 'drizzle-orm';
import { normalizeShopeeUrl } from './url-normalizer.js';
import { fetchShopeeProductWithRetry, getShopeeInfo } from './shopee-api.js';

export function hashUrl(url: string): number {
  let hash = 0;
  for (let i = 0; i < url.length; i++) {
    hash = ((hash * 31 + url.charCodeAt(i)) >>> 0);
  }
  return hash >>> 0;
}

function hashProductId(id: string): number {
  let seed = 0;
  for (let i = 0; i < id.length; i++) {
    seed = ((seed * 31 + id.charCodeAt(i)) >>> 0);
  }
  return seed >>> 0;
}

export async function runPriceCheck(app: App): Promise<void> {
  try {
    app.logger.info('Starting price check cycle');

    // Select products that need checking:
    // - url is not null and not empty
    // - last_checked_at is NULL, OR last_checked_at is older than check_interval_minutes ago
    // - fetch_error_count < 5
    // - For products with errors, apply exponential backoff: only select if last_checked_at is older than check_interval_minutes * fetch_error_count minutes ago
    const productsToCheck = await app.db
      .select()
      .from(schema.trackedProducts)
      .where(
        and(
          isNotNull(schema.trackedProducts.url),
          lte(schema.trackedProducts.fetchErrorCount, 4),
          or(
            isNull(schema.trackedProducts.lastCheckedAt),
            sql`${schema.trackedProducts.lastCheckedAt} < now() - (${schema.trackedProducts.checkIntervalMinutes}::int * (1 + ${schema.trackedProducts.fetchErrorCount}::int)) * INTERVAL '1 minute'`
          )
        )
      )
      .orderBy(schema.trackedProducts.lastCheckedAt)
      .limit(20);

    app.logger.info({ count: productsToCheck.length }, 'Products to check');

    let updatedCount = 0;
    let errorCount = 0;

    const currentHour = new Date().getHours();

    for (const product of productsToCheck) {
      // Normalize Shopee URLs if needed
      if (product.platform === 'shopee' && product.url) {
        const canonicalUrl = normalizeShopeeUrl(product.url);
        if (canonicalUrl && canonicalUrl !== product.url) {
          app.logger.info(
            { productId: product.id, originalUrl: product.url, canonicalUrl },
            'Normalizing Shopee URL'
          );
          // Update the product URL in the database
          await app.db
            .update(schema.trackedProducts)
            .set({ url: canonicalUrl })
            .where(eq(schema.trackedProducts.id, product.id));
          // Update local reference for use in this cycle
          product.url = canonicalUrl;
        }
      }

      try {
        const oldPrice = parseFloat(product.currentPrice);
        const oldInStock = product.inStock;

        let newPrice = oldPrice;
        let newInStock = oldInStock;

        // For Shopee products, fetch real data from the API
        if (product.platform === 'shopee' && product.url) {
          try {
            const shopeeInfo = getShopeeInfo(product.url);
            if (shopeeInfo.shopid && shopeeInfo.itemid) {
              const shopeeData = await fetchShopeeProductWithRetry(
                shopeeInfo.shopid,
                shopeeInfo.itemid,
                shopeeInfo.tld
              );
              newPrice = shopeeData.price;
              newInStock = shopeeData.in_stock;
            }
          } catch (apiError) {
            // If Shopee API fails, fall back to simulation
            app.logger.warn(
              { productId: product.id, err: apiError },
              'Shopee API failed, using simulated price change'
            );
            // Use deterministic simulation as fallback
            const seed = hashProductId(product.id);
            const hourSeed = (seed ^ (currentHour * 2654435761)) >>> 0;
            const rand = ((hourSeed >>> 0) % 1000) / 1000;

            const now = new Date();
            const createdAt = new Date(product.createdAt);
            const ageMs = now.getTime() - createdAt.getTime();
            const oneDayMs = 24 * 60 * 60 * 1000;
            const isOlderThanOneDay = ageMs > oneDayMs;

            if (isOlderThanOneDay) {
              if (rand < 0.45) {
                // No change
              } else if (rand < 0.70) {
                const dropPct = 0.005 + ((rand - 0.45) / 0.25) * 0.025;
                newPrice = oldPrice * (1 - dropPct);
              } else if (rand < 0.85) {
                const dropPct = 0.03 + ((rand - 0.70) / 0.15) * 0.05;
                newPrice = oldPrice * (1 - dropPct);
              } else if (rand < 0.95) {
                const risePct = 0.005 + ((rand - 0.85) / 0.10) * 0.015;
                newPrice = oldPrice * (1 + risePct);
              } else {
                newInStock = !oldInStock;
              }
            } else {
              if (rand < 0.60) {
                // No change
              } else if (rand < 0.80) {
                const dropPct = 0.005 + ((rand - 0.60) / 0.20) * 0.025;
                newPrice = oldPrice * (1 - dropPct);
              } else if (rand < 0.90) {
                const dropPct = 0.03 + ((rand - 0.80) / 0.10) * 0.05;
                newPrice = oldPrice * (1 - dropPct);
              } else if (rand < 0.97) {
                const risePct = 0.005 + ((rand - 0.90) / 0.07) * 0.015;
                newPrice = oldPrice * (1 + risePct);
              } else {
                newInStock = !oldInStock;
              }
            }
          }
        } else {
          // For non-Shopee products, use deterministic simulation
          const seed = hashProductId(product.id);
          const hourSeed = (seed ^ (currentHour * 2654435761)) >>> 0;
          const rand = ((hourSeed >>> 0) % 1000) / 1000;

          const now = new Date();
          const createdAt = new Date(product.createdAt);
          const ageMs = now.getTime() - createdAt.getTime();
          const oneDayMs = 24 * 60 * 60 * 1000;
          const isOlderThanOneDay = ageMs > oneDayMs;

          if (isOlderThanOneDay) {
            if (rand < 0.45) {
              // No change
            } else if (rand < 0.70) {
              const dropPct = 0.005 + ((rand - 0.45) / 0.25) * 0.025;
              newPrice = oldPrice * (1 - dropPct);
            } else if (rand < 0.85) {
              const dropPct = 0.03 + ((rand - 0.70) / 0.15) * 0.05;
              newPrice = oldPrice * (1 - dropPct);
            } else if (rand < 0.95) {
              const risePct = 0.005 + ((rand - 0.85) / 0.10) * 0.015;
              newPrice = oldPrice * (1 + risePct);
            } else {
              newInStock = !oldInStock;
            }
          } else {
            if (rand < 0.60) {
              // No change
            } else if (rand < 0.80) {
              const dropPct = 0.005 + ((rand - 0.60) / 0.20) * 0.025;
              newPrice = oldPrice * (1 - dropPct);
            } else if (rand < 0.90) {
              const dropPct = 0.03 + ((rand - 0.80) / 0.10) * 0.05;
              newPrice = oldPrice * (1 - dropPct);
            } else if (rand < 0.97) {
              const risePct = 0.005 + ((rand - 0.90) / 0.07) * 0.015;
              newPrice = oldPrice * (1 + risePct);
            } else {
              newInStock = !oldInStock;
            }
          }
        }

        // Round to 2 decimal places
        newPrice = Math.round(newPrice * 100) / 100;

        const priceChanged = Math.abs(newPrice - oldPrice) > 0.001;
        const stockChanged = newInStock !== oldInStock;

        if (priceChanged || stockChanged) {
          // Update product
          await app.db
            .update(schema.trackedProducts)
            .set({
              currentPrice: newPrice.toString(),
              inStock: newInStock,
              lastCheckedAt: sql`now()`,
              fetchErrorCount: 0,
              lastFetchError: null,
            })
            .where(eq(schema.trackedProducts.id, product.id));

          // Insert price history
          if (priceChanged) {
            await app.db.insert(schema.priceHistory).values({
              trackedProductId: product.id,
              price: newPrice.toString(),
              recordedAt: sql`now()`,
            });
          }

          // Generate alerts
          if (priceChanged && newPrice < oldPrice) {
            const savings = oldPrice - newPrice;
            const dropPct = ((oldPrice - newPrice) / oldPrice) * 100;

            // Check if target price is hit
            if (
              product.targetPrice &&
              newPrice <= parseFloat(product.targetPrice)
            ) {
              await app.db.insert(schema.alerts).values({
                trackedProductId: product.id,
                type: 'price_drop',
                message: `${product.name} hit your target price! Now ${product.currency} ${newPrice.toFixed(2)}`,
                oldPrice: oldPrice.toString(),
                newPrice: newPrice.toString(),
                savings: savings.toString(),
                isRead: false,
              });
            }

            // Also alert if price dropped by ≥5%
            if (dropPct >= 5) {
              await app.db.insert(schema.alerts).values({
                trackedProductId: product.id,
                type: 'price_drop',
                message: `${product.name} dropped by ${dropPct.toFixed(1)}%! Now ${product.currency} ${newPrice.toFixed(2)}`,
                oldPrice: oldPrice.toString(),
                newPrice: newPrice.toString(),
                savings: savings.toString(),
                isRead: false,
              });
            }
          }

          if (stockChanged && newInStock && !oldInStock) {
            await app.db.insert(schema.alerts).values({
              trackedProductId: product.id,
              type: 'restock',
              message: `${product.name} is back in stock!`,
              oldPrice: null,
              newPrice: null,
              savings: null,
              isRead: false,
            });
          }

          updatedCount++;
        } else {
          // No change, just update last_checked_at and reset error count
          await app.db
            .update(schema.trackedProducts)
            .set({
              lastCheckedAt: sql`now()`,
              fetchErrorCount: 0,
              lastFetchError: null,
            })
            .where(eq(schema.trackedProducts.id, product.id));
        }
      } catch (error) {
        // On failure: increment error count, set error message, update last_checked_at
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        app.logger.warn(
          { productId: product.id, url: product.url, error: errorMessage },
          'Failed to check product price'
        );

        await app.db
          .update(schema.trackedProducts)
          .set({
            lastCheckedAt: sql`now()`,
            fetchErrorCount: sql`${schema.trackedProducts.fetchErrorCount} + 1`,
            lastFetchError: errorMessage.substring(0, 255),
          })
          .where(eq(schema.trackedProducts.id, product.id));

        errorCount++;
      }
    }

    app.logger.info({ updatedCount, errorCount }, 'Price check complete');
  } catch (error) {
    app.logger.error({ err: error }, 'Price check cycle failed');
  }
}
