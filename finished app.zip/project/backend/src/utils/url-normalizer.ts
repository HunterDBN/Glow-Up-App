export function normalizeUrl(url: string): string {
  try {
    // Trim and lowercase
    const trimmed = url.trim().toLowerCase();

    // Try to parse as URL
    const parsed = new URL(trimmed);

    // Remove tracking parameters
    const trackingParams = [
      'utm_source',
      'utm_medium',
      'utm_campaign',
      'utm_content',
      'utm_term',
      'ref',
      'referrer',
      'fbclid',
      'gclid',
    ];

    const params = new URLSearchParams(parsed.search);
    for (const param of trackingParams) {
      params.delete(param);
    }

    // Build normalized URL: origin + pathname (remove trailing slash)
    let pathname = parsed.pathname;
    if (pathname.endsWith('/')) {
      pathname = pathname.slice(0, -1);
    }

    const normalized = parsed.origin + pathname;
    return normalized;
  } catch {
    // If URL parsing fails, fall back to trimmed lowercase string
    return url.trim().toLowerCase();
  }
}

export function normalizeShopeeUrl(url: string): string | null {
  try {
    const trimmed = url.trim().toLowerCase();
    const parsed = new URL(trimmed);

    let shopid: string | null = null;
    let itemid: string | null = null;

    // Strategy a: pathname matches /i.{shopid}.{itemid}
    const iMatch = parsed.pathname.match(/^\/i\.(\d+)\.(\d+)/);
    if (iMatch) {
      shopid = iMatch[1];
      itemid = iMatch[2];
    }

    // Strategy b: pathname matches /product/{shopid}/{itemid}
    if (!shopid || !itemid) {
      const productMatch = parsed.pathname.match(/^\/product\/(\d+)\/(\d+)/);
      if (productMatch) {
        shopid = productMatch[1];
        itemid = productMatch[2];
      }
    }

    // Strategy c: query parameters shopid and itemid
    if (!shopid || !itemid) {
      const shopidParam = parsed.searchParams.get('shopid');
      const itemidParam = parsed.searchParams.get('itemid');
      if (shopidParam && itemidParam) {
        shopid = shopidParam;
        itemid = itemidParam;
      }
    }

    // Return canonical URL if both IDs found
    if (shopid && itemid) {
      return `https://shopee.com.my/product/${shopid}/${itemid}`;
    }

    return null;
  } catch {
    return null;
  }
}
