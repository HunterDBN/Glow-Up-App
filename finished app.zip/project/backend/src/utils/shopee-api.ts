import { normalizeShopeeUrl } from './url-normalizer.js';

interface ShopeeProductData {
  name: string;
  price: number;
  image_url: string | null;
  in_stock: boolean;
}

interface ShopeeInfo {
  tld: string;
  currency: string;
  shopid: string | null;
  itemid: string | null;
}

/**
 * Fetch product data directly from Shopee's internal API
 */
export async function fetchShopeeProduct(
  shopid: string,
  itemid: string,
  tld: string
): Promise<ShopeeProductData> {
  const url = `https://shopee.${tld}/api/v4/item/get?itemid=${itemid}&shopid=${shopid}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        'Accept': 'application/json',
        'Accept-Language': 'en-MY,en;q=0.9',
        'Referer': `https://shopee.${tld}/`,
        'X-Requested-With': 'XMLHttpRequest',
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Shopee API returned ${response.status}`);
    }

    const data = await response.json() as any;

    // Check for API-level errors
    if (data.error) {
      throw new Error(`Shopee API error: ${data.error}`);
    }

    // Extract product data
    if (!data.data) {
      throw new Error('No data in Shopee API response');
    }

    const item = data.data;

    // Extract name
    const name = item.name;
    if (!name || typeof name !== 'string' || name.length <= 3) {
      throw new Error('Invalid or missing product name');
    }

    // Extract price (divide by 100000 to convert from minor units)
    let price = item.price;
    if (!price && item.price_min) {
      price = item.price_min;
    }
    if (!price || typeof price !== 'number') {
      throw new Error('Invalid or missing product price');
    }
    price = price / 100000;
    if (price <= 0) {
      throw new Error('Price is zero or negative');
    }

    // Extract image URL
    let image_url: string | null = null;
    if (item.images && Array.isArray(item.images) && item.images.length > 0) {
      image_url = `https://cf.shopee.${tld}/file/${item.images[0]}`;
    }

    // Extract stock status
    const in_stock = item.item_status === 'normal';

    return {
      name,
      price,
      image_url,
      in_stock,
    };
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

/**
 * Retry wrapper for fetchShopeeProduct with exponential backoff
 */
export async function fetchShopeeProductWithRetry(
  shopid: string,
  itemid: string,
  tld: string,
  maxRetries = 2
): Promise<ShopeeProductData> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fetchShopeeProduct(shopid, itemid, tld);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      // Don't delay after the last attempt
      if (attempt < maxRetries) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
    }
  }

  throw lastError || new Error('Failed to fetch Shopee product');
}

/**
 * Extract Shopee TLD, currency, shopid, and itemid from URL
 */
export function getShopeeInfo(url: string): ShopeeInfo {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.toLowerCase();

    // Detect TLD and currency
    let tld = 'com.my';
    let currency = 'MYR';

    if (hostname.includes('shopee.com.my')) {
      tld = 'com.my';
      currency = 'MYR';
    } else if (hostname.includes('shopee.vn')) {
      tld = 'vn';
      currency = 'VND';
    } else if (hostname.includes('shopee.co.id')) {
      tld = 'co.id';
      currency = 'IDR';
    } else if (hostname.includes('shopee.ph')) {
      tld = 'ph';
      currency = 'PHP';
    } else if (hostname.includes('shopee.sg')) {
      tld = 'sg';
      currency = 'SGD';
    } else if (hostname.includes('shopee.com')) {
      tld = 'com';
      currency = 'USD';
    }

    // Extract shopid and itemid from the normalized/canonical URL format
    // The URL should be like: https://shopee.XXX/product/{shopid}/{itemid}
    // or after normalization: https://shopee.com.my/product/{shopid}/{itemid}
    const match = parsed.pathname.match(/\/product\/(\d+)\/(\d+)/);
    if (match) {
      return {
        tld,
        currency,
        shopid: match[1],
        itemid: match[2],
      };
    }

    // Try the alternate format /i.{shopid}.{itemid}
    const iMatch = parsed.pathname.match(/\/i\.(\d+)\.(\d+)/);
    if (iMatch) {
      return {
        tld,
        currency,
        shopid: iMatch[1],
        itemid: iMatch[2],
      };
    }

    // Try extracting from query parameters
    const shopidParam = parsed.searchParams.get('shopid');
    const itemidParam = parsed.searchParams.get('itemid');
    if (shopidParam && itemidParam) {
      return {
        tld,
        currency,
        shopid: shopidParam,
        itemid: itemidParam,
      };
    }

    return {
      tld,
      currency,
      shopid: null,
      itemid: null,
    };
  } catch {
    return {
      tld: 'com.my',
      currency: 'MYR',
      shopid: null,
      itemid: null,
    };
  }
}
