import type { App } from '../index.js';
import * as schema from '../db/schema/schema.js';
import { eq, desc } from 'drizzle-orm';

export interface Product {
  tracking_id: string;
  product_name: string;
  platform: string;
  price: number;
  previous_price: number | null;
  price_change: 'unchanged' | 'dropped' | 'increased';
  product_url: string | null;
  image_url: string | null;
  store_name: string | null;
  notes: string | null;
  description: string | null;
  brand: string | null;
  category: string | null;
  created_at: Date;
  last_updated_at: Date;
}

export function toProduct(row: any): Product {
  let price_change: 'unchanged' | 'dropped' | 'increased' = 'unchanged';

  if (row.previousPrice !== null && row.previousPrice !== undefined) {
    const prevPrice = typeof row.previousPrice === 'string'
      ? parseFloat(row.previousPrice)
      : row.previousPrice;
    const currPrice = typeof row.currentPrice === 'string'
      ? parseFloat(row.currentPrice)
      : row.currentPrice;

    if (currPrice < prevPrice) {
      price_change = 'dropped';
    } else if (currPrice > prevPrice) {
      price_change = 'increased';
    }
  }

  const lastUpdated = row.lastUpdatedAt || row.createdAt;

  return {
    tracking_id: row.trackingId,
    product_name: row.name,
    platform: row.platform,
    price: typeof row.currentPrice === 'string'
      ? parseFloat(row.currentPrice)
      : row.currentPrice,
    previous_price: row.previousPrice
      ? typeof row.previousPrice === 'string'
        ? parseFloat(row.previousPrice)
        : row.previousPrice
      : null,
    price_change,
    product_url: row.url ?? null,
    image_url: row.imageUrl ?? null,
    store_name: row.storeName ?? null,
    notes: row.notes ?? null,
    description: row.description ?? null,
    brand: row.brand ?? null,
    category: row.category ?? null,
    created_at: row.createdAt,
    last_updated_at: lastUpdated,
  };
}

/**
 * Generate the next tracking_id in format PW-XXXXXX
 */
export async function getNextTrackingId(app: App): Promise<string> {
  // Query existing tracking_ids and find the max numeric suffix
  const products = await app.db
    .select({ trackingId: schema.trackedProducts.trackingId })
    .from(schema.trackedProducts);

  let maxNum = 0;

  for (const product of products) {
    const match = product.trackingId.match(/^PW-(\d+)$/);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) {
        maxNum = num;
      }
    }
  }

  const nextNum = maxNum + 1;
  const paddedNum = String(nextNum).padStart(6, '0');
  return `PW-${paddedNum}`;
}

/**
 * Backfill tracking_id for existing rows
 */
export async function backfillTrackingIds(app: App): Promise<number> {
  // Find all products where tracking_id is empty or null
  const products = await app.db
    .select()
    .from(schema.trackedProducts)
    .orderBy(schema.trackedProducts.createdAt);

  let updated = 0;
  let nextNum = 1;

  for (const product of products) {
    if (!product.trackingId) {
      const paddedNum = String(nextNum).padStart(6, '0');
      const newTrackingId = `PW-${paddedNum}`;

      await app.db
        .update(schema.trackedProducts)
        .set({ trackingId: newTrackingId })
        .where(eq(schema.trackedProducts.id, product.id));

      updated++;
      nextNum++;
    }
  }

  return updated;
}
