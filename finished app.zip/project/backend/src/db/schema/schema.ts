import {
  pgTable,
  pgEnum,
  text,
  numeric,
  boolean,
  timestamp,
  integer,
  unique,
  uuid,
} from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

export const platformEnum = pgEnum('platform', [
  'shopee',
  'lazada',
  'tokopedia',
  'tiktok_shop',
  'manual',
  'other',
]);

export const alertTypeEnum = pgEnum('alert_type', [
  'price_drop',
  'restock',
  'target_reached',
]);

export const trackedProducts = pgTable('tracked_products', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  trackingId: text('tracking_id').notNull().unique(),
  name: text('name').notNull(),
  url: text('url'),
  platform: platformEnum('platform').notNull(),
  imageUrl: text('image_url'),
  currentPrice: numeric('current_price', { precision: 10, scale: 2 }).notNull(),
  originalPrice: numeric('original_price', { precision: 10, scale: 2 }).notNull(),
  targetPrice: numeric('target_price', { precision: 10, scale: 2 }),
  previousPrice: numeric('previous_price', { precision: 10, scale: 2 }),
  currency: text('currency').default('MYR').notNull(),
  inStock: boolean('in_stock').default(true).notNull(),
  storeName: text('store_name'),
  notes: text('notes'),
  description: text('description'),
  brand: text('brand'),
  category: text('category'),
  lastCheckedAt: timestamp('last_checked_at', { withTimezone: true }),
  checkIntervalMinutes: integer('check_interval_minutes').default(60).notNull(),
  fetchErrorCount: integer('fetch_error_count').default(0).notNull(),
  lastFetchError: text('last_fetch_error'),
  lastUpdatedAt: timestamp('last_updated_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const priceHistory = pgTable('price_history', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  trackedProductId: text('tracked_product_id')
    .notNull()
    .references(() => trackedProducts.id, { onDelete: 'cascade' }),
  price: numeric('price', { precision: 10, scale: 2 }).notNull(),
  note: text('note'),
  recordedAt: timestamp('recorded_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const alerts = pgTable('alerts', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  trackedProductId: text('tracked_product_id')
    .notNull()
    .references(() => trackedProducts.id, { onDelete: 'cascade' }),
  type: alertTypeEnum('type').notNull(),
  message: text('message').notNull(),
  oldPrice: numeric('old_price', { precision: 10, scale: 2 }),
  newPrice: numeric('new_price', { precision: 10, scale: 2 }),
  savings: numeric('savings', { precision: 10, scale: 2 }),
  isRead: boolean('is_read').default(false).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const productViews = pgTable('product_views', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  trackedProductId: text('tracked_product_id')
    .notNull()
    .references(() => trackedProducts.id, { onDelete: 'cascade' }),
  viewedAt: timestamp('viewed_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

// TrendJack tables
export const trends = pgTable('trends', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  title: text('title').notNull(),
  niche: text('niche').notNull(),
  platform: text('platform').notNull(),
  whyItsTrending: text('why_its_trending').notNull(),
  trendScore: integer('trend_score').notNull(),
  isFeatured: boolean('is_featured').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const templates = pgTable('templates', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  trendId: text('trend_id')
    .notNull()
    .references(() => trends.id, { onDelete: 'cascade' }),
  hook: text('hook').notNull(),
  script: text('script').notNull(),
  caption: text('caption').notNull(),
  callToAction: text('call_to_action').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const tjUsers = pgTable('tj_users', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  deviceId: text('device_id').notNull().unique(),
  name: text('name').notNull().default('Creator'),
  selectedNiches: text('selected_niches').notNull().default(''),
  joinedAt: timestamp('joined_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const savedItems = pgTable('saved_items', {
  id: text('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: text('user_id')
    .notNull()
    .references(() => tjUsers.id, { onDelete: 'cascade' }),
  trendId: text('trend_id')
    .notNull()
    .references(() => trends.id, { onDelete: 'cascade' }),
  templateId: text('template_id').references(() => templates.id, { onDelete: 'set null' }),
  savedAt: timestamp('saved_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
}, (table) => ({
  uniqueUserTrend: unique().on(table.userId, table.trendId),
}));

// GlowUp enums
export const guCategoryEnum = pgEnum('gu_category', [
  'fitness',
  'skincare',
  'mental health',
  'style',
  'confidence',
  'relationships',
  'career',
  'wellness',
]);

export const guMoodEnum = pgEnum('gu_mood', [
  'glowing',
  'growing',
  'struggling',
  'grateful',
  'powerful',
  'soft',
]);

// GlowUp tables
export const guProfiles = pgTable('gu_profiles', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull().unique(),
  username: text('username').notNull().unique(),
  bio: text('bio').notNull().default(''),
  profilePhoto: text('profile_photo').notNull().default(''),
  glowAreas: text('glow_areas').notNull().default(''),
  instagramUrl: text('instagram_url').notNull().default(''),
  tiktokUrl: text('tiktok_url').notNull().default(''),
  pinterestUrl: text('pinterest_url').notNull().default(''),
  youtubeUrl: text('youtube_url').notNull().default(''),
  isPremium: boolean('is_premium').notNull().default(false),
  joinedAt: timestamp('joined_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const guPosts = pgTable('gu_posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  content: text('content').notNull(),
  imageUrl: text('image_url').notNull().default(''),
  category: guCategoryEnum('category').notNull(),
  likesCount: integer('likes_count').notNull().default(0),
  commentsCount: integer('comments_count').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const guComments = pgTable('gu_comments', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').notNull().references(() => guPosts.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull(),
  commentText: text('comment_text').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const guLikes = pgTable('gu_likes', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').notNull().references(() => guPosts.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
}, (table) => ({
  uniqueLike: unique().on(table.postId, table.userId),
}));

export const guSavedPosts = pgTable('gu_saved_posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  postId: uuid('post_id').notNull().references(() => guPosts.id, { onDelete: 'cascade' }),
  savedAt: timestamp('saved_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
}, (table) => ({
  uniqueSavedPost: unique().on(table.userId, table.postId),
}));

export const guChallenges = pgTable('gu_challenges', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  category: guCategoryEnum('category').notNull(),
  durationDays: integer('duration_days').notNull(),
  coverImage: text('cover_image').notNull().default(''),
  isPremium: boolean('is_premium').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const guChallengeEntries = pgTable('gu_challenge_entries', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  challengeId: uuid('challenge_id').notNull().references(() => guChallenges.id, { onDelete: 'cascade' }),
  dayNumber: integer('day_number').notNull(),
  note: text('note').notNull().default(''),
  photoUrl: text('photo_url').notNull().default(''),
  loggedAt: timestamp('logged_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});

export const guJournalEntries = pgTable('gu_journal_entries', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  prompt: text('prompt').notNull(),
  response: text('response').notNull(),
  mood: guMoodEnum('mood').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true })
    .default(sql`now()`)
    .notNull(),
});
