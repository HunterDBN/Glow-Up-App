import { createApplication } from '@specific-dev/framework';
import * as schema from './schema/schema.js';

async function seed() {
  const app = await createApplication(schema);
  const db = app.db;

  console.log('Clearing database...');

  // Delete in correct order to respect FK constraints
  await db.delete(schema.alerts);
  console.log('Cleared alerts');

  await db.delete(schema.priceHistory);
  console.log('Cleared price history');

  await db.delete(schema.trackedProducts);
  console.log('Cleared tracked products');

  console.log('Database cleared successfully!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
