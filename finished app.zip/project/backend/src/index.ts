import { createApplication } from "@specific-dev/framework";
import * as appSchema from './db/schema/schema.js';
import * as authSchema from './db/schema/auth-schema.js';
import * as trackedProductsRoutes from './routes/tracked-products.js';
import * as productsRoutes from './routes/products.js';
import * as alertsRoutes from './routes/alerts.js';
import * as profileRoutes from './routes/profile.js';
import * as scraperRoutes from './routes/scraper.js';
import * as trendingRoutes from './routes/trending.js';
import * as hotDropsRoutes from './routes/hot-drops.js';
import * as metaRoutes from './routes/meta.js';
import * as trendjackRoutes from './routes/trendjack.js';
import * as glowupRoutes from './routes/glowup.js';
import { normalizeShopeeUrl } from './utils/url-normalizer.js';
import { backfillTrackingIds } from './utils/products-helpers.js';
import { eq } from 'drizzle-orm';
import { sql } from 'drizzle-orm';
import { generateText } from 'ai';
import { google } from '@ai-sdk/google';

// Merge app and auth schemas
const schema = { ...appSchema, ...authSchema };

// Create application with schema for full database type support
export const app = await createApplication(schema);

// Enable authentication with Apple and Google OAuth
app.withAuth();

// Export App type for use in route files
export type App = typeof app;

// Register routes
trackedProductsRoutes.register(app, app.fastify);
productsRoutes.register(app, app.fastify);
alertsRoutes.register(app, app.fastify);
profileRoutes.register(app, app.fastify);
scraperRoutes.register(app, app.fastify);
trendingRoutes.register(app, app.fastify);
hotDropsRoutes.register(app, app.fastify);
metaRoutes.register(app, app.fastify);
trendjackRoutes.register(app, app.fastify);
glowupRoutes.register(app, app.fastify);

await app.run();
app.logger.info('Application running');

// Guard flag for backfill
let backfillRunning = false;

/**
 * Seed TrendJack trends and templates
 */
async function seedTrendJackData(app: any) {
  const trendsData = [
    {
      title: '7-Second Abs That Actually Work',
      niche: 'fitness',
      platform: 'TikTok',
      whyItsTrending: 'Quick fitness routines dominate short-form video',
      trendScore: 95,
    },
    {
      title: 'Air Fryer Hacks Nobody Knows',
      niche: 'food',
      platform: 'TikTok',
      whyItsTrending: 'Air fryer cooking content has viral engagement',
      trendScore: 92,
    },
    {
      title: 'Thrifting OOTD Transformations',
      niche: 'fashion',
      platform: 'Instagram',
      whyItsTrending: 'Sustainable fashion resonates with Gen Z',
      trendScore: 89,
    },
    {
      title: 'Passive Income: No Work Setup',
      niche: 'finance',
      platform: 'YouTube',
      whyItsTrending: 'Financial independence content drives views',
      trendScore: 88,
    },
    {
      title: 'Hidden Gem Travel Destinations',
      niche: 'travel',
      platform: 'TikTok',
      whyItsTrending: 'Travel exploration content highly shareable',
      trendScore: 87,
    },
    {
      title: 'Skincare Routine That Changed My Life',
      niche: 'beauty',
      platform: 'Instagram',
      whyItsTrending: 'Beauty transformations drive engagement',
      trendScore: 91,
    },
    {
      title: 'Gaming Fails Compilation Ultimate',
      niche: 'gaming',
      platform: 'TikTok',
      whyItsTrending: 'Comedy gaming content highly viral',
      trendScore: 86,
    },
    {
      title: 'Stand-Up Comedy Cold Open',
      niche: 'comedy',
      platform: 'YouTube',
      whyItsTrending: 'Comedy content builds loyal audiences',
      trendScore: 84,
    },
    {
      title: 'How to Learn Coding in 30 Days',
      niche: 'education',
      platform: 'YouTube',
      whyItsTrending: 'Skill-building content drives subscriptions',
      trendScore: 85,
    },
    {
      title: 'Relationship Red Flags You Ignore',
      niche: 'relationships',
      platform: 'TikTok',
      whyItsTrending: 'Relationship advice is evergreen viral content',
      trendScore: 90,
    },
    {
      title: 'Cute Pet Behavior Explained',
      niche: 'pets',
      platform: 'Instagram',
      whyItsTrending: 'Pet content has highest engagement rates',
      trendScore: 93,
    },
    {
      title: 'DIY Room Makeover Challenge',
      niche: 'DIY',
      platform: 'TikTok',
      whyItsTrending: 'Home transformation videos highly shareable',
      trendScore: 88,
    },
    {
      title: 'Bedroom Pop Production Tutorial',
      niche: 'music',
      platform: 'YouTube',
      whyItsTrending: 'Music production content attracts creators',
      trendScore: 82,
    },
    {
      title: 'Olympic Training Secrets Revealed',
      niche: 'sports',
      platform: 'YouTube',
      whyItsTrending: 'Sports performance tips drive views',
      trendScore: 83,
    },
    {
      title: 'Side Hustle Ideas $500/Week',
      niche: 'business',
      platform: 'TikTok',
      whyItsTrending: 'Money-making content highly sought',
      trendScore: 89,
    },
    {
      title: 'Morning Wellness Routine Flow',
      niche: 'wellness',
      platform: 'Instagram',
      whyItsTrending: 'Wellness content builds communities',
      trendScore: 86,
    },
    {
      title: 'Parenting Hacks for Sanity',
      niche: 'parenting',
      platform: 'TikTok',
      whyItsTrending: 'Parent content has growing audience',
      trendScore: 81,
    },
    {
      title: 'Tech Gadget Unboxing ASMR',
      niche: 'tech',
      platform: 'YouTube',
      whyItsTrending: 'Tech reviews drive strong engagement',
      trendScore: 84,
    },
    {
      title: 'Meal Prep for Busy Professionals',
      niche: 'food',
      platform: 'YouTube',
      whyItsTrending: 'Practical food content highly valued',
      trendScore: 87,
    },
    {
      title: 'Home Gym Setup No Equipment',
      niche: 'fitness',
      platform: 'TikTok',
      whyItsTrending: 'Accessible fitness content viral',
      trendScore: 86,
    },
  ];

  // Create templates for each trend
  const templatesPerTrend = [
    {
      hook: 'Wait for the plot twist...',
      script: 'Introduce problem, build tension, reveal surprising solution',
      caption: 'This one trick changed everything 🤯',
      callToAction: 'Save this before they delete it',
    },
    {
      hook: 'POV: You\'re about to learn something life-changing',
      script: 'Show before, explain method, demonstrate after',
      caption: 'Tag someone who needs to see this',
      callToAction: 'Drop a 💯 if this helped you',
    },
  ];

  for (const trendData of trendsData) {
    // Insert trend
    const trend = await app.db
      .insert(schema.trends)
      .values(trendData)
      .returning();

    const trendId = trend[0].id;

    // Insert 2 templates for each trend
    for (const templateData of templatesPerTrend) {
      await app.db
        .insert(schema.templates)
        .values({
          trendId,
          ...templateData,
        });
    }
  }
}

/**
 * Seed GlowUp challenges and posts
 */
async function seedGlowUpData(app: any) {
  // Seed challenges
  const challengesData = [
    {
      title: '7-Day Morning Movement',
      category: 'fitness',
      description:
        'Start every morning with 10 minutes of movement — a walk, stretch, or quick workout. Build the habit that changes everything.',
      durationDays: 7,
      isPremium: false,
      coverImage: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800',
    },
    {
      title: 'Glow Skin Reset',
      category: 'skincare',
      description:
        '21 days of consistent skincare — cleanse, moisturise, SPF. No skipping. Watch your skin transform.',
      durationDays: 21,
      isPremium: false,
      coverImage: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=800',
    },
    {
      title: '30-Day Mindfulness Journey',
      category: 'mental health',
      description:
        'One mindful moment every day for 30 days. Breathe, reflect, and reconnect with yourself.',
      durationDays: 30,
      isPremium: true,
      coverImage: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800',
    },
    {
      title: 'Style Your Best Self',
      category: 'style',
      description:
        '14 days of intentional dressing. Wear something that makes you feel amazing every single day.',
      durationDays: 14,
      isPremium: false,
      coverImage: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800',
    },
    {
      title: 'Confidence Unlocked',
      category: 'confidence',
      description:
        '21 days of confidence-building actions — speak up, try something new, celebrate yourself daily.',
      durationDays: 21,
      isPremium: true,
      coverImage: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800',
    },
    {
      title: 'Connection Challenge',
      category: 'relationships',
      description:
        '14 days of deepening your relationships — reach out, listen deeply, express gratitude.',
      durationDays: 14,
      isPremium: false,
      coverImage: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800',
    },
    {
      title: 'Career Glow Up',
      category: 'career',
      description:
        '30 days of career-building actions — learn a skill, network, update your portfolio, apply for that role.',
      durationDays: 30,
      isPremium: true,
      coverImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800',
    },
    {
      title: 'Wellness Reset',
      category: 'wellness',
      description:
        '7 days of full-body wellness — sleep, hydration, nutrition, movement, and rest. All at once.',
      durationDays: 7,
      isPremium: false,
      coverImage: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800',
    },
  ];

  for (const challengeData of challengesData) {
    await app.db
      .insert(schema.guChallenges)
      .values(challengeData as any)
      .onConflictDoNothing();
  }

  // Create seed user
  const seedUserId = '00000000-0000-0000-0000-000000000001';
  const seedUserExists = await app.db
    .select()
    .from({ user: schema.guProfiles })
    .where(eq({ user: schema.guProfiles }.user.userId, seedUserId))
    .limit(1);

  if (seedUserExists.length === 0) {
    // Insert seed user into auth user table (note: this is done via raw SQL in migrations)
    try {
      await app.db.execute(
        sql`INSERT INTO "user" (id, name, email, email_verified, created_at, updated_at) VALUES (${seedUserId}, 'GlowUp Community', 'community@glowup.app', true, now(), now()) ON CONFLICT (id) DO NOTHING`
      );
    } catch (e) {
      app.logger.debug('Seed user may already exist');
    }

    // Create profile for seed user
    await app.db
      .insert(schema.guProfiles)
      .values({
        userId: seedUserId,
        username: 'glowup_community',
        bio: 'Your GlowUp community 💫',
        profilePhoto: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=200',
        glowAreas: 'wellness,confidence,fitness',
      })
      .onConflictDoNothing();
  }

  // Seed posts
  const postsData = [
    {
      content:
        'Just completed my first 5K run after 3 months of training 🏃‍♀️✨ I cried at the finish line. If you told me 3 months ago I would do this I would have laughed. Keep going girls — the glow up is REAL.',
      category: 'fitness',
      likesCount: 47,
      imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800',
    },
    {
      content:
        'PSA: double cleansing changed my skin more than any expensive serum ever did 🧴 Oil cleanser first to remove makeup and SPF, then your regular cleanser. My pores are literally invisible now. You are welcome.',
      category: 'skincare',
      likesCount: 89,
      imageUrl: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=800',
    },
    {
      content:
        'Therapy is the best investment I have ever made in myself. Not a flex — just a reminder that asking for help is the strongest thing you can do 💜 Your mental health is worth every penny.',
      category: 'mental health',
      likesCount: 134,
      imageUrl: '',
    },
    {
      content:
        'Wore the bold red lip to the work meeting today. Nobody said anything but I felt like a CEO the entire time 💄👑 Dress for the version of yourself you are becoming.',
      category: 'style',
      likesCount: 62,
      imageUrl: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800',
    },
    {
      content:
        'I said no to something that did not serve me today and I did not apologise for it. That is my win. Small but mighty 💪 Boundaries are self-love in action.',
      category: 'confidence',
      likesCount: 201,
      imageUrl: '',
    },
    {
      content:
        'Called my mum just to tell her I love her. No reason. No occasion. She cried. I cried. Relationships need watering just like plants 🌸 Who are you going to reach out to today?',
      category: 'relationships',
      likesCount: 78,
      imageUrl: '',
    },
    {
      content:
        'Got the promotion 🎉 Two years of showing up, learning, and refusing to shrink myself. It is yours too — keep building. The right people will notice.',
      category: 'career',
      likesCount: 312,
      imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800',
    },
    {
      content:
        '8 hours of sleep for 7 days straight and I am a completely different person. Not joking. Skin clearer, mood better, energy through the roof. Sleep is the original glow up.',
      category: 'wellness',
      likesCount: 156,
      imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800',
    },
    {
      content:
        'Reminder that your glow up does not have to be visible to count 🌱 Healing quietly, growing slowly, choosing yourself every day — that is the real transformation. You are doing amazing.',
      category: 'mental health',
      likesCount: 445,
      imageUrl: '',
    },
    {
      content:
        'Started my skincare routine at 22 thinking it was too late. I am 28 now and people think I am 19. It is never too late to start. Your future skin will thank you 🌟',
      category: 'skincare',
      likesCount: 267,
      imageUrl: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=800',
    },
  ];

  for (const postData of postsData) {
    await app.db
      .insert(schema.guPosts)
      .values({
        userId: seedUserId,
        content: postData.content,
        category: postData.category as any,
        imageUrl: postData.imageUrl,
        likesCount: postData.likesCount,
      })
      .onConflictDoNothing();
  }
}

// One-time startup migration: backfill tracking_ids, normalize Shopee URLs, and add missing columns
(async () => {
  try {
    app.logger.info('Starting startup migrations');

    // Backfill tracking_ids for existing products
    const backfilledCount = await backfillTrackingIds(app);
    if (backfilledCount > 0) {
      app.logger.info({ count: backfilledCount }, 'Tracking IDs backfilled');
    }

    // Normalize existing Shopee URLs
    const shopeeProducts = await app.db
      .select()
      .from(schema.trackedProducts)
      .where(eq(schema.trackedProducts.platform, 'shopee'));

    let normalizedCount = 0;

    for (const product of shopeeProducts) {
      if (!product.url) continue;

      const canonicalUrl = normalizeShopeeUrl(product.url);
      if (canonicalUrl && canonicalUrl !== product.url) {
        await app.db
          .update(schema.trackedProducts)
          .set({ url: canonicalUrl })
          .where(eq(schema.trackedProducts.id, product.id));
        normalizedCount++;
        app.logger.debug(
          { productId: product.id, oldUrl: product.url, newUrl: canonicalUrl },
          'Shopee URL normalized'
        );
      }
    }

    if (normalizedCount > 0) {
      app.logger.info({ count: normalizedCount }, 'Shopee URLs normalized');
    }

    // Safely add new columns if they don't exist
    try {
      const columns = ['description', 'brand', 'category'];
      for (const col of columns) {
        try {
          // Try to add the column - if it exists, this will fail silently
          await app.db.execute(
            sql.raw(`ALTER TABLE tracked_products ADD COLUMN ${col} text;`)
          );
          app.logger.info({ column: col }, 'Column added to tracked_products');
        } catch (colError: any) {
          // Column likely already exists - ignore
          if (!colError.message?.includes('already exists') && !colError.message?.includes('duplicate')) {
            app.logger.debug({ column: col, err: colError }, 'Column already exists or other error');
          }
        }
      }
    } catch (colError) {
      app.logger.warn({ err: colError }, 'Error adding columns (may already exist)');
    }

    // Seed TrendJack trends if table is empty
    const existingTrends = await app.db
      .select({ id: schema.trends.id })
      .from(schema.trends)
      .limit(1);

    if (existingTrends.length === 0) {
      app.logger.info('Seeding TrendJack trends');
      await seedTrendJackData(app);
      app.logger.info('TrendJack trends seeded');
    }

    // Seed GlowUp challenges and posts if table is empty
    const existingChallenges = await app.db
      .select({ id: schema.guChallenges.id })
      .from(schema.guChallenges)
      .limit(1);

    if (existingChallenges.length === 0) {
      app.logger.info('Seeding GlowUp challenges and posts');
      await seedGlowUpData(app);
      app.logger.info('GlowUp challenges and posts seeded');
    }

    app.logger.info('Startup migrations complete');

    // Start background backfill job (non-blocking)
    if (!backfillRunning) {
      backfillRunning = true;
      backfillProductMetadata(app);
    }
  } catch (error) {
    app.logger.error({ err: error }, 'Startup migrations failed');
  }
})();

/**
 * Background job to backfill product metadata
 */
async function backfillProductMetadata(app: any) {
  try {
    app.logger.info('Starting product metadata backfill job');

    while (true) {
      // Query products with null description and non-null URL, limit 20
      const productsToUpdate = await app.db
        .select()
        .from(schema.trackedProducts)
        .where(eq(schema.trackedProducts.description, null))
        .limit(20);

      if (productsToUpdate.length === 0) {
        app.logger.info('Product metadata backfill complete');
        break;
      }

      for (const product of productsToUpdate) {
        if (!product.url) {
          app.logger.debug({ trackingId: product.trackingId }, 'Skipping product with no URL');
          continue;
        }

        try {
          // Fetch metadata using same logic as GET /api/meta
          const result = await fetchProductMetadata(product.url);

          // Update only non-null fields
          const updateData: Record<string, any> = {};
          if (result.description) updateData.description = result.description;
          if (result.brand) updateData.brand = result.brand;
          if (result.category) updateData.category = result.category;

          if (Object.keys(updateData).length > 0) {
            await app.db
              .update(schema.trackedProducts)
              .set(updateData)
              .where(eq(schema.trackedProducts.id, product.id));

            app.logger.info(
              {
                trackingId: product.trackingId,
                brand: result.brand || null,
                category: result.category || null,
              },
              '[Backfill] Updated product'
            );
          }
        } catch (productError) {
          app.logger.warn(
            { trackingId: product.trackingId, err: productError },
            '[Backfill] Failed to update product metadata'
          );
        }

        // Wait 2 seconds between products
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
    }
  } catch (error) {
    app.logger.error({ err: error }, 'Product metadata backfill failed');
  }
}

/**
 * Fetch metadata from a URL (mirrors GET /api/meta logic)
 */
async function fetchProductMetadata(url: string): Promise<{
  description: string | null;
  brand: string | null;
  category: string | null;
}> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        'Accept': 'text/html',
      },
      signal: controller.signal,
      redirect: 'follow',
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      return { description: null, brand: null, category: null };
    }

    const html = await response.text();

    // Extract metadata using regex
    const extractMeta = (property: string): string | null => {
      const ogRegex = new RegExp(
        `<meta\\s+property=["']og:${property}["']\\s+content=["']([^"']+)["']`,
        'i'
      );
      const ogMatch = html.match(ogRegex);
      if (ogMatch && ogMatch[1]) return ogMatch[1];

      const nameRegex = new RegExp(
        `<meta\\s+name=["']${property}["']\\s+content=["']([^"']+)["']`,
        'i'
      );
      const nameMatch = html.match(nameRegex);
      if (nameMatch && nameMatch[1]) return nameMatch[1];

      return null;
    };

    let description = extractMeta('description');
    let brand: string | null = null;
    let category: string | null = null;

    // Extract brand
    let match = html.match(
      /<meta\s+property=["']product:brand["']\s+content=["']([^"']+)["']/i
    );
    if (match && match[1]) brand = match[1];

    match = html.match(/<meta\s+name=["']brand["']\s+content=["']([^"']+)["']/i);
    if (!brand && match && match[1]) brand = match[1];

    const jsonLdMatch = html.match(/"brand"\s*:\s*{"name"\s*:\s*"([^"]+)"}/i);
    if (!brand && jsonLdMatch && jsonLdMatch[1]) brand = jsonLdMatch[1];

    // Extract category
    match = html.match(
      /<meta\s+property=["']product:category["']\s+content=["']([^"']+)["']/i
    );
    if (match && match[1]) category = match[1];

    match = html.match(/"category"\s*:\s*"([^"]+)"/i);
    if (!category && match && match[1]) category = match[1];

    // If brand or category missing, call Gemini
    if (!brand || !category) {
      try {
        const title = html.match(/<title>([^<]+)<\/title>/i)?.[1] || 'Unknown';
        const aiResponse = await generateText({
          model: google('gemini-2.0-flash'),
          prompt: `Product title: "${title}"

Return JSON: { "brand": "...", "category": "..." }
Brand should be the manufacturer/brand name (e.g. "Nike", "Apple", "Samsung"). If unknown, return null.
Category should be a short product category label (e.g. "Trainers", "Smartphone", "Skincare", "Jacket"). If unknown, return null.
Return ONLY the JSON object.`,
          temperature: 0.3,
          timeout: 5000,
        });

        try {
          const parsed = JSON.parse(aiResponse.text);
          if (!brand && parsed.brand) brand = parsed.brand;
          if (!category && parsed.category) category = parsed.category;
        } catch (_parseError) {
          // Ignore parse errors
        }
      } catch (_aiError) {
        // Ignore AI errors
      }
    }

    return { description, brand, category };
  } catch (_error) {
    return { description: null, brand: null, category: null };
  }
}

// Note: Price-check scheduler has been disabled. Use manual price updates via POST /api/products/:tracking_id/price
