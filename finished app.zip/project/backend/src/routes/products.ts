import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc } from 'drizzle-orm';
import { sql } from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';
import { toProduct, getNextTrackingId, type Product } from '../utils/products-helpers.js';
import { generateText } from 'ai';
import { google } from '@ai-sdk/google';
import { fetchMetaForUrl } from './meta.js';

/**
 * In-memory cache for price comparisons
 */
interface CacheEntry {
  data: ComparisonEntry[];
  expiresAt: number;
}

const comparisonCache = new Map<string, CacheEntry>();

/**
 * Price comparison entry
 */
interface ComparisonEntry {
  store: string;
  price: number;
  currency: string;
  url: string | null;
  is_current: boolean;
  is_best_price: boolean;
}

/**
 * Map platform enum to display name
 */
function getPlatformDisplayName(platform: string): string {
  switch (platform) {
    case 'shopee':
      return 'Shopee';
    case 'lazada':
      return 'Lazada';
    case 'tiktok_shop':
      return 'TikTok Shop';
    case 'manual':
    default:
      return 'Other';
  }
}

/**
 * Normalize URL by stripping tracking parameters
 */
function normalizeUrlForUpsert(url: string): string {
  try {
    const parsed = new URL(url);

    // List of tracking parameters to remove
    const trackingParams = [
      'utm_source',
      'utm_medium',
      'utm_campaign',
      'utm_term',
      'utm_content',
      'utm_id',
      'af_sub1',
      'af_sub2',
      'af_sub3',
      'af_sub4',
      'af_sub5',
      'af_click_lookback',
      'af_reengagement_window',
      'fbclid',
      'sp_atk',
      'gclid',
      'msclkid',
    ];

    // Remove tracking params
    for (const param of trackingParams) {
      parsed.searchParams.delete(param);
    }

    // Return normalized URL
    return parsed.toString();
  } catch {
    return url.trim();
  }
}

/**
 * Map display platform names to database enum values
 */
function mapPlatformToEnum(
  displayName: string
): 'shopee' | 'lazada' | 'tokopedia' | 'tiktok_shop' | 'manual' | 'other' | null {
  const lower = displayName.toLowerCase().trim();
  if (lower === 'shopee') return 'shopee';
  if (lower === 'lazada') return 'lazada';
  if (lower === 'tokopedia') return 'tokopedia';
  if (lower.includes('tiktok')) return 'tiktok_shop';
  if (lower === 'manual') return 'manual';
  if (lower === 'other') return 'other';
  return null; // Invalid platform
}

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/products - List all products
  fastify.get(
    '/api/products',
    {
      schema: {
        description: 'List all tracked products',
        tags: ['products'],
        response: {
          200: {
            description: 'List of products',
            type: 'object',
            properties: {
              products: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    tracking_id: { type: 'string' },
                    product_name: { type: 'string' },
                    platform: { type: 'string' },
                    price: { type: 'number' },
                    previous_price: { type: ['number', 'null'] },
                    price_change: { type: 'string', enum: ['unchanged', 'dropped', 'increased'] },
                    product_url: { type: ['string', 'null'] },
                    image_url: { type: ['string', 'null'] },
                    store_name: { type: ['string', 'null'] },
                    notes: { type: ['string', 'null'] },
                    description: { type: ['string', 'null'] },
                    brand: { type: ['string', 'null'] },
                    category: { type: ['string', 'null'] },
                    created_at: { type: 'string', format: 'date-time' },
                    last_updated_at: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      app.logger.info('Listing all products');

      try {
        const products = await app.db
          .select()
          .from(schema.trackedProducts)
          .orderBy(desc(schema.trackedProducts.lastUpdatedAt));

        const mapped = products.map(toProduct);

        app.logger.info({ count: mapped.length }, 'Products listed successfully');
        return { products: mapped };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to list products');
        throw error;
      }
    }
  );

  // POST /api/products - Create new product
  fastify.post<{
    Body: {
      product_name: string;
      platform: string;
      price: number;
      product_url?: string;
      image_url?: string;
      store_name?: string;
      notes?: string;
      description?: string;
      brand?: string;
      category?: string;
    };
  }>(
    '/api/products',
    {
      schema: {
        description: 'Create a new tracked product',
        tags: ['products'],
        body: {
          type: 'object',
          required: ['product_name', 'platform', 'price'],
          properties: {
            product_name: { type: 'string' },
            platform: { type: 'string', enum: ['shopee', 'lazada', 'tiktok_shop', 'other'] },
            price: { type: 'number' },
            product_url: { type: 'string' },
            image_url: { type: 'string' },
            store_name: { type: 'string' },
            notes: { type: 'string' },
            description: { type: 'string' },
            brand: { type: 'string' },
            category: { type: 'string' },
          },
        },
        response: {
          201: {
            description: 'Product created',
            type: 'object',
            properties: {
              tracking_id: { type: 'string' },
              product_name: { type: 'string' },
              platform: { type: 'string' },
              price: { type: 'number' },
              previous_price: { type: ['number', 'null'] },
              price_change: { type: 'string' },
              product_url: { type: ['string', 'null'] },
              image_url: { type: ['string', 'null'] },
              store_name: { type: ['string', 'null'] },
              notes: { type: ['string', 'null'] },
              description: { type: ['string', 'null'] },
              brand: { type: ['string', 'null'] },
              category: { type: ['string', 'null'] },
              created_at: { type: 'string', format: 'date-time' },
              last_updated_at: { type: 'string', format: 'date-time' },
            },
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Body: {
          product_name: string;
          platform: string;
          price: number;
          product_url?: string;
          image_url?: string;
          store_name?: string;
          notes?: string;
          description?: string;
          brand?: string;
          category?: string;
        };
      }>,
      reply: FastifyReply
    ) => {
      const { product_name, platform, price, product_url, image_url, store_name, notes, description, brand, category } =
        request.body;

      app.logger.info(
        { product_name, platform, price },
        'Creating product'
      );

      try {
        // Validate required fields
        if (!product_name || !platform || price === undefined || price === null) {
          return reply.status(400).send({
            error: 'Missing required fields: product_name, platform, price',
          });
        }

        // Generate tracking_id
        const trackingId = await getNextTrackingId(app);

        // Insert product
        try {
          await app.db
            .insert(schema.trackedProducts)
            .values({
              trackingId,
              name: product_name,
              platform: platform as any,
              currentPrice: price.toString(),
              originalPrice: price.toString(),
              previousPrice: null,
              currency: 'VND',
              inStock: true,
              url: product_url || null,
              imageUrl: image_url || null,
              storeName: store_name || null,
              notes: notes || null,
              description: description || null,
              brand: brand || null,
              category: category || null,
              checkIntervalMinutes: 60,
              fetchErrorCount: 0,
              lastFetchError: null,
              lastUpdatedAt: sql`now()`,
              createdAt: sql`now()`,
            });

          app.logger.debug({ trackingId, product_name: product_name }, 'Inserted product');
        } catch (insertError) {
          app.logger.error({ err: insertError, trackingId, product_name }, 'Failed to insert product');
          throw insertError;
        }

        // Re-fetch the inserted product
        let refetched;
        try {
          refetched = await app.db
            .select()
            .from(schema.trackedProducts)
            .where(eq(schema.trackedProducts.trackingId, trackingId))
            .limit(1);
        } catch (selectError) {
          app.logger.error({ err: selectError, trackingId }, 'Failed to select product after insert');
          throw selectError;
        }

        if (!refetched || refetched.length === 0) {
          app.logger.error({ trackingId, product_name }, 'Failed to refetch inserted product');
          return reply.status(500).send({ error: 'Failed to create product' });
        }

        const product = refetched[0];

        app.logger.debug({
          id: product.id,
          trackingId: product.trackingId,
          name: product.name,
          nameType: typeof product.name,
          hasName: 'name' in product
        }, 'Product refetch details for POST');

        // Insert price history
        await app.db.insert(schema.priceHistory).values({
          trackedProductId: product.id,
          price: price.toString(),
          note: 'Initial price',
          recordedAt: sql`now()`,
        });

        const mapped = toProduct(product);
        app.logger.info({ trackingId, product_name: mapped.product_name }, 'Product created successfully');
        reply.status(201);
        return mapped;
      } catch (error) {
        app.logger.error({ err: error, product_name, platform }, 'Failed to create product');
        throw error;
      }
    }
  );

  // GET /api/products/:tracking_id - Get product with history
  fastify.get<{
    Params: { tracking_id: string };
  }>(
    '/api/products/:tracking_id',
    {
      schema: {
        description: 'Get product with price history',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Product with history',
            type: 'object',
            properties: {
              tracking_id: { type: 'string' },
              product_name: { type: 'string' },
              platform: { type: 'string' },
              price: { type: 'number' },
              previous_price: { type: ['number', 'null'] },
              price_change: { type: 'string' },
              product_url: { type: ['string', 'null'] },
              image_url: { type: ['string', 'null'] },
              store_name: { type: ['string', 'null'] },
              notes: { type: ['string', 'null'] },
              description: { type: ['string', 'null'] },
              brand: { type: ['string', 'null'] },
              category: { type: ['string', 'null'] },
              created_at: { type: 'string', format: 'date-time' },
              last_updated_at: { type: 'string', format: 'date-time' },
              price_history: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    tracking_id: { type: 'string' },
                    price: { type: 'number' },
                    note: { type: ['string', 'null'] },
                    recorded_at: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { tracking_id: string } }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;

      app.logger.info({ tracking_id }, 'Getting product');

      try {
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];

        const history = await app.db
          .select()
          .from(schema.priceHistory)
          .where(eq(schema.priceHistory.trackedProductId, prod.id))
          .orderBy(desc(schema.priceHistory.recordedAt));

        const mappedHistory = history.map((h) => ({
          id: h.id,
          tracking_id: prod.trackingId,
          price: typeof h.price === 'string' ? parseFloat(h.price) : h.price,
          note: h.note ?? null,
          recorded_at: h.recordedAt,
        }));

        app.logger.info({ tracking_id }, 'Product retrieved successfully');
        return {
          ...toProduct(prod),
          price_history: mappedHistory,
        };
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to get product');
        throw error;
      }
    }
  );

  // POST /api/products/:tracking_id/price - Update price
  fastify.post<{
    Params: { tracking_id: string };
    Body: { price: number; note?: string };
  }>(
    '/api/products/:tracking_id/price',
    {
      schema: {
        description: 'Update product price',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['price'],
          properties: {
            price: { type: 'number' },
            note: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Price updated',
            type: 'object',
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Params: { tracking_id: string };
        Body: { price: number; note?: string };
      }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;
      const { price, note } = request.body;

      app.logger.info({ tracking_id, price }, 'Updating product price');

      try {
        if (price === undefined || price === null) {
          return reply.status(400).send({ error: 'Price is required' });
        }

        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];
        const oldPrice = typeof prod.currentPrice === 'string'
          ? parseFloat(prod.currentPrice)
          : prod.currentPrice;

        // Insert price history
        await app.db.insert(schema.priceHistory).values({
          trackedProductId: prod.id,
          price: price.toString(),
          note: note || null,
          recordedAt: sql`now()`,
        });

        // Update product
        await app.db
          .update(schema.trackedProducts)
          .set({
            currentPrice: price.toString(),
            previousPrice: oldPrice.toString(),
            lastUpdatedAt: sql`now()`,
          })
          .where(eq(schema.trackedProducts.trackingId, tracking_id));

        app.logger.info({ tracking_id, price }, 'Price updated successfully');

        const updated = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        return toProduct(updated[0]);
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to update price');
        throw error;
      }
    }
  );

  // POST /api/products/:tracking_id/notes - Append note
  fastify.post<{
    Params: { tracking_id: string };
    Body: { note: string };
  }>(
    '/api/products/:tracking_id/notes',
    {
      schema: {
        description: 'Append note to product',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['note'],
          properties: {
            note: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Note added',
            type: 'object',
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Params: { tracking_id: string };
        Body: { note: string };
      }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;
      const { note } = request.body;

      app.logger.info({ tracking_id }, 'Adding note to product');

      try {
        if (!note) {
          return reply.status(400).send({ error: 'Note is required' });
        }

        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];
        const existingNotes = prod.notes || '';
        const newNotes = existingNotes ? `${existingNotes}\n${note}` : note;

        await app.db
          .update(schema.trackedProducts)
          .set({
            notes: newNotes,
            lastUpdatedAt: sql`now()`,
          })
          .where(eq(schema.trackedProducts.trackingId, tracking_id));

        app.logger.info({ tracking_id }, 'Note added successfully');

        const updated = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        return toProduct(updated[0]);
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to add note');
        throw error;
      }
    }
  );

  // DELETE /api/products/:tracking_id - Delete product
  fastify.delete<{
    Params: { tracking_id: string };
  }>(
    '/api/products/:tracking_id',
    {
      schema: {
        description: 'Delete a product',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Product deleted',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { tracking_id: string } }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;

      app.logger.info({ tracking_id }, 'Deleting product');

      try {
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];

        // Delete price history
        await app.db
          .delete(schema.priceHistory)
          .where(eq(schema.priceHistory.trackedProductId, prod.id));

        // Delete product
        await app.db
          .delete(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id));

        app.logger.info({ tracking_id }, 'Product deleted successfully');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to delete product');
        throw error;
      }
    }
  );

  // GET /api/products/:tracking_id/history - Get price history
  fastify.get<{
    Params: { tracking_id: string };
  }>(
    '/api/products/:tracking_id/history',
    {
      schema: {
        description: 'Get price history for a product',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Price history',
            type: 'object',
            properties: {
              history: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    tracking_id: { type: 'string' },
                    price: { type: 'number' },
                    note: { type: ['string', 'null'] },
                    recorded_at: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { tracking_id: string } }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;

      app.logger.info({ tracking_id }, 'Getting price history');

      try {
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];

        const history = await app.db
          .select()
          .from(schema.priceHistory)
          .where(eq(schema.priceHistory.trackedProductId, prod.id))
          .orderBy(desc(schema.priceHistory.recordedAt));

        const mappedHistory = history.map((h) => ({
          id: h.id,
          tracking_id: prod.trackingId,
          price: typeof h.price === 'string' ? parseFloat(h.price) : h.price,
          note: h.note ?? null,
          recorded_at: h.recordedAt,
        }));

        app.logger.info({ tracking_id, count: mappedHistory.length }, 'Price history retrieved');
        return { history: mappedHistory };
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to get history');
        throw error;
      }
    }
  );

  // POST /api/products/upsert - Create or update product
  fastify.post<{
    Body: {
      product_url: string;
      product_name: string;
      platform: string;
      price: number;
      image_url?: string;
      store_name?: string;
      notes?: string;
      description?: string;
      brand?: string;
      category?: string;
    };
  }>(
    '/api/products/upsert',
    {
      schema: {
        description: 'Create a new product or update an existing one by URL',
        tags: ['products'],
        body: {
          type: 'object',
          required: ['product_url', 'product_name', 'platform', 'price'],
          properties: {
            product_url: { type: 'string' },
            product_name: { type: 'string' },
            platform: { type: 'string' },
            price: { type: 'number' },
            image_url: { type: 'string' },
            store_name: { type: 'string' },
            notes: { type: 'string' },
            description: { type: 'string' },
            brand: { type: 'string' },
            category: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Product updated',
            type: 'object',
            properties: {
              created: { type: 'boolean' },
              product: {
                type: 'object',
                properties: {
                  tracking_id: { type: 'string' },
                  product_name: { type: 'string' },
                  platform: { type: 'string' },
                  price: { type: 'number' },
                  previous_price: { type: ['number', 'null'] },
                  price_change: { type: 'string' },
                  product_url: { type: ['string', 'null'] },
                  image_url: { type: ['string', 'null'] },
                  store_name: { type: ['string', 'null'] },
                  notes: { type: ['string', 'null'] },
                  description: { type: ['string', 'null'] },
                  brand: { type: ['string', 'null'] },
                  category: { type: ['string', 'null'] },
                  created_at: { type: 'string', format: 'date-time' },
                  last_updated_at: { type: 'string', format: 'date-time' },
                },
              },
            },
          },
          201: {
            description: 'Product created',
            type: 'object',
            properties: {
              created: { type: 'boolean' },
              product: {
                type: 'object',
                properties: {
                  tracking_id: { type: 'string' },
                  product_name: { type: 'string' },
                  platform: { type: 'string' },
                  price: { type: 'number' },
                  previous_price: { type: ['number', 'null'] },
                  price_change: { type: 'string' },
                  product_url: { type: ['string', 'null'] },
                  image_url: { type: ['string', 'null'] },
                  store_name: { type: ['string', 'null'] },
                  notes: { type: ['string', 'null'] },
                  description: { type: ['string', 'null'] },
                  brand: { type: ['string', 'null'] },
                  category: { type: ['string', 'null'] },
                  created_at: { type: 'string', format: 'date-time' },
                  last_updated_at: { type: 'string', format: 'date-time' },
                },
              },
            },
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Body: {
          product_url: string;
          product_name: string;
          platform: string;
          price: number;
          image_url?: string;
          store_name?: string;
          notes?: string;
          description?: string;
          brand?: string;
          category?: string;
        };
      }>,
      reply: FastifyReply
    ) => {
      const { product_url, product_name, platform, price, image_url, store_name, notes, description, brand, category } =
        request.body;

      app.logger.info({ product_url, product_name, platform }, 'Upserting product');

      try {
        // Validate required fields
        if (!product_url || !product_name || !platform || price === undefined || price === null) {
          return reply.status(400).send({
            error: 'Missing required fields: product_url, product_name, platform, price',
          });
        }

        // Normalize URL
        const normalizedUrl = normalizeUrlForUpsert(product_url);

        // Map platform to enum
        const mappedPlatform = mapPlatformToEnum(platform);

        // Validate platform
        if (mappedPlatform === null) {
          return reply.status(400).send({
            error: 'Invalid platform. Must be one of: shopee, lazada, tokopedia, tiktok_shop, manual, other',
          });
        }

        // Check if product exists
        const existingProduct = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.url, normalizedUrl))
          .limit(1);

        if (existingProduct.length > 0) {
          // UPDATE PATH
          const prod = existingProduct[0];
          const oldPrice = typeof prod.currentPrice === 'string'
            ? parseFloat(prod.currentPrice)
            : prod.currentPrice;

          // Build update object
          const updateData: Record<string, any> = {
            name: product_name,
            lastUpdatedAt: sql`now()`,
          };

          if (image_url) {
            updateData.imageUrl = image_url;
          }
          if (store_name) {
            updateData.storeName = store_name;
          }
          if (notes) {
            updateData.notes = notes;
          }
          if (description) {
            updateData.description = description;
          }
          if (brand) {
            updateData.brand = brand;
          }
          if (category) {
            updateData.category = category;
          }

          // Handle price change
          if (price !== oldPrice) {
            // Insert price history record with old price
            await app.db.insert(schema.priceHistory).values({
              trackedProductId: prod.id,
              price: oldPrice.toString(),
              note: 'price update',
              recordedAt: sql`now()`,
            });

            // Update price fields
            updateData.previousPrice = oldPrice.toString();
            updateData.currentPrice = price.toString();
          }

          // Update product
          await app.db
            .update(schema.trackedProducts)
            .set(updateData)
            .where(eq(schema.trackedProducts.id, prod.id));

          // Fetch updated product
          const updated = await app.db
            .select()
            .from(schema.trackedProducts)
            .where(eq(schema.trackedProducts.id, prod.id))
            .limit(1);

          app.logger.info({ trackingId: prod.trackingId }, 'Product updated');
          return {
            created: false,
            product: toProduct(updated[0]),
          };
        } else {
          // INSERT PATH
          const trackingId = await getNextTrackingId(app);

          // Fetch metadata for enrichment
          let metaData = null;
          if (normalizedUrl) {
            try {
              metaData = await fetchMetaForUrl(normalizedUrl, 10000, app.logger);

              if (metaData && (metaData.title || metaData.brand || metaData.category)) {
                app.logger.info({
                  url: normalizedUrl,
                  title: metaData.title,
                  brand: metaData.brand,
                  category: metaData.category
                }, '[Upsert] Meta enrichment for URL');
              }
            } catch (metaError) {
              app.logger.warn({ err: metaError, url: normalizedUrl }, '[Upsert] Meta enrichment failed, proceeding without meta');
            }
          }

          // Use meta results as defaults — only fill fields NOT already provided
          const enrichedProductName = product_name || (metaData?.title || null);
          const enrichedImageUrl = image_url || (metaData?.image || null);
          const enrichedDescription = description || (metaData?.description || null);
          const enrichedBrand = brand || (metaData?.brand || null);
          const enrichedCategory = category || (metaData?.category || null);
          const enrichedPlatform = (mappedPlatform && mappedPlatform !== 'other')
            ? mappedPlatform
            : (metaData?.platform?.toLowerCase() as any || 'other');

          await app.db
            .insert(schema.trackedProducts)
            .values({
              trackingId,
              name: enrichedProductName || 'Untitled Product',
              url: normalizedUrl,
              platform: enrichedPlatform,
              imageUrl: enrichedImageUrl,
              currentPrice: price.toString(),
              originalPrice: price.toString(),
              previousPrice: null,
              currency: 'VND',
              inStock: true,
              storeName: store_name || null,
              notes: notes || null,
              description: enrichedDescription,
              brand: enrichedBrand,
              category: enrichedCategory,
              checkIntervalMinutes: 60,
              fetchErrorCount: 0,
              lastFetchError: null,
              lastUpdatedAt: sql`now()`,
              createdAt: sql`now()`,
            });

          app.logger.debug({ trackingId, product_name: enrichedProductName }, 'Inserted product in upsert');

          // Re-fetch the inserted product
          const refetched = await app.db
            .select()
            .from(schema.trackedProducts)
            .where(eq(schema.trackedProducts.trackingId, trackingId))
            .limit(1);

          if (!refetched || refetched.length === 0) {
            app.logger.error({ trackingId, product_name }, 'Failed to refetch inserted product');
            return reply.status(500).send({ error: 'Failed to create product' });
          }

          const insertedProduct = refetched[0];
          app.logger.debug({
            id: insertedProduct.id,
            trackingId: insertedProduct.trackingId,
            name: insertedProduct.name,
            nameType: typeof insertedProduct.name,
            hasName: 'name' in insertedProduct
          }, 'Product refetch details for upsert insert');

          // Insert initial price history
          await app.db.insert(schema.priceHistory).values({
            trackedProductId: insertedProduct.id,
            price: price.toString(),
            note: 'Initial price',
            recordedAt: sql`now()`,
          });

          const mapped = toProduct(insertedProduct);
          app.logger.info({ trackingId, productId: insertedProduct.id, product_name: mapped.product_name }, 'Product created');
          reply.status(201);
          return {
            created: true,
            product: mapped,
          };
        }
      } catch (error) {
        app.logger.error({ err: error, product_url, product_name }, 'Failed to upsert product');
        throw error;
      }
    }
  );

  // GET /api/products/:tracking_id/compare - Get price comparisons
  fastify.get<{
    Params: { tracking_id: string };
  }>(
    '/api/products/:tracking_id/compare',
    {
      schema: {
        description: 'Get price comparisons for a product across platforms',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Price comparisons',
            type: 'object',
            properties: {
              comparisons: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    store: { type: 'string' },
                    price: { type: 'number' },
                    currency: { type: 'string' },
                    url: { type: ['string', 'null'] },
                    is_current: { type: 'boolean' },
                    is_best_price: { type: 'boolean' },
                  },
                },
              },
              cached: { type: 'boolean' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { tracking_id: string } }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;

      app.logger.info({ tracking_id }, 'Getting price comparisons');

      try {
        // Query product by tracking_id
        const products = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (products.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found for comparison');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const product = products[0];

        // Build current product entry
        const platformDisplay = getPlatformDisplayName(product.platform);
        const currentEntry: ComparisonEntry = {
          store: platformDisplay,
          price: Number(product.currentPrice),
          currency: 'VND',
          url: product.url ?? null,
          is_current: true,
          is_best_price: false,
        };

        // Check cache
        const cached = comparisonCache.get(tracking_id);
        if (cached && cached.expiresAt > Date.now()) {
          app.logger.info({ tracking_id }, 'Price comparison cache hit');
          return {
            comparisons: cached.data,
            cached: true,
          };
        }

        // Call AI for price comparisons (with 15-second timeout)
        let aiEntries: ComparisonEntry[] = [];
        try {
          const prompt = `You are a price comparison assistant for Vietnamese e-commerce.

Product: "${product.name}"
Current platform: ${product.platform}
Current price: ${Number(product.currentPrice)} VND

Generate realistic price comparison data for this product across these platforms: Shopee, Lazada, TikTok Shop, Amazon, eBay.
Exclude the current platform (${product.platform}) from the list — it will be shown separately.

Return a JSON array of objects. Each object must have:
- "store": store name (string)
- "price": price in VND as a number (realistic variation ±5-20% from current price)
- "currency": "VND"
- "url": a plausible (but not necessarily real) search URL for this product on that store

Return ONLY the JSON array, no markdown, no explanation.
Example: [{"store":"Lazada","price":450000,"currency":"VND","url":"https://www.lazada.vn/catalog/?q=..."}]`;

          const response = await generateText({
            model: google('gemini-2.0-flash'),
            prompt,
            temperature: 0.7,
            timeout: 15000, // 15-second timeout
          });

          // Parse AI response, stripping markdown code fences
          let jsonText = response.text.trim();
          if (jsonText.startsWith('```json')) {
            jsonText = jsonText.slice(7);
          }
          if (jsonText.startsWith('```')) {
            jsonText = jsonText.slice(3);
          }
          if (jsonText.endsWith('```')) {
            jsonText = jsonText.slice(0, -3);
          }
          jsonText = jsonText.trim();

          const parsed = JSON.parse(jsonText);
          if (Array.isArray(parsed)) {
            aiEntries = parsed.map((entry: any) => ({
              store: entry.store || 'Unknown',
              price: Number(entry.price) || 0,
              currency: entry.currency || 'VND',
              url: entry.url || null,
              is_current: false,
              is_best_price: false,
            }));
          }
        } catch (aiError) {
          app.logger.warn(
            { err: aiError, tracking_id },
            'AI comparison failed, using fallback'
          );
          // Use empty array as fallback
          aiEntries = [];
        }

        // Build full list with current entry
        const comparisons: ComparisonEntry[] = [currentEntry, ...aiEntries];

        // Find best price and set is_best_price
        let bestPriceIndex = 0;
        let lowestPrice = comparisons[0].price;
        for (let i = 1; i < comparisons.length; i++) {
          if (comparisons[i].price < lowestPrice) {
            lowestPrice = comparisons[i].price;
            bestPriceIndex = i;
          }
        }
        comparisons[bestPriceIndex].is_best_price = true;

        // Cache the results (10 minutes)
        comparisonCache.set(tracking_id, {
          data: comparisons,
          expiresAt: Date.now() + 10 * 60 * 1000,
        });

        app.logger.info(
          { tracking_id, comparisonCount: comparisons.length },
          'Price comparisons retrieved successfully'
        );

        return {
          comparisons,
          cached: false,
        };
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to get price comparisons');
        throw error;
      }
    }
  );

  // POST /api/products/:tracking_id/refresh - Refresh product metadata from URL
  fastify.post<{
    Params: { tracking_id: string };
  }>(
    '/api/products/:tracking_id/refresh',
    {
      schema: {
        description: 'Refresh product metadata from its URL',
        tags: ['products'],
        params: {
          type: 'object',
          required: ['tracking_id'],
          properties: {
            tracking_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Metadata refresh result',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
              message: { type: 'string' },
              product: {
                type: ['object', 'null'],
                properties: {
                  tracking_id: { type: 'string' },
                  product_name: { type: 'string' },
                  platform: { type: 'string' },
                  price: { type: 'number' },
                  previous_price: { type: ['number', 'null'] },
                  price_change: { type: 'string' },
                  product_url: { type: ['string', 'null'] },
                  image_url: { type: ['string', 'null'] },
                  store_name: { type: ['string', 'null'] },
                  notes: { type: ['string', 'null'] },
                  description: { type: ['string', 'null'] },
                  brand: { type: ['string', 'null'] },
                  category: { type: ['string', 'null'] },
                  created_at: { type: 'string', format: 'date-time' },
                  last_updated_at: { type: 'string', format: 'date-time' },
                },
              },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { tracking_id: string } }>,
      reply: FastifyReply
    ) => {
      const { tracking_id } = request.params;

      app.logger.info({ tracking_id }, 'Refreshing product metadata');

      try {
        // Look up product by tracking_id
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.trackingId, tracking_id))
          .limit(1);

        if (product.length === 0) {
          app.logger.warn({ tracking_id }, 'Product not found for refresh');
          return reply.status(404).send({ error: 'Product not found' });
        }

        const prod = product[0];

        // Check if product has a URL
        if (!prod.url) {
          app.logger.info({ tracking_id }, 'Product has no URL for refresh');
          return {
            success: false,
            message: 'No URL stored for this product',
          };
        }

        // Fetch metadata with 15-second timeout
        let metaData = null;
        try {
          metaData = await fetchMetaForUrl(prod.url, 15000, app.logger);
        } catch (fetchError) {
          app.logger.warn(
            { err: fetchError, tracking_id, url: prod.url },
            '[Refresh] Failed to fetch metadata'
          );
          // Even on fetch error, still update last_updated_at and return success
          // since the refresh attempt was made
        }

        // Build update object with only non-empty values
        const updateData: Record<string, any> = {
          lastUpdatedAt: sql`now()`,
        };

        if (metaData?.title) updateData.name = metaData.title;
        if (metaData?.image) updateData.imageUrl = metaData.image;
        if (metaData?.description) updateData.description = metaData.description;
        if (metaData?.brand) updateData.brand = metaData.brand;
        if (metaData?.category) updateData.category = metaData.category;

        // Update product
        await app.db
          .update(schema.trackedProducts)
          .set(updateData)
          .where(eq(schema.trackedProducts.id, prod.id));

        // Fetch updated product
        const updated = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, prod.id))
          .limit(1);

        app.logger.info(
          {
            trackingId: tracking_id,
            brand: metaData?.brand,
            category: metaData?.category,
          },
          '[Refresh] Product metadata updated'
        );

        return {
          success: true,
          message: 'Product metadata refreshed successfully',
          product: toProduct(updated[0]),
        };
      } catch (error) {
        app.logger.error({ err: error, tracking_id }, 'Failed to refresh product metadata');
        return {
          success: false,
          message: 'Could not fetch product data. The page may have changed.',
        };
      }
    }
  );
}
