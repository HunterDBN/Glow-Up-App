import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import type { App } from '../index.js';
import { generateText } from 'ai';
import { google } from '@ai-sdk/google';

interface MetaResponse {
  title: string | null;
  image: string | null;
  site_name: string | null;
  description: string | null;
  brand: string | null;
  category: string | null;
  platform: string;
}

interface OpenGraphResponse {
  name: string | null;
  image: string | null;
  description: string | null;
  brand: string | null;
}

interface CacheEntry {
  data: OpenGraphResponse;
  expiresAt: number;
}

const FALLBACK_RESPONSE: MetaResponse = {
  title: null,
  image: null,
  site_name: null,
  description: null,
  brand: null,
  category: null,
  platform: 'Other',
};

const OPENGRAPH_FALLBACK: OpenGraphResponse = {
  name: null,
  image: null,
  description: null,
  brand: null,
};

// In-memory cache for OpenGraph.io responses (5 minute TTL)
const ogCache = new Map<string, CacheEntry>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes in milliseconds

function detectPlatform(urlString: string): string {
  try {
    const url = new URL(urlString);
    const hostname = url.hostname.toLowerCase();

    if (hostname.includes('shopee')) return 'Shopee';
    if (hostname.includes('lazada')) return 'Lazada';
    if (hostname.includes('tiktok')) return 'TikTok Shop';
    return 'Other';
  } catch {
    return 'Other';
  }
}

function extractMetaContent(html: string, property: string): string | null {
  // Try og: property first
  const ogRegex = new RegExp(`<meta\\s+property=["']og:${property}["']\\s+content=["']([^"']+)["']`, 'i');
  const ogMatch = html.match(ogRegex);
  if (ogMatch && ogMatch[1]) {
    return ogMatch[1];
  }

  // Try name attribute
  const nameRegex = new RegExp(`<meta\\s+name=["']${property}["']\\s+content=["']([^"']+)["']`, 'i');
  const nameMatch = html.match(nameRegex);
  if (nameMatch && nameMatch[1]) {
    return nameMatch[1];
  }

  return null;
}

function extractBrand(html: string): string | null {
  // Try product:brand
  let match = html.match(/<meta\s+property=["']product:brand["']\s+content=["']([^"']+)["']/i);
  if (match && match[1]) return match[1];

  // Try name="brand"
  match = html.match(/<meta\s+name=["']brand["']\s+content=["']([^"']+)["']/i);
  if (match && match[1]) return match[1];

  // Try JSON-LD brand.name
  const jsonLdMatch = html.match(/"brand"\s*:\s*{"name"\s*:\s*"([^"]+)"}/i);
  if (jsonLdMatch && jsonLdMatch[1]) return jsonLdMatch[1];

  return null;
}

function extractCategory(html: string): string | null {
  // Try product:category
  let match = html.match(/<meta\s+property=["']product:category["']\s+content=["']([^"']+)["']/i);
  if (match && match[1]) return match[1];

  // Try JSON-LD category
  match = html.match(/"category"\s*:\s*"([^"]+)"/i);
  if (match && match[1]) return match[1];

  // Try og:type for category hints
  const ogType = extractMetaContent(html, 'type');
  if (ogType && ogType !== 'website') return ogType;

  return null;
}

function extractTitle(html: string): string | null {
  // Try og:title first
  const ogTitle = extractMetaContent(html, 'title');
  if (ogTitle) return ogTitle;

  // Fallback to <title> tag
  const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
  if (titleMatch && titleMatch[1]) {
    return titleMatch[1].trim();
  }

  return null;
}

/**
 * Fetch and extract metadata from a URL with AI enrichment
 * Returns timeout-resistant result (never throws, always returns object)
 */
export async function fetchMetaForUrl(
  url: string,
  timeoutMs: number = 8000,
  logger?: any
): Promise<MetaResponse> {
  try {
    // Validate URL format
    new URL(url);
  } catch {
    logger?.warn({ url }, 'Invalid URL format');
    return FALLBACK_RESPONSE;
  }

  try {
    // Fetch URL with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    let redirectCount = 0;
    let currentUrl = url;
    let response: Response | null = null;

    // Follow redirects up to 3 hops
    while (redirectCount <= 3) {
      try {
        response = await fetch(currentUrl, {
          method: 'GET',
          headers: {
            'User-Agent':
              'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
            'Accept': 'text/html',
          },
          signal: controller.signal,
          redirect: 'follow',
        });

        if (response.ok) {
          break;
        }

        // Check for redirect response codes
        if ([301, 302, 303, 307, 308].includes(response.status)) {
          const location = response.headers.get('location');
          if (location) {
            currentUrl = location;
            redirectCount++;
            continue;
          }
        }

        break;
      } catch (error) {
        clearTimeout(timeoutId);
        logger?.warn({ err: error, url: currentUrl }, 'Failed to fetch URL');
        return FALLBACK_RESPONSE;
      }
    }

    clearTimeout(timeoutId);

    if (!response || !response.ok) {
      logger?.warn({ url, status: response?.status }, 'Failed to fetch URL');
      return FALLBACK_RESPONSE;
    }

    const html = await response.text();

    // Extract metadata
    const title = extractTitle(html);
    const image = extractMetaContent(html, 'image');
    const site_name = extractMetaContent(html, 'site_name');
    let description = extractMetaContent(html, 'description');
    let brand = extractBrand(html);
    let category = extractCategory(html);
    const platform = detectPlatform(url);

    // If brand or category are missing, call Gemini
    if (!brand || !category) {
      try {
        const aiResponse = await generateText({
          model: google('gemini-2.0-flash'),
          prompt: `Product title: "${title}"
Site: "${site_name}"

Return JSON: { "brand": "...", "category": "..." }
Brand should be the manufacturer/brand name (e.g. "Nike", "Apple", "Samsung"). If unknown, return null.
Category should be a short product category label (e.g. "Trainers", "Smartphone", "Skincare", "Jacket"). If unknown, return null.
Return ONLY the JSON object.`,
          temperature: 0.3,
          timeout: 5000,
        });

        try {
          const parsed = JSON.parse(aiResponse.text);
          if (!brand && parsed.brand) brand = parsed.brand;
          if (!category && parsed.category) category = parsed.category;
        } catch (parseError) {
          logger?.warn({ err: parseError }, 'Failed to parse Gemini response for brand/category');
        }
      } catch (aiError) {
        logger?.warn({ err: aiError }, 'Gemini call failed for brand/category');
      }
    }

    // If description is missing, optionally call Gemini (or keep as null)
    if (!description && title) {
      try {
        const descResponse = await generateText({
          model: google('gemini-2.0-flash'),
          prompt: `Write a 2-3 sentence product description for: "${title}"
Be concise and factual. Return ONLY the description text, no quotes.`,
          temperature: 0.3,
          timeout: 5000,
        });
        description = descResponse.text.trim();
      } catch (aiError) {
        logger?.warn({ err: aiError }, 'Gemini call failed for description');
      }
    }

    const result: MetaResponse = {
      title,
      image,
      site_name,
      description,
      brand,
      category,
      platform,
    };

    logger?.info({ url, platform, brand, category }, 'Metadata extracted successfully');
    return result;
  } catch (error) {
    logger?.warn({ err: error, url }, 'Failed to fetch metadata');
    return FALLBACK_RESPONSE;
  }
}

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/meta - Extract metadata from URL
  fastify.get<{
    Querystring: { url?: string };
  }>(
    '/api/meta',
    {
      schema: {
        description: 'Extract metadata from a URL',
        tags: ['meta'],
        querystring: {
          type: 'object',
          required: ['url'],
          properties: {
            url: { type: 'string', description: 'URL to fetch metadata from' },
          },
        },
        response: {
          200: {
            description: 'Metadata extracted successfully',
            type: 'object',
            properties: {
              title: { type: ['string', 'null'] },
              image: { type: ['string', 'null'] },
              site_name: { type: ['string', 'null'] },
              description: { type: ['string', 'null'] },
              brand: { type: ['string', 'null'] },
              category: { type: ['string', 'null'] },
              platform: { type: 'string' },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Querystring: { url?: string } }>,
      reply: FastifyReply
    ) => {
      const { url } = request.query;

      app.logger.info({ url }, 'Fetching metadata');

      if (!url) {
        return reply.status(400).send({ error: 'url is required' });
      }

      const result = await fetchMetaForUrl(url, 8000, app.logger);
      return result;
    }
  );

  // GET /api/meta/opengraph - OpenGraph.io proxy with caching
  fastify.get<{
    Querystring: { url?: string };
  }>(
    '/api/meta/opengraph',
    {
      schema: {
        description: 'Extract metadata from URL via OpenGraph.io',
        tags: ['meta'],
        querystring: {
          type: 'object',
          required: ['url'],
          properties: {
            url: { type: 'string', description: 'URL to fetch metadata from' },
          },
        },
        response: {
          200: {
            description: 'Metadata extracted successfully',
            type: 'object',
            properties: {
              name: { type: ['string', 'null'] },
              image: { type: ['string', 'null'] },
              description: { type: ['string', 'null'] },
              brand: { type: ['string', 'null'] },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Querystring: { url?: string } }>,
      reply: FastifyReply
    ) => {
      const { url } = request.query;

      app.logger.info({ url }, 'Fetching OpenGraph metadata');

      if (!url) {
        return reply.status(400).send({ error: 'url is required' });
      }

      // Check cache
      const cached = ogCache.get(url);
      if (cached && cached.expiresAt > Date.now()) {
        app.logger.info({ url }, 'OpenGraph metadata cache hit');
        return cached.data;
      }

      try {
        // Call OpenGraph.io API
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10-second timeout

        const response = await fetch(
          `https://opengraph.io/api/1.1/site/${encodeURIComponent(url)}?app_id=02541231-7815-49d1-a0a5-32ba1d359c24`,
          {
            method: 'GET',
            signal: controller.signal,
          }
        );

        clearTimeout(timeoutId);

        if (!response.ok) {
          app.logger.warn({ url, status: response.status }, 'OpenGraph.io returned non-200 status');
          // Cache the fallback for 5 minutes
          ogCache.set(url, {
            data: OPENGRAPH_FALLBACK,
            expiresAt: Date.now() + CACHE_TTL,
          });
          return OPENGRAPH_FALLBACK;
        }

        const json = await response.json() as any;

        // Extract data from hybridGraph
        const hybridGraph = json?.hybridGraph || {};
        const result: OpenGraphResponse = {
          name: hybridGraph.title || null,
          image: hybridGraph.image || null,
          description: hybridGraph.description || null,
          brand: hybridGraph.site_name || null,
        };

        // Cache the result
        ogCache.set(url, {
          data: result,
          expiresAt: Date.now() + CACHE_TTL,
        });

        app.logger.info({ url, brand: result.brand }, 'OpenGraph metadata fetched successfully');
        return result;
      } catch (error) {
        app.logger.warn({ err: error, url }, 'Failed to fetch OpenGraph metadata');
        // Cache the fallback for 5 minutes
        ogCache.set(url, {
          data: OPENGRAPH_FALLBACK,
          expiresAt: Date.now() + CACHE_TTL,
        });
        return OPENGRAPH_FALLBACK;
      }
    }
  );
}
