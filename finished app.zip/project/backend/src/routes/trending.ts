import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';
import { sql, desc } from 'drizzle-orm';

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/trending - Get top 10 trending products
  fastify.get(
    '/api/trending',
    {
      schema: {
        description: 'Get top trending products based on views and alerts in last 7 days',
        tags: ['trending'],
        response: {
          200: {
            description: 'List of trending products',
            type: 'object',
            properties: {
              trending: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    name: { type: 'string' },
                    url: { type: 'string' },
                    platform: { type: 'string' },
                    image_url: { type: 'string' },
                    current_price: { type: 'number' },
                    original_price: { type: 'number' },
                    currency: { type: 'string' },
                    in_stock: { type: 'boolean' },
                    view_count: { type: 'integer' },
                    alert_count: { type: 'integer' },
                  },
                },
              },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      app.logger.info('Getting trending products');

      try {
        const results = (await app.db.execute(sql`
          SELECT
            tp.id,
            tp.name,
            tp.url,
            tp.platform,
            tp.image_url,
            tp.current_price,
            tp.original_price,
            tp.currency,
            tp.in_stock,
            COALESCE(v.view_count, 0) AS view_count,
            COALESCE(a.alert_count, 0) AS alert_count
          FROM tracked_products tp
          LEFT JOIN (
            SELECT tracked_product_id, COUNT(*) AS view_count
            FROM product_views
            WHERE viewed_at > now() - interval '7 days'
            GROUP BY tracked_product_id
          ) v ON v.tracked_product_id = tp.id
          LEFT JOIN (
            SELECT tracked_product_id, COUNT(*) AS alert_count
            FROM alerts
            WHERE created_at > now() - interval '7 days'
            GROUP BY tracked_product_id
          ) a ON a.tracked_product_id = tp.id
          WHERE tp.in_stock = true
          ORDER BY (COALESCE(v.view_count, 0) + COALESCE(a.alert_count, 0)) DESC, tp.created_at DESC
          LIMIT 20
        `) as any[]) || [];

        const trending = results.map((row: any) => {
          return {
            id: row.id,
            name: row.name,
            url: row.url,
            platform: row.platform,
            image_url: row.image_url,
            current_price: parseFloat(row.current_price),
            original_price: parseFloat(row.original_price),
            currency: row.currency,
            in_stock: row.in_stock,
            view_count: parseInt(row.view_count),
            alert_count: parseInt(row.alert_count),
          };
        });

        app.logger.info(
          { count: trending.length },
          'Trending products retrieved successfully'
        );
        return { trending };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to get trending products');
        throw error;
      }
    }
  );
}
