import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc, ilike, and, or } from 'drizzle-orm';
import { sql } from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';

interface UpdateProfileBody {
  name?: string;
  username?: string;
  bio?: string;
  profile_photo?: string;
  glow_areas?: string;
  instagram_url?: string;
  tiktok_url?: string;
  pinterest_url?: string;
  youtube_url?: string;
}

interface CreatePostBody {
  content: string;
  image_url?: string;
  category: string;
}

interface CreateCommentBody {
  comment_text: string;
}

interface ListPostsQuery {
  category?: string;
  search?: string;
}

interface ListChallengesQuery {
  category?: string;
}

interface LogChallengeBody {
  day_number: number;
  note?: string;
  photo_url?: string;
}

interface CreateJournalBody {
  prompt: string;
  response: string;
  mood: string;
}

const JOURNAL_PROMPTS = [
  'What does your ideal day look like, and what is one small step you can take toward it today?',
  'Write about a moment this week when you felt truly yourself.',
  'What is one thing you are proud of that you have never told anyone?',
  'Describe the version of yourself you are becoming.',
  'What habit, if you started today, would change your life in a year?',
  'Write a love letter to your body.',
  'What are you holding onto that no longer serves you?',
  'Who inspires you most and what qualities of theirs do you want to cultivate?',
  'What does success look like to you — not anyone else, just you?',
  'Write about a challenge you overcame and what it taught you.',
  'What boundaries do you need to set to protect your peace?',
  'Describe your perfect morning routine and why it matters to you.',
  'What is one fear you want to face this month?',
  'Write about a woman who has shaped who you are.',
  'What does self-care mean to you beyond bubble baths and face masks?',
  'What are three things you want to feel more of in your life?',
  'Write about a time you chose yourself. How did it feel?',
  'What story are you telling yourself that might not be true?',
  'What would you do if you knew you could not fail?',
  'Describe your relationship with rest. Do you allow yourself to slow down?',
  'What are you most grateful for right now, in this exact season of life?',
  'Write about a goal you have been putting off. What is really stopping you?',
  'How do you want people to feel when they are around you?',
  'What does your inner critic say most often? What would your inner champion say instead?',
  'Write about a time you surprised yourself.',
  'What does your dream life look like five years from now?',
  'What is one thing you can forgive yourself for today?',
  'How have you grown in the past year?',
  'What makes you feel most alive?',
  'Write a message to your future self.',
];

export function register(app: App, fastify: FastifyInstance) {
  const requireAuth = app.requireAuth();

  // ==================== PROFILES ====================

  // GET /api/gu/profile - Get current user's profile
  fastify.get(
    '/api/gu/profile',
    {
      schema: {
        description: 'Get current user profile',
        tags: ['glowup-profile'],
        response: {
          200: {
            type: 'object',
            properties: {
              profile: { type: 'object' },
            },
          },
          401: { type: 'object', properties: { error: { type: 'string' } } },
          404: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;
      app.logger.info({ userId }, 'Getting user profile');

      try {
        // Query gu_profiles with a raw select from the user table
        const profileResult = await app.db.execute(sql`
          SELECT p.id, p.user_id, p.username, p.bio, p.profile_photo, p.glow_areas,
                 p.instagram_url, p.tiktok_url, p.pinterest_url, p.youtube_url,
                 p.is_premium, p.joined_at, u.name, u.email
          FROM gu_profiles p
          JOIN "user" u ON u.id = p.user_id
          WHERE p.user_id = ${userId}
        `);

        const rows = (profileResult as any).rows;
        if (!rows || rows.length === 0) {
          return reply.status(404).send({ error: 'Profile not found' });
        }

        app.logger.info({ userId }, 'Profile retrieved');
        return { profile: rows[0] };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to get profile');
        throw error;
      }
    }
  );

  // PUT /api/gu/profile - Update current user's profile
  fastify.put<{ Body: UpdateProfileBody }>(
    '/api/gu/profile',
    {
      schema: {
        description: 'Update user profile',
        tags: ['glowup-profile'],
        body: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            username: { type: 'string' },
            bio: { type: 'string' },
            profile_photo: { type: 'string' },
            glow_areas: { type: 'string' },
            instagram_url: { type: 'string' },
            tiktok_url: { type: 'string' },
            pinterest_url: { type: 'string' },
            youtube_url: { type: 'string' },
          },
        },
        response: {
          200: { type: 'object', properties: { profile: { type: 'object' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Body: UpdateProfileBody }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;
      const {
        name,
        username,
        bio,
        profile_photo,
        glow_areas,
        instagram_url,
        tiktok_url,
        pinterest_url,
        youtube_url,
      } = request.body as UpdateProfileBody;

      app.logger.info({ userId }, 'Updating profile');

      try {
        // Step 1: If name is provided, update the user table
        if (name !== undefined) {
          await app.db.execute(
            sql`UPDATE "user" SET name = ${name}, updated_at = now() WHERE id = ${userId}`
          );
        }

        // Step 2: Always update gu_profiles using COALESCE for optional fields
        await app.db.execute(sql`
          UPDATE gu_profiles
          SET
            username = COALESCE(${username || null}, username),
            bio = COALESCE(${bio || null}, bio),
            profile_photo = COALESCE(${profile_photo || null}, profile_photo),
            glow_areas = COALESCE(${glow_areas || null}, glow_areas),
            instagram_url = COALESCE(${instagram_url || null}, instagram_url),
            tiktok_url = COALESCE(${tiktok_url || null}, tiktok_url),
            pinterest_url = COALESCE(${pinterest_url || null}, pinterest_url),
            youtube_url = COALESCE(${youtube_url || null}, youtube_url)
          WHERE user_id = ${userId}
        `);

        // Step 3: Select the full profile joined with user
        const profileResult = await app.db.execute(sql`
          SELECT p.id, p.user_id, p.username, p.bio, p.profile_photo, p.glow_areas,
                 p.instagram_url, p.tiktok_url, p.pinterest_url, p.youtube_url,
                 p.is_premium, p.joined_at, u.name, u.email
          FROM gu_profiles p
          JOIN "user" u ON u.id = p.user_id
          WHERE p.user_id = ${userId}
        `);

        const rows = (profileResult as any).rows;
        if (!rows || rows.length === 0) {
          return reply.status(404).send({ error: 'Profile not found' });
        }

        app.logger.info({ userId }, 'Profile updated');
        return { profile: rows[0] };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to update profile');
        throw error;
      }
    }
  );

  // GET /api/gu/profile/:user_id - Get public profile
  fastify.get<{ Params: { user_id: string } }>(
    '/api/gu/profile/:user_id',
    {
      schema: {
        description: 'Get public user profile',
        tags: ['glowup-profile'],
        params: {
          type: 'object',
          required: ['user_id'],
          properties: { user_id: { type: 'string' } },
        },
        response: {
          200: { type: 'object', properties: { profile: { type: 'object' } } },
          404: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { user_id: string } }>, reply: FastifyReply) => {
      const { user_id } = request.params;
      app.logger.info({ userId: user_id }, 'Getting public profile');

      try {
        const profile = await app.db
          .select()
          .from(schema.guProfiles)
          .where(eq(schema.guProfiles.userId, user_id))
          .limit(1);

        if (profile.length === 0) {
          return reply.status(404).send({ error: 'Profile not found' });
        }

        return { profile: profile[0] };
      } catch (error) {
        app.logger.error({ err: error, userId: user_id }, 'Failed to get public profile');
        throw error;
      }
    }
  );

  // ==================== POSTS ====================

  // GET /api/gu/posts - List posts
  fastify.get<{ Querystring: ListPostsQuery }>(
    '/api/gu/posts',
    {
      schema: {
        description: 'List posts',
        tags: ['glowup-posts'],
        querystring: {
          type: 'object',
          properties: {
            category: { type: 'string' },
            search: { type: 'string' },
          },
        },
        response: {
          200: { type: 'object', properties: { posts: { type: 'array', items: { type: 'object' } } } },
        },
      },
    },
    async (request: FastifyRequest<{ Querystring: ListPostsQuery }>, reply: FastifyReply) => {
      const { category, search } = request.query as ListPostsQuery;
      const session = await (app.auth?.api.getSession({ headers: request.headers as any }) as any);

      app.logger.info({ category, search }, 'Listing posts');

      try {
        let query = app.db
          .select({
            id: schema.guPosts.id,
            userId: schema.guPosts.userId,
            content: schema.guPosts.content,
            imageUrl: schema.guPosts.imageUrl,
            category: schema.guPosts.category,
            likesCount: schema.guPosts.likesCount,
            commentsCount: schema.guPosts.commentsCount,
            createdAt: schema.guPosts.createdAt,
            author: {
              username: schema.guProfiles.username,
              profilePhoto: schema.guProfiles.profilePhoto,
            },
          })
          .from(schema.guPosts)
          .innerJoin(schema.guProfiles, eq(schema.guPosts.userId, schema.guProfiles.userId));

        const conditions = [];
        if (category) {
          conditions.push(eq(schema.guPosts.category, category as any));
        }
        if (search) {
          conditions.push(ilike(schema.guPosts.content, `%${search}%`));
        }

        if (conditions.length > 0) {
          query = query.where(and(...(conditions as any))) as any;
        }

        const posts = await query.orderBy(desc(schema.guPosts.createdAt));

        // Add is_liked and is_saved for authenticated users
        const enrichedPosts = await Promise.all(
          posts.map(async (post: any) => {
            const isLiked = session && session.user
              ? (await app.db
                  .select()
                  .from(schema.guLikes)
                  .where(
                    and(
                      eq(schema.guLikes.postId, post.id),
                      eq(schema.guLikes.userId, session.user.id)
                    )
                  )
                  .limit(1)).length > 0
              : false;

            const isSaved = session && session.user
              ? (await app.db
                  .select()
                  .from(schema.guSavedPosts)
                  .where(
                    and(
                      eq(schema.guSavedPosts.postId, post.id),
                      eq(schema.guSavedPosts.userId, session.user.id)
                    )
                  )
                  .limit(1)).length > 0
              : false;

            return {
              ...post,
              is_liked: isLiked,
              is_saved: isSaved,
            };
          })
        );

        app.logger.info({ count: enrichedPosts.length }, 'Posts retrieved');
        return { posts: enrichedPosts };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to list posts');
        throw error;
      }
    }
  );

  // POST /api/gu/posts - Create post
  fastify.post<{ Body: CreatePostBody }>(
    '/api/gu/posts',
    {
      schema: {
        description: 'Create post',
        tags: ['glowup-posts'],
        body: {
          type: 'object',
          required: ['content', 'category'],
          properties: {
            content: { type: 'string' },
            image_url: { type: 'string' },
            category: { type: 'string' },
          },
        },
        response: {
          201: { type: 'object', properties: { post: { type: 'object' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Body: CreatePostBody }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;
      const { content, image_url, category } = request.body as CreatePostBody;

      app.logger.info({ userId, category }, 'Creating post');

      try {
        const created = await app.db
          .insert(schema.guPosts)
          .values({
            userId,
            content,
            imageUrl: image_url || '',
            category: category as any,
          })
          .returning();

        reply.status(201);
        app.logger.info({ postId: created[0].id, userId }, 'Post created');
        return { post: created[0] };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to create post');
        throw error;
      }
    }
  );

  // DELETE /api/gu/posts/:id - Delete post
  fastify.delete<{ Params: { id: string } }>(
    '/api/gu/posts/:id',
    {
      schema: {
        description: 'Delete post',
        tags: ['glowup-posts'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: { type: 'object', properties: { success: { type: 'boolean' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
          404: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const { id } = request.params;
      const userId = session.user.id;

      app.logger.info({ postId: id, userId }, 'Deleting post');

      try {
        const post = await app.db
          .select()
          .from(schema.guPosts)
          .where(eq(schema.guPosts.id, id as any))
          .limit(1);

        if (post.length === 0) {
          return reply.status(404).send({ error: 'Post not found' });
        }

        if (post[0].userId !== userId) {
          return reply.status(404).send({ error: 'Post not found' });
        }

        await app.db.delete(schema.guPosts).where(eq(schema.guPosts.id, id as any));

        app.logger.info({ postId: id }, 'Post deleted');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, postId: id }, 'Failed to delete post');
        throw error;
      }
    }
  );

  // GET /api/gu/posts/:id - Get single post
  fastify.get<{ Params: { id: string } }>(
    '/api/gu/posts/:id',
    {
      schema: {
        description: 'Get single post with comments',
        tags: ['glowup-posts'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: {
            type: 'object',
            properties: {
              post: { type: 'object' },
              comments: { type: 'array', items: { type: 'object' } },
            },
          },
          404: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const { id } = request.params;

      app.logger.info({ postId: id }, 'Getting post');

      try {
        const post = await app.db
          .select()
          .from(schema.guPosts)
          .where(eq(schema.guPosts.id, id as any))
          .limit(1);

        if (post.length === 0) {
          return reply.status(404).send({ error: 'Post not found' });
        }

        const comments = await app.db
          .select({
            id: schema.guComments.id,
            postId: schema.guComments.postId,
            userId: schema.guComments.userId,
            commentText: schema.guComments.commentText,
            createdAt: schema.guComments.createdAt,
            author: {
              username: schema.guProfiles.username,
              profilePhoto: schema.guProfiles.profilePhoto,
            },
          })
          .from(schema.guComments)
          .innerJoin(schema.guProfiles, eq(schema.guComments.userId, schema.guProfiles.userId))
          .where(eq(schema.guComments.postId, id as any))
          .orderBy(desc(schema.guComments.createdAt));

        app.logger.info({ postId: id, commentCount: comments.length }, 'Post retrieved');
        return { post: post[0], comments };
      } catch (error) {
        app.logger.error({ err: error, postId: id }, 'Failed to get post');
        throw error;
      }
    }
  );

  // GET /api/gu/posts/user/:user_id - Get posts by user
  fastify.get<{ Params: { user_id: string } }>(
    '/api/gu/posts/user/:user_id',
    {
      schema: {
        description: 'Get posts by user',
        tags: ['glowup-posts'],
        params: {
          type: 'object',
          required: ['user_id'],
          properties: { user_id: { type: 'string' } },
        },
        response: {
          200: { type: 'object', properties: { posts: { type: 'array', items: { type: 'object' } } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { user_id: string } }>, reply: FastifyReply) => {
      const { user_id } = request.params;

      app.logger.info({ userId: user_id }, 'Getting user posts');

      try {
        const posts = await app.db
          .select({
            id: schema.guPosts.id,
            userId: schema.guPosts.userId,
            content: schema.guPosts.content,
            imageUrl: schema.guPosts.imageUrl,
            category: schema.guPosts.category,
            likesCount: schema.guPosts.likesCount,
            commentsCount: schema.guPosts.commentsCount,
            createdAt: schema.guPosts.createdAt,
            author: {
              username: schema.guProfiles.username,
              profilePhoto: schema.guProfiles.profilePhoto,
            },
          })
          .from(schema.guPosts)
          .innerJoin(schema.guProfiles, eq(schema.guPosts.userId, schema.guProfiles.userId))
          .where(eq(schema.guPosts.userId, user_id))
          .orderBy(desc(schema.guPosts.createdAt));

        app.logger.info({ userId: user_id, count: posts.length }, 'User posts retrieved');
        return { posts };
      } catch (error) {
        app.logger.error({ err: error, userId: user_id }, 'Failed to get user posts');
        throw error;
      }
    }
  );

  // ==================== LIKES ====================

  // POST /api/gu/posts/:id/like - Toggle like
  fastify.post<{ Params: { id: string } }>(
    '/api/gu/posts/:id/like',
    {
      schema: {
        description: 'Toggle like on post',
        tags: ['glowup-likes'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: {
            type: 'object',
            properties: {
              liked: { type: 'boolean' },
              likes_count: { type: 'number' },
            },
          },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const postId = request.params.id as any;
      const userId = session.user.id;

      app.logger.info({ postId, userId }, 'Toggling like');

      try {
        const existing = await app.db
          .select()
          .from(schema.guLikes)
          .where(and(eq(schema.guLikes.postId, postId), eq(schema.guLikes.userId, userId)))
          .limit(1);

        let liked = false;
        if (existing.length > 0) {
          await app.db
            .delete(schema.guLikes)
            .where(and(eq(schema.guLikes.postId, postId), eq(schema.guLikes.userId, userId)));

          await app.db
            .update(schema.guPosts)
            .set({ likesCount: sql`${schema.guPosts.likesCount} - 1` })
            .where(eq(schema.guPosts.id, postId));

          liked = false;
        } else {
          await app.db.insert(schema.guLikes).values({
            postId,
            userId,
          });

          await app.db
            .update(schema.guPosts)
            .set({ likesCount: sql`${schema.guPosts.likesCount} + 1` })
            .where(eq(schema.guPosts.id, postId));

          liked = true;
        }

        const post = await app.db
          .select()
          .from(schema.guPosts)
          .where(eq(schema.guPosts.id, postId))
          .limit(1);

        app.logger.info({ postId, liked }, 'Like toggled');
        return { liked, likes_count: post[0].likesCount };
      } catch (error) {
        app.logger.error({ err: error, postId }, 'Failed to toggle like');
        throw error;
      }
    }
  );

  // ==================== COMMENTS ====================

  // POST /api/gu/posts/:id/comments - Create comment
  fastify.post<{ Params: { id: string }; Body: CreateCommentBody }>(
    '/api/gu/posts/:id/comments',
    {
      schema: {
        description: 'Create comment on post',
        tags: ['glowup-comments'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        body: {
          type: 'object',
          required: ['comment_text'],
          properties: { comment_text: { type: 'string' } },
        },
        response: {
          201: { type: 'object', properties: { comment: { type: 'object' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string }; Body: CreateCommentBody }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const postId = request.params.id as any;
      const userId = session.user.id;
      const { comment_text } = request.body as CreateCommentBody;

      app.logger.info({ postId, userId }, 'Creating comment');

      try {
        const created = await app.db
          .insert(schema.guComments)
          .values({
            postId,
            userId,
            commentText: comment_text,
          })
          .returning();

        await app.db
          .update(schema.guPosts)
          .set({ commentsCount: sql`${schema.guPosts.commentsCount} + 1` })
          .where(eq(schema.guPosts.id, postId));

        reply.status(201);
        app.logger.info({ commentId: created[0].id }, 'Comment created');
        return { comment: created[0] };
      } catch (error) {
        app.logger.error({ err: error, postId }, 'Failed to create comment');
        throw error;
      }
    }
  );

  // DELETE /api/gu/comments/:id - Delete comment
  fastify.delete<{ Params: { id: string } }>(
    '/api/gu/comments/:id',
    {
      schema: {
        description: 'Delete comment',
        tags: ['glowup-comments'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: { type: 'object', properties: { success: { type: 'boolean' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
          404: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const commentId = request.params.id as any;
      const userId = session.user.id;

      app.logger.info({ commentId, userId }, 'Deleting comment');

      try {
        const comment = await app.db
          .select()
          .from(schema.guComments)
          .where(eq(schema.guComments.id, commentId))
          .limit(1);

        if (comment.length === 0) {
          return reply.status(404).send({ error: 'Comment not found' });
        }

        if (comment[0].userId !== userId) {
          return reply.status(404).send({ error: 'Comment not found' });
        }

        await app.db.delete(schema.guComments).where(eq(schema.guComments.id, commentId));

        await app.db
          .update(schema.guPosts)
          .set({ commentsCount: sql`${schema.guPosts.commentsCount} - 1` })
          .where(eq(schema.guPosts.id, comment[0].postId));

        app.logger.info({ commentId }, 'Comment deleted');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, commentId }, 'Failed to delete comment');
        throw error;
      }
    }
  );

  // ==================== SAVED POSTS ====================

  // POST /api/gu/posts/:id/save - Toggle save
  fastify.post<{ Params: { id: string } }>(
    '/api/gu/posts/:id/save',
    {
      schema: {
        description: 'Toggle save post',
        tags: ['glowup-saved'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: { type: 'object', properties: { saved: { type: 'boolean' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const postId = request.params.id as any;
      const userId = session.user.id;

      app.logger.info({ postId, userId }, 'Toggling save');

      try {
        const existing = await app.db
          .select()
          .from(schema.guSavedPosts)
          .where(and(eq(schema.guSavedPosts.postId, postId), eq(schema.guSavedPosts.userId, userId)))
          .limit(1);

        let saved = false;
        if (existing.length > 0) {
          await app.db
            .delete(schema.guSavedPosts)
            .where(and(eq(schema.guSavedPosts.postId, postId), eq(schema.guSavedPosts.userId, userId)));
          saved = false;
        } else {
          await app.db.insert(schema.guSavedPosts).values({
            userId,
            postId,
          });
          saved = true;
        }

        app.logger.info({ postId, saved }, 'Save toggled');
        return { saved };
      } catch (error) {
        app.logger.error({ err: error, postId }, 'Failed to toggle save');
        throw error;
      }
    }
  );

  // GET /api/gu/saved - Get saved posts
  fastify.get(
    '/api/gu/saved',
    {
      schema: {
        description: 'Get saved posts',
        tags: ['glowup-saved'],
        response: {
          200: { type: 'object', properties: { posts: { type: 'array', items: { type: 'object' } } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;

      app.logger.info({ userId }, 'Getting saved posts');

      try {
        const posts = await app.db
          .select({
            id: schema.guPosts.id,
            userId: schema.guPosts.userId,
            content: schema.guPosts.content,
            imageUrl: schema.guPosts.imageUrl,
            category: schema.guPosts.category,
            likesCount: schema.guPosts.likesCount,
            commentsCount: schema.guPosts.commentsCount,
            createdAt: schema.guPosts.createdAt,
            author: {
              username: schema.guProfiles.username,
              profilePhoto: schema.guProfiles.profilePhoto,
            },
          })
          .from(schema.guSavedPosts)
          .innerJoin(schema.guPosts, eq(schema.guSavedPosts.postId, schema.guPosts.id))
          .innerJoin(schema.guProfiles, eq(schema.guPosts.userId, schema.guProfiles.userId))
          .where(eq(schema.guSavedPosts.userId, userId))
          .orderBy(desc(schema.guSavedPosts.savedAt));

        app.logger.info({ userId, count: posts.length }, 'Saved posts retrieved');
        return { posts };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to get saved posts');
        throw error;
      }
    }
  );

  // ==================== CHALLENGES ====================

  // GET /api/gu/challenges - List challenges
  fastify.get<{ Querystring: ListChallengesQuery }>(
    '/api/gu/challenges',
    {
      schema: {
        description: 'List challenges',
        tags: ['glowup-challenges'],
        querystring: {
          type: 'object',
          properties: { category: { type: 'string' } },
        },
        response: {
          200: { type: 'object', properties: { challenges: { type: 'array', items: { type: 'object' } } } },
        },
      },
    },
    async (request: FastifyRequest<{ Querystring: ListChallengesQuery }>, reply: FastifyReply) => {
      const { category } = request.query as ListChallengesQuery;

      app.logger.info({ category }, 'Listing challenges');

      try {
        let query = app.db.select().from(schema.guChallenges);

        if (category) {
          query = query.where(eq(schema.guChallenges.category, category as any)) as any;
        }

        const challenges = await query.orderBy(desc(schema.guChallenges.createdAt));

        app.logger.info({ count: challenges.length }, 'Challenges retrieved');
        return { challenges };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to list challenges');
        throw error;
      }
    }
  );

  // GET /api/gu/challenges/joined - Get joined challenges
  fastify.get(
    '/api/gu/challenges/joined',
    {
      schema: {
        description: 'Get challenges user has joined',
        tags: ['glowup-challenges'],
        response: {
          200: {
            type: 'object',
            properties: {
              challenges: {
                type: 'array',
                items: { type: 'object' },
              },
            },
          },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;

      app.logger.info({ userId }, 'Getting joined challenges');

      try {
        const joined = await app.db
          .selectDistinct({
            id: schema.guChallenges.id,
            title: schema.guChallenges.title,
            description: schema.guChallenges.description,
            category: schema.guChallenges.category,
            durationDays: schema.guChallenges.durationDays,
            coverImage: schema.guChallenges.coverImage,
            isPremium: schema.guChallenges.isPremium,
            createdAt: schema.guChallenges.createdAt,
            latestDay: schema.guChallengeEntries.dayNumber,
          })
          .from(schema.guChallengeEntries)
          .innerJoin(
            schema.guChallenges,
            eq(schema.guChallengeEntries.challengeId, schema.guChallenges.id)
          )
          .where(eq(schema.guChallengeEntries.userId, userId));

        app.logger.info({ userId, count: joined.length }, 'Joined challenges retrieved');
        return { challenges: joined };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to get joined challenges');
        throw error;
      }
    }
  );

  // POST /api/gu/challenges/:id/log - Log challenge entry
  fastify.post<{ Params: { id: string }; Body: LogChallengeBody }>(
    '/api/gu/challenges/:id/log',
    {
      schema: {
        description: 'Log challenge entry',
        tags: ['glowup-challenges'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        body: {
          type: 'object',
          required: ['day_number'],
          properties: {
            day_number: { type: 'number' },
            note: { type: 'string' },
            photo_url: { type: 'string' },
          },
        },
        response: {
          201: { type: 'object', properties: { entry: { type: 'object' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string }; Body: LogChallengeBody }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const challengeId = request.params.id as any;
      const userId = session.user.id;
      const { day_number, note, photo_url } = request.body as LogChallengeBody;

      app.logger.info({ challengeId, userId, dayNumber: day_number }, 'Logging challenge entry');

      try {
        const created = await app.db
          .insert(schema.guChallengeEntries)
          .values({
            userId,
            challengeId,
            dayNumber: day_number,
            note: note || '',
            photoUrl: photo_url || '',
          })
          .returning();

        reply.status(201);
        app.logger.info({ entryId: created[0].id }, 'Challenge entry logged');
        return { entry: created[0] };
      } catch (error) {
        app.logger.error({ err: error, challengeId }, 'Failed to log challenge entry');
        throw error;
      }
    }
  );

  // GET /api/gu/challenges/:id/entries - Get challenge entries
  fastify.get<{ Params: { id: string } }>(
    '/api/gu/challenges/:id/entries',
    {
      schema: {
        description: 'Get challenge entries for user',
        tags: ['glowup-challenges'],
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string', format: 'uuid' } },
        },
        response: {
          200: { type: 'object', properties: { entries: { type: 'array', items: { type: 'object' } } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const challengeId = request.params.id as any;
      const userId = session.user.id;

      app.logger.info({ challengeId, userId }, 'Getting challenge entries');

      try {
        const entries = await app.db
          .select()
          .from(schema.guChallengeEntries)
          .where(
            and(
              eq(schema.guChallengeEntries.challengeId, challengeId),
              eq(schema.guChallengeEntries.userId, userId)
            )
          )
          .orderBy(schema.guChallengeEntries.dayNumber);

        app.logger.info({ challengeId, count: entries.length }, 'Challenge entries retrieved');
        return { entries };
      } catch (error) {
        app.logger.error({ err: error, challengeId }, 'Failed to get challenge entries');
        throw error;
      }
    }
  );

  // ==================== JOURNAL ====================

  // GET /api/gu/journal/prompt - Get today's journal prompt
  fastify.get(
    '/api/gu/journal/prompt',
    {
      schema: {
        description: "Get today's journal prompt",
        tags: ['glowup-journal'],
        response: {
          200: { type: 'object', properties: { prompt: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      try {
        const dayOfYear = Math.floor(
          (new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) /
            (1000 * 60 * 60 * 24)
        );
        const promptIndex = dayOfYear % JOURNAL_PROMPTS.length;
        const prompt = JOURNAL_PROMPTS[promptIndex];

        app.logger.info({ promptIndex }, 'Journal prompt retrieved');
        return { prompt };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to get journal prompt');
        throw error;
      }
    }
  );

  // POST /api/gu/journal - Create journal entry
  fastify.post<{ Body: CreateJournalBody }>(
    '/api/gu/journal',
    {
      schema: {
        description: 'Create journal entry',
        tags: ['glowup-journal'],
        body: {
          type: 'object',
          required: ['prompt', 'response', 'mood'],
          properties: {
            prompt: { type: 'string' },
            response: { type: 'string' },
            mood: { type: 'string' },
          },
        },
        response: {
          201: { type: 'object', properties: { entry: { type: 'object' } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest<{ Body: CreateJournalBody }>, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;
      const { prompt, response, mood } = request.body as CreateJournalBody;

      app.logger.info({ userId }, 'Creating journal entry');

      try {
        const created = await app.db
          .insert(schema.guJournalEntries)
          .values({
            userId,
            prompt,
            response,
            mood: mood as any,
          })
          .returning();

        reply.status(201);
        app.logger.info({ entryId: created[0].id }, 'Journal entry created');
        return { entry: created[0] };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to create journal entry');
        throw error;
      }
    }
  );

  // GET /api/gu/journal - Get user's journal entries
  fastify.get(
    '/api/gu/journal',
    {
      schema: {
        description: 'Get journal entries',
        tags: ['glowup-journal'],
        response: {
          200: { type: 'object', properties: { entries: { type: 'array', items: { type: 'object' } } } },
          401: { type: 'object', properties: { error: { type: 'string' } } },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const session = await requireAuth(request, reply);
      if (!session) return;

      const userId = session.user.id;

      app.logger.info({ userId }, 'Getting journal entries');

      try {
        const entries = await app.db
          .select()
          .from(schema.guJournalEntries)
          .where(eq(schema.guJournalEntries.userId, userId))
          .orderBy(desc(schema.guJournalEntries.createdAt));

        app.logger.info({ userId, count: entries.length }, 'Journal entries retrieved');
        return { entries };
      } catch (error) {
        app.logger.error({ err: error, userId }, 'Failed to get journal entries');
        throw error;
      }
    }
  );
}
