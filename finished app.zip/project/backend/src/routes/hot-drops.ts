import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';
import { sql } from 'drizzle-orm';

export function register(app: App, fastify: FastifyInstance) {
  fastify.get<{
    Querystring: {
      min_drop?: string;
      limit?: string;
    };
  }>(
    '/api/hot-drops',
    {
      schema: {
        description: 'Get products with the biggest price drops',
        tags: ['products'],
        querystring: {
          type: 'object',
          properties: {
            min_drop: {
              type: 'integer',
              default: 5,
              minimum: 1,
              maximum: 50,
              description: 'Minimum drop percentage threshold',
            },
            limit: {
              type: 'integer',
              default: 20,
              minimum: 1,
              maximum: 50,
              description: 'Maximum results to return',
            },
          },
        },
        response: {
          200: {
            description: 'List of products with big price drops and urgency scores',
            type: 'object',
            properties: {
              hot_drops: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    name: { type: 'string' },
                    url: { type: 'string' },
                    platform: { type: 'string' },
                    image_url: { type: 'string' },
                    current_price: { type: 'number' },
                    original_price: { type: 'number' },
                    highest_price: { type: 'number' },
                    currency: { type: 'string' },
                    in_stock: { type: 'boolean' },
                    target_price: { type: 'number' },
                    drop_pct: { type: 'number' },
                    urgency_score: { type: 'number' },
                    recent_drop: { type: 'boolean' },
                    view_count_24h: { type: 'integer' },
                    last_checked_at: { type: 'string', format: 'date-time' },
                    created_at: { type: 'string', format: 'date-time' },
                  },
                },
              },
              count: { type: 'integer' },
              min_drop_pct: { type: 'integer' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Querystring: {
          min_drop?: string;
          limit?: string;
        };
      }>,
      reply: FastifyReply
    ) => {
      const minDrop = Math.min(
        Math.max(parseInt(request.query.min_drop || '5'), 1),
        50
      );
      const limit = Math.min(
        Math.max(parseInt(request.query.limit || '20'), 1),
        50
      );

      app.logger.info(
        { minDrop, limit },
        'Getting hot drops'
      );

      try {
        const results = (await app.db.execute(sql`
          WITH price_stats AS (
            SELECT
              tracked_product_id,
              MAX(price) AS highest_price,
              MAX(recorded_at) FILTER (WHERE price = (SELECT MAX(p2.price) FROM price_history p2 WHERE p2.tracked_product_id = price_history.tracked_product_id)) AS highest_recorded_at
            FROM price_history
            GROUP BY tracked_product_id
          ),
          view_counts AS (
            SELECT
              tracked_product_id,
              COUNT(*) AS view_count_24h
            FROM product_views
            WHERE viewed_at >= NOW() - INTERVAL '24 hours'
            GROUP BY tracked_product_id
          ),
          alert_counts AS (
            SELECT
              tracked_product_id,
              COUNT(*) AS alert_count_48h
            FROM alerts
            WHERE created_at >= NOW() - INTERVAL '48 hours'
            GROUP BY tracked_product_id
          )
          SELECT
            tp.id,
            tp.name,
            tp.url,
            tp.platform,
            tp.image_url,
            tp.current_price,
            tp.original_price,
            tp.currency,
            tp.in_stock,
            tp.target_price,
            tp.last_checked_at,
            tp.created_at,
            ps.highest_price,
            ROUND(((ps.highest_price - tp.current_price) / ps.highest_price * 100)::numeric, 2) AS drop_pct,
            COALESCE(vc.view_count_24h, 0) AS view_count_24h,
            COALESCE(ac.alert_count_48h, 0) AS alert_count_48h,
            CASE
              WHEN ps.highest_recorded_at >= NOW() - INTERVAL '2 hours' THEN 30
              WHEN ps.highest_recorded_at >= NOW() - INTERVAL '6 hours' THEN 15
              ELSE 0
            END AS recency_bonus,
            CASE
              WHEN ps.highest_recorded_at >= NOW() - INTERVAL '6 hours' THEN true
              ELSE false
            END AS recent_drop
          FROM tracked_products tp
          INNER JOIN price_stats ps ON ps.tracked_product_id = tp.id
          LEFT JOIN view_counts vc ON vc.tracked_product_id = tp.id
          LEFT JOIN alert_counts ac ON ac.tracked_product_id = tp.id
          WHERE
            tp.in_stock = true
            AND tp.current_price < ps.highest_price
            AND ROUND(((ps.highest_price - tp.current_price) / ps.highest_price * 100)::numeric, 2) >= ${minDrop}
          ORDER BY
            (ROUND(((ps.highest_price - tp.current_price) / ps.highest_price * 100)::numeric, 2) * 2.0) +
            (LEAST(COALESCE(vc.view_count_24h, 0), 20)::numeric * 1.0) +
            (LEAST(COALESCE(ac.alert_count_48h, 0), 10)::numeric * 1.5) +
            CASE
              WHEN ps.highest_recorded_at >= NOW() - INTERVAL '2 hours' THEN 30
              WHEN ps.highest_recorded_at >= NOW() - INTERVAL '6 hours' THEN 15
              ELSE 0
            END DESC
          LIMIT ${limit}
        `) as any[]) || [];

        const hotDrops = results.map((row: any) => {
          const dropPct = parseFloat(row.drop_pct);
          const viewCount = parseInt(row.view_count_24h);
          const alertCount = parseInt(row.alert_count_48h);
          const recencyBonus = parseInt(row.recency_bonus);
          const urgencyScore = Math.round(
            ((dropPct * 2.0) +
            (Math.min(viewCount, 20) * 1.0) +
            (Math.min(alertCount, 10) * 1.5) +
            recencyBonus) * 10
          ) / 10;

          return {
            id: row.id,
            name: row.name,
            url: row.url,
            platform: row.platform,
            image_url: row.image_url,
            current_price: parseFloat(row.current_price),
            original_price: parseFloat(row.original_price),
            highest_price: parseFloat(row.highest_price),
            currency: row.currency,
            in_stock: row.in_stock,
            target_price: row.target_price ? parseFloat(row.target_price) : null,
            drop_pct: dropPct,
            urgency_score: urgencyScore,
            recent_drop: row.recent_drop,
            view_count_24h: viewCount,
            last_checked_at: row.last_checked_at,
            created_at: row.created_at,
          };
        });

        app.logger.info(
          { count: hotDrops.length, minDrop },
          'Hot drops retrieved successfully'
        );

        return {
          hot_drops: hotDrops,
          count: hotDrops.length,
          min_drop_pct: minDrop,
        };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to get hot drops');
        throw error;
      }
    }
  );
}
