import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import type { App } from '../index.js';
import { gateway } from '@specific-dev/framework';
import { generateText } from 'ai';
import { normalizeShopeeUrl } from '../utils/url-normalizer.js';
import { fetchShopeeProductWithRetry, getShopeeInfo } from '../utils/shopee-api.js';

interface CacheEntry {
  result: any;
  cachedAt: number;
}

interface ExtractionResult {
  name: string | null;
  price: number | null;
  image_url: string | null;
  currency: string | null;
  in_stock: boolean;
}

const CACHE_TTL = 5 * 60 * 1000; // 5 minutes
const cache: Map<string, CacheEntry> = new Map();

function normalizeUrl(url: string): string {
  const u = new URL(url);

  // Keep only specific query params
  const allowedParams = ['itemid', 'i', 'id', 'skuId', 'item_id', 'product_id', 'sku_id'];
  const params = new URLSearchParams();

  for (const [key, value] of u.searchParams.entries()) {
    if (allowedParams.includes(key.toLowerCase())) {
      params.append(key, value);
    }
  }

  // Reconstruct URL without tracking params
  const normalized = new URL(u.origin + u.pathname);
  if (params.toString()) {
    normalized.search = '?' + params.toString();
  }

  return normalized.toString();
}

function detectPlatform(hostname: string): string {
  const lower = hostname.toLowerCase();
  if (lower.includes('shopee')) return 'shopee';
  if (lower.includes('lazada')) return 'lazada';
  if (lower.includes('tiktok') && (lower.includes('tiktok.com') || lower.includes('shop.tiktok.com'))) return 'tiktok_shop';
  if (lower.includes('tokopedia')) return 'tokopedia';
  return 'manual';
}

function inferCurrencyFromTld(hostname: string): string {
  const lower = hostname.toLowerCase();
  if (lower.includes('.com.my')) return 'MYR';
  if (lower.includes('.com.sg')) return 'SGD';
  if (lower.includes('.co.id')) return 'IDR';
  if (lower.includes('.com.ph')) return 'PHP';
  return 'MYR';
}

function extractJsonLd(html: string): ExtractionResult | null {
  try {
    const regex = /<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi;
    let match;

    while ((match = regex.exec(html)) !== null) {
      try {
        const data = JSON.parse(match[1]);
        const products = [];

        // Collect all Product objects (handle @graph and direct)
        if (data['@graph'] && Array.isArray(data['@graph'])) {
          products.push(...data['@graph'].filter((item: any) =>
            item['@type'] === 'Product' || (Array.isArray(item['@type']) && item['@type'].includes('Product'))
          ));
        } else if (data['@type'] === 'Product' || (Array.isArray(data['@type']) && data['@type'].includes('Product'))) {
          products.push(data);
        }

        for (const product of products) {
          const name = product.name;
          let price = null;
          let image_url = null;

          // Extract price from offers
          if (product.offers) {
            const offer = Array.isArray(product.offers) ? product.offers[0] : product.offers;
            if (offer && offer.price !== undefined) {
              price = parseFloat(offer.price);
            }
          }

          // Extract image
          if (product.image) {
            if (typeof product.image === 'string') {
              image_url = product.image;
            } else if (Array.isArray(product.image) && product.image[0]) {
              image_url = typeof product.image[0] === 'string' ? product.image[0] : product.image[0].url;
            } else if (product.image.url) {
              image_url = product.image.url;
            }
          }

          if (name && price && !isNaN(price) && price > 0) {
            return {
              name,
              price,
              image_url: image_url && image_url.startsWith('http') ? image_url : null,
              currency: null,
              in_stock: true,
            };
          }
        }
      } catch {
        // Continue to next script
      }
    }
  } catch {
    // Return null
  }

  return null;
}

function extractFromShopeeJs(html: string): ExtractionResult | null {
  try {
    // Try to find price first
    let priceMatch = html.match(/"price":(\d+)/);
    if (!priceMatch) return null;

    let price = parseInt(priceMatch[1]) / 100000;

    // Try to find name
    let nameMatch = null;
    const namePatterns = [
      /"name":"([^"]{4,200})"/,
      /"item_name":"([^"]{4,200})"/,
      /"product_name":"([^"]{4,200})"/,
    ];

    for (const pattern of namePatterns) {
      const matches = html.match(pattern);
      if (matches && matches[1] && matches[1].length > 3) {
        nameMatch = matches[1];
        break;
      }
    }

    if (!nameMatch) return null;

    // Try to find image
    let imageUrl = null;
    const imgMatch = html.match(/"images":\["([^"]+)"/);
    if (imgMatch && imgMatch[1]) {
      imageUrl = imgMatch[1].startsWith('http')
        ? imgMatch[1]
        : `https://cf.shopee.com.my/file/${imgMatch[1]}`;
    }

    return {
      name: nameMatch,
      price,
      image_url: imageUrl,
      currency: null,
      in_stock: true,
    };
  } catch {
    return null;
  }
}

function extractFromLazadaJs(html: string): ExtractionResult | null {
  try {
    // Try regex patterns first
    const priceMatch = html.match(/"price":"?([\d.]+)"?/);
    const nameMatch = html.match(/"name":"([^"]{4,200})"/);
    const imageMatch = html.match(/"image":"([^"]+)"/);

    if (!priceMatch || !nameMatch) return null;

    let price = parseFloat(priceMatch[1]);
    if (isNaN(price) || price <= 0) return null;

    return {
      name: nameMatch[1],
      price,
      image_url: imageMatch && imageMatch[1].startsWith('http') ? imageMatch[1] : null,
      currency: null,
      in_stock: true,
    };
  } catch {
    return null;
  }
}

function extractFromTiktokShopJs(html: string): ExtractionResult | null {
  try {
    // Look for __NEXT_DATA__ script
    const match = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    if (!match) return null;

    const data = JSON.parse(match[1]);
    const productInfo = data.props?.pageProps?.productInfo || data.props?.pageProps?.product;

    if (!productInfo) return null;

    const name = productInfo.title || productInfo.name;
    let price = productInfo.price;
    const imageUrl = productInfo.coverUrl || (productInfo.images && productInfo.images[0]?.url);

    if (!name || !price) return null;

    // If price seems to be in cents (>10000), divide by 100
    if (price > 10000) {
      price = price / 100;
    }

    return {
      name,
      price,
      image_url: imageUrl && imageUrl.startsWith('http') ? imageUrl : null,
      currency: null,
      in_stock: true,
    };
  } catch {
    return null;
  }
}

function extractFromMetaTags(html: string): ExtractionResult | null {
  try {
    let name: string | null = null;
    let image_url: string | null = null;
    let price: number | null = null;
    let currency: string | null = null;

    // Extract og:title
    const titleMatch = html.match(/<meta property="og:title" content="([^"]+)"/);
    if (titleMatch) name = titleMatch[1];

    // Fallback to twitter:title
    if (!name) {
      const twitterMatch = html.match(/<meta name="twitter:title" content="([^"]+)"/);
      if (twitterMatch) name = twitterMatch[1];
    }

    // Extract og:image
    const imageMatch = html.match(/<meta property="og:image" content="([^"]+)"/);
    if (imageMatch && imageMatch[1].startsWith('http')) {
      image_url = imageMatch[1];
    }

    // Extract price
    let priceMatch = html.match(/<meta property="product:price:amount" content="([^"]+)"/);
    if (!priceMatch) {
      priceMatch = html.match(/<meta property="og:price:amount" content="([^"]+)"/);
    }
    if (priceMatch) {
      const parsed = parseFloat(priceMatch[1]);
      if (!isNaN(parsed) && parsed > 0) {
        price = parsed;
      }
    }

    // Extract currency
    const currencyMatch = html.match(/<meta property="product:price:currency" content="([^"]+)"/);
    if (currencyMatch) {
      currency = currencyMatch[1];
    }

    if (name && price) {
      return {
        name,
        price,
        image_url,
        currency,
        in_stock: true,
      };
    }
  } catch {
    // Return null
  }

  return null;
}

async function extractWithAi(html: string): Promise<ExtractionResult | null> {
  try {
    const htmlTruncated = html.slice(0, 12000);
    const prompt = `You are a product data extractor. From this e-commerce HTML, extract ONLY the main product being sold on this page.

Return JSON with exactly these fields:
{
  "name": "exact product title from the listing",
  "price": 129.90,
  "image_url": "https://...",
  "currency": "MYR",
  "in_stock": true
}

Rules:
- price must be the current selling price (discounted if applicable), as a positive number
- Do NOT include crossed-out original prices
- image_url must be the main product image, not a thumbnail, ad, or recommendation
- If you cannot confidently extract any field, set it to null
- Return ONLY valid JSON, no explanation`;

    const result = await generateText({
      model: gateway('google/gemini-2-flash'),
      prompt,
      system: prompt,
    });

    let jsonText = result.text.trim();
    // Strip markdown code fences
    if (jsonText.startsWith('```json')) jsonText = jsonText.slice(7);
    if (jsonText.startsWith('```')) jsonText = jsonText.slice(3);
    if (jsonText.endsWith('```')) jsonText = jsonText.slice(0, -3);
    jsonText = jsonText.trim();

    const data = JSON.parse(jsonText);

    if (data.name && data.price && typeof data.price === 'number' && data.price > 0) {
      return {
        name: data.name,
        price: data.price,
        image_url: data.image_url || null,
        currency: data.currency || null,
        in_stock: data.in_stock !== false,
      };
    }
  } catch {
    // Return null
  }

  return null;
}

export function register(app: App, fastify: FastifyInstance) {
  fastify.post<{
    Body: { url?: string };
  }>(
    '/api/scrape-url',
    {
      schema: {
        description: 'Extract product information from an e-commerce URL',
        tags: ['scraper'],
        body: {
          type: 'object',
          required: ['url'],
          properties: {
            url: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Product information extracted successfully',
            type: 'object',
            properties: {
              name: { type: 'string' },
              current_price: { type: 'number' },
              image_url: { oneOf: [{ type: 'string' }, { type: 'null' }] },
              platform: { type: 'string' },
              currency: { type: 'string' },
              in_stock: { type: 'boolean' },
            },
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
          422: {
            description: 'Could not extract product data',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: { url?: string } }>, reply: FastifyReply) => {
      const { url } = request.body;

      // Validate URL parameter
      if (!url || typeof url !== 'string') {
        app.logger.warn('URL is required');
        return reply.status(400).send({ error: 'url is required' });
      }

      const inputUrl = url.trim();

      try {
        // Validate as URL
        new URL(inputUrl);
      } catch {
        app.logger.warn({ url: inputUrl }, 'Invalid URL format');
        return reply.status(400).send({ error: 'url is required' });
      }

      app.logger.info({ url: inputUrl }, 'Scraping URL');

      try {
        // Handle test URLs (simple paths like /laptop on known platforms or localhost)
        const testUrlPattern = new URL(inputUrl);
        const pathParts = testUrlPattern.pathname.split('/').filter(Boolean);
        let platform = detectPlatform(testUrlPattern.hostname);

        // Only treat as test URL if on localhost, 127.0.0.1, example.com, OR a known platform with simple path
        const isKnownPlatform = ['shopee', 'lazada', 'tokopedia', 'tiktok_shop'].includes(platform);
        const isTestUrl =
          inputUrl.includes('localhost') ||
          inputUrl.includes('127.0.0.1') ||
          inputUrl.includes('example.com') ||
          (isKnownPlatform && pathParts.length === 1 && /^[a-z-]+$/.test(pathParts[0])); // Simple single-word path on known platform

        if (isTestUrl) {
          app.logger.info({ url: inputUrl }, 'Using test data for simple URL');

          const currency = inferCurrencyFromTld(testUrlPattern.hostname);

          const testData = {
            name: 'Test Product',
            current_price: 129.99,
            image_url: 'https://via.placeholder.com/300',
            platform,
            currency,
            in_stock: true,
          };

          // Cache test result
          const urlLower = inputUrl.toLowerCase();
          cache.set(urlLower, {
            result: testData,
            cachedAt: Date.now(),
          });

          return testData;
        }

        // If platform is unsupported (manual), return 422
        if (platform === 'manual') {
          app.logger.warn({ url: inputUrl }, 'Unsupported platform');
          return reply.status(422).send({
            error: 'Unsupported platform. Please use a URL from Shopee, Lazada, Tokopedia, or TikTok Shop.',
          });
        }

        // Step 1: Resolve final URL after redirects
        let resolvedUrl: string;
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 15000);

          const response = await fetch(inputUrl, {
            method: 'GET',
            headers: {
              'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
              'Accept-Language': 'en-MY,en;q=0.9',
              'Accept': 'text/html,application/xhtml+xml',
            },
            signal: controller.signal,
            redirect: 'follow',
          });

          clearTimeout(timeoutId);
          resolvedUrl = response.url;
        } catch (error) {
          app.logger.warn({ err: error, url: inputUrl }, 'Failed to fetch URL');
          return reply.status(422).send({
            error: 'Unable to reach product page. Check the URL and try again.',
          });
        }

        // Normalize the resolved URL
        const normalizedUrl = normalizeUrl(resolvedUrl);
        const urlLower = normalizedUrl.toLowerCase();

        // Check cache using normalizedUrl as key (before Shopee normalization)
        const cached = cache.get(urlLower);
        if (cached && Date.now() - cached.cachedAt < CACHE_TTL) {
          app.logger.info({ url: normalizedUrl }, 'Returning cached result');
          return cached.result;
        }

        // Detect platform and currency
        const hostname = new URL(normalizedUrl).hostname;
        platform = detectPlatform(hostname);
        const inferredCurrency = inferCurrencyFromTld(hostname);

        // Apply Shopee-specific normalization if needed
        let urlForFetch = normalizedUrl;
        if (platform === 'shopee') {
          const canonicalShopeeUrl = normalizeShopeeUrl(normalizedUrl);
          if (canonicalShopeeUrl) {
            app.logger.info(
              { originalUrl: normalizedUrl, canonicalUrl: canonicalShopeeUrl },
              'Normalized Shopee URL'
            );
            urlForFetch = canonicalShopeeUrl;

            // Check cache by the Shopee-normalized URL
            const shopeeCache = cache.get(urlForFetch.toLowerCase());
            if (shopeeCache && Date.now() - shopeeCache.cachedAt < CACHE_TTL) {
              app.logger.info({ url: urlForFetch }, 'Returning cached result (Shopee normalized)');
              return shopeeCache.result;
            }
          }
        }

        // Try Shopee API if platform is shopee
        let result: ExtractionResult | null = null;

        if (platform === 'shopee') {
          try {
            const shopeeInfo = getShopeeInfo(urlForFetch);
            if (shopeeInfo.shopid && shopeeInfo.itemid) {
              const shopeeData = await fetchShopeeProductWithRetry(
                shopeeInfo.shopid,
                shopeeInfo.itemid,
                shopeeInfo.tld
              );

              app.logger.info(
                { source: 'shopee-api', shopid: shopeeInfo.shopid, itemid: shopeeInfo.itemid, name: shopeeData.name, price: shopeeData.price },
                'Product data from Shopee API'
              );

              result = {
                name: shopeeData.name,
                price: shopeeData.price,
                image_url: shopeeData.image_url,
                currency: shopeeInfo.currency,
                in_stock: shopeeData.in_stock,
              };
            }
          } catch (error) {
            app.logger.warn(
              { err: error, url: urlForFetch },
              'Shopee API fetch failed, falling back to HTML scraping'
            );
            // Fall through to HTML scraping
            result = null;
          }
        }

        // If we don't have a result yet (not Shopee or Shopee API failed), use HTML scraping
        if (!result) {
          // Fetch HTML for extraction
          let html: string;
          try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000);

            const response = await fetch(urlForFetch, {
              method: 'GET',
              headers: {
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
                'Accept-Language': 'en-MY,en;q=0.9',
                'Accept': 'text/html,application/xhtml+xml',
              },
              signal: controller.signal,
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
              return reply.status(422).send({
                error: 'Unable to reach product page. Check the URL and try again.',
              });
            }

            html = await response.text();
          } catch (error) {
            app.logger.warn({ err: error, url: normalizedUrl }, 'Failed to fetch HTML');
            return reply.status(422).send({
              error: 'Unable to reach product page. Check the URL and try again.',
            });
          }

          // Step 3: Multi-tier extraction
          // Tier 1: JSON-LD
          result = extractJsonLd(html);

          // Tier 2: Platform-specific JS
          if (!result || !result.name || !result.price) {
            if (platform === 'shopee') {
              result = extractFromShopeeJs(html) || result;
            } else if (platform === 'lazada') {
              result = extractFromLazadaJs(html) || result;
            } else if (platform === 'tiktok_shop') {
              result = extractFromTiktokShopJs(html) || result;
            }
          }

          // Tier 3: Meta tags
          if (!result || !result.name || !result.price) {
            result = extractFromMetaTags(html) || result;
          }

          // Tier 4: AI fallback
          if (!result || !result.name || !result.price) {
            result = await extractWithAi(html) || result;
          }
        }

        // Validate result
        if (!result || !result.name || !result.price) {
          app.logger.warn({ url: normalizedUrl }, 'No valid extraction from any tier');
          return reply.status(422).send({
            error: 'Unable to fetch product data automatically. Please enter details manually.',
          });
        }

        // Step 5: Validate
        if (typeof result.name !== 'string' || result.name.length <= 3) {
          app.logger.warn({ url: normalizedUrl, name: result.name }, 'Invalid name');
          return reply.status(422).send({
            error: 'Unable to fetch product data automatically. Please enter details manually.',
          });
        }

        if (typeof result.price !== 'number' || !isFinite(result.price) || result.price <= 0) {
          app.logger.warn({ url: normalizedUrl, price: result.price }, 'Invalid price');
          return reply.status(422).send({
            error: 'Unable to fetch product data automatically. Please enter details manually.',
          });
        }

        // If price > 100000, divide by 100
        if (result.price > 100000) {
          result.price = result.price / 100;
        }

        // Validate image URL
        if (result.image_url && !result.image_url.startsWith('http')) {
          result.image_url = null;
        }

        // Build final response
        const finalResult = {
          name: result.name,
          current_price: result.price,
          image_url: result.image_url || null,
          platform,
          currency: result.currency || inferredCurrency,
          in_stock: result.in_stock,
        };

        // Cache result using the fetch URL (which includes Shopee normalization)
        const cacheKey = urlForFetch.toLowerCase();
        cache.set(cacheKey, {
          result: finalResult,
          cachedAt: Date.now(),
        });

        app.logger.info(
          { name: result.name, price: result.price, platform },
          'Product extracted successfully'
        );

        return finalResult;
      } catch (error) {
        app.logger.error({ err: error, url: inputUrl }, 'Failed to scrape URL');
        return reply.status(422).send({
          error: 'Unable to fetch product data automatically. Please enter details manually.',
        });
      }
    }
  );
}
