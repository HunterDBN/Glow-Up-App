import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import {
  count,
  countDistinct,
  sum,
  eq,
  inArray,
  isNotNull,
  and,
} from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/profile/stats - Get aggregate statistics
  fastify.get(
    '/api/profile/stats',
    {
      schema: {
        description: 'Get user profile statistics',
        tags: ['profile'],
        response: {
          200: {
            description: 'User profile statistics',
            type: 'object',
            properties: {
              total_tracked: { type: 'integer' },
              total_alerts: { type: 'integer' },
              unread_alerts: { type: 'integer' },
              total_savings: { type: 'string' },
              platforms_used: { type: 'integer' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      app.logger.info('Getting profile statistics');

      try {
        // Count total tracked products
        const totalTrackedResult = await app.db
          .select({ value: count() })
          .from(schema.trackedProducts);
        const totalTracked = totalTrackedResult[0]?.value || 0;

        // Count total alerts
        const totalAlertsResult = await app.db
          .select({ value: count() })
          .from(schema.alerts);
        const totalAlerts = totalAlertsResult[0]?.value || 0;

        // Count unread alerts
        const unreadAlertsResult = await app.db
          .select({ value: count() })
          .from(schema.alerts)
          .where(eq(schema.alerts.isRead, false));
        const unreadAlerts = unreadAlertsResult[0]?.value || 0;

        // Sum total savings from price_drop and target_reached alerts
        const totalSavingsResult = await app.db
          .select({ value: sum(schema.alerts.savings) })
          .from(schema.alerts)
          .where(
            and(
              inArray(schema.alerts.type, ['price_drop', 'target_reached']),
              isNotNull(schema.alerts.savings)
            )
          );
        const totalSavings = totalSavingsResult[0]?.value || '0';

        // Count distinct platforms
        const platformsResult = await app.db
          .select({ value: countDistinct(schema.trackedProducts.platform) })
          .from(schema.trackedProducts);
        const platformsUsed = platformsResult[0]?.value || 0;

        app.logger.info(
          {
            totalTracked,
            totalAlerts,
            unreadAlerts,
            totalSavings,
            platformsUsed,
          },
          'Profile statistics retrieved successfully'
        );

        return {
          total_tracked: totalTracked,
          total_alerts: totalAlerts,
          unread_alerts: unreadAlerts,
          total_savings: totalSavings,
          platforms_used: platformsUsed,
        };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to get profile statistics');
        throw error;
      }
    }
  );
}
