import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc, ilike, and, or } from 'drizzle-orm';
import { sql } from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/tj/trends - List all trends with optional filters
  fastify.get<{
    Querystring: { niche?: string; platform?: string; search?: string };
  }>(
    '/api/tj/trends',
    {
      schema: {
        description: 'List all trends with optional filtering',
        tags: ['trendjack'],
        querystring: {
          type: 'object',
          properties: {
            niche: { type: 'string', description: 'Filter by niche' },
            platform: { type: 'string', description: 'Filter by platform' },
            search: { type: 'string', description: 'Search by title (ilike)' },
          },
        },
        response: {
          200: {
            description: 'List of trends',
            type: 'object',
            properties: {
              trends: {
                type: 'array',
                items: { type: 'object' },
              },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Querystring: { niche?: string; platform?: string; search?: string } }>,
      reply: FastifyReply
    ) => {
      const { niche, platform, search } = request.query;

      app.logger.info({ niche, platform, search }, 'Fetching trends');

      try {
        const conditions: any[] = [];
        if (niche) {
          conditions.push(eq(schema.trends.niche, niche));
        }
        if (platform) {
          conditions.push(eq(schema.trends.platform, platform));
        }
        if (search) {
          conditions.push(ilike(schema.trends.title, `%${search}%`));
        }

        let baseQuery = app.db.select().from(schema.trends) as any;

        if (conditions.length > 0) {
          baseQuery = baseQuery.where(and(...conditions));
        }

        const trends = await baseQuery.orderBy(desc(schema.trends.trendScore));

        app.logger.info({ count: trends.length }, 'Trends fetched successfully');
        return { trends };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to fetch trends');
        throw error;
      }
    }
  );

  // GET /api/tj/trends/:id - Get single trend with templates
  fastify.get<{
    Params: { id: string };
  }>(
    '/api/tj/trends/:id',
    {
      schema: {
        description: 'Get a trend with its templates',
        tags: ['trendjack'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', description: 'Trend ID' },
          },
        },
        response: {
          200: {
            description: 'Trend with templates',
            type: 'object',
            properties: {
              trend: { type: 'object' },
              templates: {
                type: 'array',
                items: { type: 'object' },
              },
            },
          },
          404: {
            description: 'Trend not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
      const { id } = request.params;

      app.logger.info({ trendId: id }, 'Getting trend');

      try {
        const trend = await app.db
          .select()
          .from(schema.trends)
          .where(eq(schema.trends.id, id))
          .limit(1);

        if (trend.length === 0) {
          app.logger.warn({ trendId: id }, 'Trend not found');
          return reply.status(404).send({ error: 'Trend not found' });
        }

        const templates = await app.db
          .select()
          .from(schema.templates)
          .where(eq(schema.templates.trendId, id));

        app.logger.info({ trendId: id, templateCount: templates.length }, 'Trend retrieved');
        return { trend: trend[0], templates };
      } catch (error) {
        app.logger.error({ err: error, trendId: id }, 'Failed to get trend');
        throw error;
      }
    }
  );

  // GET /api/tj/saved - Get saved items for user
  fastify.get<{
    Querystring: { device_id?: string };
  }>(
    '/api/tj/saved',
    {
      schema: {
        description: 'Get saved items for a user',
        tags: ['trendjack'],
        querystring: {
          type: 'object',
          required: ['device_id'],
          properties: {
            device_id: { type: 'string', description: 'Device ID' },
          },
        },
        response: {
          200: {
            description: 'Saved items',
            type: 'object',
            properties: {
              saved: {
                type: 'array',
                items: { type: 'object' },
              },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Querystring: { device_id?: string } }>, reply: FastifyReply) => {
      const { device_id } = request.query;

      if (!device_id) {
        return reply.status(400).send({ error: 'device_id is required' });
      }

      app.logger.info({ deviceId: device_id }, 'Getting saved items');

      try {
        // Upsert user
        const existingUser = await app.db
          .select()
          .from(schema.tjUsers)
          .where(eq(schema.tjUsers.deviceId, device_id))
          .limit(1);

        let user;
        if (existingUser.length === 0) {
          const created = await app.db
            .insert(schema.tjUsers)
            .values({ deviceId: device_id })
            .returning();
          user = created[0];
        } else {
          user = existingUser[0];
        }

        // Get saved items with trend and template details
        const saved = await app.db
          .select({
            id: schema.savedItems.id,
            userId: schema.savedItems.userId,
            trendId: schema.savedItems.trendId,
            templateId: schema.savedItems.templateId,
            savedAt: schema.savedItems.savedAt,
            trend: {
              id: schema.trends.id,
              title: schema.trends.title,
              niche: schema.trends.niche,
              platform: schema.trends.platform,
              whyItsTrending: schema.trends.whyItsTrending,
              trendScore: schema.trends.trendScore,
              isFeatured: schema.trends.isFeatured,
              createdAt: schema.trends.createdAt,
            },
            template: {
              id: schema.templates.id,
              hook: schema.templates.hook,
              script: schema.templates.script,
              caption: schema.templates.caption,
              callToAction: schema.templates.callToAction,
            },
          })
          .from(schema.savedItems)
          .innerJoin(schema.trends, eq(schema.savedItems.trendId, schema.trends.id))
          .leftJoin(schema.templates, eq(schema.savedItems.templateId, schema.templates.id))
          .where(eq(schema.savedItems.userId, user.id));

        app.logger.info({ deviceId: device_id, count: saved.length }, 'Saved items retrieved');
        return { saved };
      } catch (error) {
        app.logger.error({ err: error, deviceId: device_id }, 'Failed to get saved items');
        throw error;
      }
    }
  );

  // POST /api/tj/saved - Save an item
  fastify.post<{
    Body: { device_id: string; trend_id: string; template_id?: string };
  }>(
    '/api/tj/saved',
    {
      schema: {
        description: 'Save a trend or template',
        tags: ['trendjack'],
        body: {
          type: 'object',
          required: ['device_id', 'trend_id'],
          properties: {
            device_id: { type: 'string' },
            trend_id: { type: 'string' },
            template_id: { type: 'string' },
          },
        },
        response: {
          201: {
            description: 'Saved item created',
            type: 'object',
            properties: {
              saved_item: { type: 'object' },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Body: { device_id: string; trend_id: string; template_id?: string } }>,
      reply: FastifyReply
    ) => {
      const { device_id, trend_id, template_id } = request.body;

      if (!device_id || !trend_id) {
        return reply.status(400).send({ error: 'device_id and trend_id are required' });
      }

      app.logger.info({ deviceId: device_id, trendId: trend_id }, 'Saving item');

      try {
        // Upsert user
        const existingUser = await app.db
          .select()
          .from(schema.tjUsers)
          .where(eq(schema.tjUsers.deviceId, device_id))
          .limit(1);

        let user;
        if (existingUser.length === 0) {
          const created = await app.db
            .insert(schema.tjUsers)
            .values({ deviceId: device_id })
            .returning();
          user = created[0];
        } else {
          user = existingUser[0];
        }

        // Insert saved item (on conflict do nothing)
        const result = await app.db
          .insert(schema.savedItems)
          .values({
            userId: user.id,
            trendId: trend_id,
            templateId: template_id || null,
          })
          .onConflictDoNothing({ target: [schema.savedItems.userId, schema.savedItems.trendId] })
          .returning();

        let saved_item;
        if (result.length === 0) {
          // Item already exists, fetch it
          const existing = await app.db
            .select()
            .from(schema.savedItems)
            .where(and(eq(schema.savedItems.userId, user.id), eq(schema.savedItems.trendId, trend_id)))
            .limit(1);
          saved_item = existing[0];
        } else {
          saved_item = result[0];
        }

        app.logger.info({ deviceId: device_id, savedItemId: saved_item.id }, 'Item saved');
        reply.status(201);
        return { saved_item };
      } catch (error) {
        app.logger.error({ err: error, deviceId: device_id, trendId: trend_id }, 'Failed to save item');
        throw error;
      }
    }
  );

  // DELETE /api/tj/saved/:id - Delete saved item
  fastify.delete<{
    Params: { id: string };
    Body: { device_id: string };
  }>(
    '/api/tj/saved/:id',
    {
      schema: {
        description: 'Delete a saved item',
        tags: ['trendjack'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['device_id'],
          properties: {
            device_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'Item deleted',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
            },
          },
          404: {
            description: 'Not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Params: { id: string }; Body: { device_id: string } }>,
      reply: FastifyReply
    ) => {
      const { id } = request.params;
      const { device_id } = request.body;

      app.logger.info({ savedItemId: id, deviceId: device_id }, 'Deleting saved item');

      try {
        // Get saved item and verify ownership
        const savedItem = await app.db
          .select()
          .from(schema.savedItems)
          .where(eq(schema.savedItems.id, id))
          .limit(1);

        if (savedItem.length === 0) {
          app.logger.warn({ savedItemId: id }, 'Saved item not found');
          return reply.status(404).send({ error: 'Saved item not found' });
        }

        // Verify ownership
        const user = await app.db
          .select()
          .from(schema.tjUsers)
          .where(eq(schema.tjUsers.id, savedItem[0].userId))
          .limit(1);

        if (user.length === 0 || user[0].deviceId !== device_id) {
          app.logger.warn({ savedItemId: id, deviceId: device_id }, 'Unauthorized delete');
          return reply.status(404).send({ error: 'Saved item not found' });
        }

        // Delete
        await app.db.delete(schema.savedItems).where(eq(schema.savedItems.id, id));

        app.logger.info({ savedItemId: id }, 'Saved item deleted');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, savedItemId: id }, 'Failed to delete saved item');
        throw error;
      }
    }
  );

  // GET /api/tj/profile - Get user profile
  fastify.get<{
    Querystring: { device_id?: string };
  }>(
    '/api/tj/profile',
    {
      schema: {
        description: 'Get user profile',
        tags: ['trendjack'],
        querystring: {
          type: 'object',
          required: ['device_id'],
          properties: {
            device_id: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'User profile',
            type: 'object',
            properties: {
              user: { type: 'object' },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Querystring: { device_id?: string } }>, reply: FastifyReply) => {
      const { device_id } = request.query;

      if (!device_id) {
        return reply.status(400).send({ error: 'device_id is required' });
      }

      app.logger.info({ deviceId: device_id }, 'Getting profile');

      try {
        // Upsert user
        const existingUser = await app.db
          .select()
          .from(schema.tjUsers)
          .where(eq(schema.tjUsers.deviceId, device_id))
          .limit(1);

        let user;
        if (existingUser.length === 0) {
          const created = await app.db
            .insert(schema.tjUsers)
            .values({ deviceId: device_id })
            .returning();
          user = created[0];
        } else {
          user = existingUser[0];
        }

        app.logger.info({ deviceId: device_id, userId: user.id }, 'Profile retrieved');
        return { user };
      } catch (error) {
        app.logger.error({ err: error, deviceId: device_id }, 'Failed to get profile');
        throw error;
      }
    }
  );

  // PUT /api/tj/profile - Update user profile
  fastify.put<{
    Body: { device_id: string; name?: string; selected_niches?: string };
  }>(
    '/api/tj/profile',
    {
      schema: {
        description: 'Update user profile',
        tags: ['trendjack'],
        body: {
          type: 'object',
          required: ['device_id'],
          properties: {
            device_id: { type: 'string' },
            name: { type: 'string' },
            selected_niches: { type: 'string' },
          },
        },
        response: {
          200: {
            description: 'User profile updated',
            type: 'object',
            properties: {
              user: { type: 'object' },
            },
          },
          400: {
            description: 'Bad request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{ Body: { device_id: string; name?: string; selected_niches?: string } }>,
      reply: FastifyReply
    ) => {
      const { device_id, name, selected_niches } = request.body;

      if (!device_id) {
        return reply.status(400).send({ error: 'device_id is required' });
      }

      app.logger.info({ deviceId: device_id }, 'Updating profile');

      try {
        // Upsert user
        const existingUser = await app.db
          .select()
          .from(schema.tjUsers)
          .where(eq(schema.tjUsers.deviceId, device_id))
          .limit(1);

        let user;
        if (existingUser.length === 0) {
          const insertData: any = { deviceId: device_id };
          if (name) insertData.name = name;
          if (selected_niches) insertData.selectedNiches = selected_niches;

          const created = await app.db
            .insert(schema.tjUsers)
            .values(insertData as typeof schema.tjUsers.$inferInsert)
            .returning();
          user = created[0];
        } else {
          // Update existing user
          const updateData: any = {};
          if (name) updateData.name = name;
          if (selected_niches) updateData.selectedNiches = selected_niches;

          if (Object.keys(updateData).length > 0) {
            await app.db
              .update(schema.tjUsers)
              .set(updateData)
              .where(eq(schema.tjUsers.id, existingUser[0].id));

            const updated = await app.db
              .select()
              .from(schema.tjUsers)
              .where(eq(schema.tjUsers.id, existingUser[0].id))
              .limit(1);
            user = updated[0];
          } else {
            user = existingUser[0];
          }
        }

        app.logger.info({ deviceId: device_id, userId: user.id }, 'Profile updated');
        return { user };
      } catch (error) {
        app.logger.error({ err: error, deviceId: device_id }, 'Failed to update profile');
        throw error;
      }
    }
  );
}
