import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc, asc, isNull, isNotNull, lt, or } from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';
import { runPriceCheck, hashUrl } from '../utils/price-check.js';
import { normalizeUrl } from '../utils/url-normalizer.js';
import { getNextTrackingId } from '../utils/products-helpers.js';
import { sql } from 'drizzle-orm';

function generatePriceHistory(
  basePrice: number
): Array<{ price: number; daysAgo: number }> {
  const history: Array<{ price: number; daysAgo: number }> = [];
  const startPrice = basePrice * (1 + Math.random() * 0.10 + 0.05); // 5-15% higher

  // Generate 10 historical points
  for (let i = 9; i >= 0; i--) {
    const daysAgo = (i / 9) * 7;
    const progress = (9 - i) / 9;
    const noise = (Math.random() - 0.5) * 0.02 * basePrice; // ±1%
    const simulatedPrice =
      startPrice * (1 + (1 - progress) * 0.08) + noise;
    const floorPrice = basePrice * 0.85;
    const finalPrice = Math.max(simulatedPrice, floorPrice);
    const roundedPrice = Math.round(finalPrice * 100) / 100;

    history.push({
      price: roundedPrice,
      daysAgo,
    });
  }

  // Add current price as latest
  history.push({
    price: basePrice,
    daysAgo: 0,
  });

  return history;
}

async function performPriceCheck(
  app: App,
  productId: string
): Promise<{
  priceChanged: boolean;
  newPrice: number;
}> {
  const product = await app.db
    .select()
    .from(schema.trackedProducts)
    .where(eq(schema.trackedProducts.id, productId));

  if (product.length === 0) {
    throw new Error('Product not found');
  }

  const prod = product[0];
  const oldPrice = parseFloat(prod.currentPrice);
  const oldInStock = prod.inStock;

  // Deterministic simulation
  let seed = 0;
  for (let i = 0; i < productId.length; i++) {
    seed = ((seed * 31 + productId.charCodeAt(i)) >>> 0);
  }

  const currentHour = new Date().getHours();
  const hourSeed = (seed ^ (currentHour * 2654435761)) >>> 0;
  const rand = ((hourSeed >>> 0) % 1000) / 1000;

  let newPrice = oldPrice;
  let newInStock = oldInStock;

  if (rand < 0.60) {
    // No change
  } else if (rand < 0.80) {
    const dropPct = 0.005 + ((rand - 0.60) / 0.20) * 0.025;
    newPrice = oldPrice * (1 - dropPct);
  } else if (rand < 0.90) {
    const dropPct = 0.03 + ((rand - 0.80) / 0.10) * 0.05;
    newPrice = oldPrice * (1 - dropPct);
  } else if (rand < 0.97) {
    const risePct = 0.005 + ((rand - 0.90) / 0.07) * 0.015;
    newPrice = oldPrice * (1 + risePct);
  } else {
    newInStock = !oldInStock;
  }

  newPrice = Math.round(newPrice * 100) / 100;
  const priceChanged = Math.abs(newPrice - oldPrice) > 0.001;
  const stockChanged = newInStock !== oldInStock;

  if (priceChanged || stockChanged) {
    await app.db
      .update(schema.trackedProducts)
      .set({
        currentPrice: newPrice.toString(),
        inStock: newInStock,
        lastCheckedAt: sql`now()`,
      })
      .where(eq(schema.trackedProducts.id, productId));

    if (priceChanged) {
      await app.db.insert(schema.priceHistory).values({
        trackedProductId: productId,
        price: newPrice.toString(),
        recordedAt: sql`now()`,
      });
    }

    if (priceChanged && newPrice < oldPrice) {
      const savings = oldPrice - newPrice;
      if (
        prod.targetPrice &&
        newPrice <= parseFloat(prod.targetPrice)
      ) {
        await app.db.insert(schema.alerts).values({
          trackedProductId: productId,
          type: 'target_reached',
          message: `${prod.name} hit your target price! Now MYR ${newPrice.toFixed(2)}`,
          oldPrice: oldPrice.toString(),
          newPrice: newPrice.toString(),
          savings: savings.toString(),
          isRead: false,
        });
      } else {
        await app.db.insert(schema.alerts).values({
          trackedProductId: productId,
          type: 'price_drop',
          message: `${prod.name} dropped from MYR ${oldPrice.toFixed(2)} to MYR ${newPrice.toFixed(2)}`,
          oldPrice: oldPrice.toString(),
          newPrice: newPrice.toString(),
          savings: savings.toString(),
          isRead: false,
        });
      }
    }

    if (stockChanged && newInStock && !oldInStock) {
      await app.db.insert(schema.alerts).values({
        trackedProductId: productId,
        type: 'restock',
        message: `${prod.name} is back in stock!`,
        oldPrice: null,
        newPrice: null,
        savings: null,
        isRead: false,
      });
    }
  } else {
    await app.db
      .update(schema.trackedProducts)
      .set({ lastCheckedAt: sql`now()` })
      .where(eq(schema.trackedProducts.id, productId));
  }

  return { priceChanged, newPrice };
}

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/tracked-products - List all tracked products
  fastify.get('/api/tracked-products', {
    schema: {
      description: 'List all tracked products with price changes and popularity metrics',
      tags: ['tracked-products'],
      response: {
        200: {
          description: 'List of all tracked products',
          type: 'object',
          properties: {
            products: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  tracking_id: { type: 'string' },
                  name: { type: 'string' },
                  url: { type: 'string' },
                  platform: { type: 'string' },
                  imageUrl: { type: 'string' },
                  currentPrice: { type: 'string' },
                  originalPrice: { type: 'string' },
                  targetPrice: { type: 'string' },
                  currency: { type: 'string' },
                  inStock: { type: 'boolean' },
                  lastCheckedAt: { type: 'string', format: 'date-time' },
                  createdAt: { type: 'string', format: 'date-time' },
                  description: { type: ['string', 'null'] },
                  brand: { type: ['string', 'null'] },
                  category: { type: ['string', 'null'] },
                  price_change: { type: 'number' },
                  price_change_pct: { type: 'number' },
                  view_count: { type: 'integer' },
                  alert_count: { type: 'integer' },
                  fetchErrorCount: { type: 'integer' },
                  lastFetchError: { type: ['string', 'null'] },
                },
              },
            },
          },
        },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    app.logger.info('Listing all tracked products');
    try {
      // Run price check before listing
      await runPriceCheck(app);

      const results = (await app.db.execute(sql`
        SELECT
          tp.id,
          tp.tracking_id,
          tp.name,
          tp.url,
          tp.platform,
          tp.image_url,
          tp.current_price,
          tp.original_price,
          tp.target_price,
          tp.currency,
          tp.in_stock,
          tp.last_checked_at,
          tp.created_at,
          tp.fetch_error_count,
          tp.last_fetch_error,
          tp.description,
          tp.brand,
          tp.category,
          COALESCE(v.view_count, 0) AS view_count,
          COALESCE(a.alert_count, 0) AS alert_count
        FROM tracked_products tp
        LEFT JOIN (
          SELECT tracked_product_id, COUNT(*) AS view_count
          FROM product_views
          WHERE viewed_at > now() - interval '7 days'
          GROUP BY tracked_product_id
        ) v ON v.tracked_product_id = tp.id
        LEFT JOIN (
          SELECT tracked_product_id, COUNT(*) AS alert_count
          FROM alerts
          WHERE created_at > now() - interval '7 days'
          GROUP BY tracked_product_id
        ) a ON a.tracked_product_id = tp.id
        ORDER BY tp.created_at DESC
      `) as any[]) || [];

      const productsWithMetrics = results.map((row: any) => {
        const current = parseFloat(row.current_price);
        const original = parseFloat(row.original_price);
        const priceChange = current - original;
        const priceChangePct = (priceChange / original) * 100;

        return {
          id: row.id,
          tracking_id: row.tracking_id,
          name: row.name,
          url: row.url,
          platform: row.platform,
          imageUrl: row.image_url,
          currentPrice: row.current_price,
          originalPrice: row.original_price,
          targetPrice: row.target_price,
          currency: row.currency,
          inStock: row.in_stock,
          lastCheckedAt: row.last_checked_at,
          createdAt: row.created_at,
          description: row.description || null,
          brand: row.brand || null,
          category: row.category || null,
          price_change: parseFloat(priceChange.toFixed(2)),
          price_change_pct: parseFloat(priceChangePct.toFixed(2)),
          view_count: parseInt(row.view_count),
          alert_count: parseInt(row.alert_count),
          fetchErrorCount: row.fetch_error_count,
          lastFetchError: row.last_fetch_error,
        };
      });

      app.logger.info(
        { count: productsWithMetrics.length },
        'Products listed successfully'
      );
      return { products: productsWithMetrics };
    } catch (error) {
      app.logger.error({ err: error }, 'Failed to list tracked products');
      throw error;
    }
  });

  // POST /api/tracked-products - Add a new product
  fastify.post<{
    Body: {
      name: string;
      url?: string;
      platform: 'shopee' | 'lazada' | 'tokopedia' | 'tiktok_shop' | 'manual';
      imageUrl?: string;
      currentPrice: number;
      targetPrice?: number;
      currency?: string;
    };
  }>(
    '/api/tracked-products',
    {
      schema: {
        description: 'Create a new tracked product',
        tags: ['tracked-products'],
        body: {
          type: 'object',
          required: ['name', 'platform', 'currentPrice'],
          properties: {
            name: { type: 'string' },
            url: { type: 'string' },
            platform: {
              type: 'string',
              enum: ['shopee', 'lazada', 'tokopedia', 'tiktok_shop', 'manual'],
            },
            imageUrl: { type: 'string' },
            currentPrice: { type: 'number' },
            targetPrice: { type: 'number' },
            currency: { type: 'string' },
          },
        },
        response: {
          201: {
            description: 'Product created successfully',
            type: 'object',
            properties: {
              id: { type: 'string' },
              name: { type: 'string' },
              url: { type: 'string' },
              platform: { type: 'string' },
              imageUrl: { type: 'string' },
              currentPrice: { type: 'string' },
              originalPrice: { type: 'string' },
              targetPrice: { type: 'string' },
              currency: { type: 'string' },
              inStock: { type: 'boolean' },
              lastCheckedAt: { type: 'string', format: 'date-time' },
              createdAt: { type: 'string', format: 'date-time' },
              price_change: { type: 'number' },
              price_change_pct: { type: 'number' },
              fetchErrorCount: { type: 'integer' },
              lastFetchError: { type: ['string', 'null'] },
            },
          },
          400: {
            description: 'Invalid request',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Body: {
          name: string;
          url?: string;
          platform: 'shopee' | 'lazada' | 'tokopedia' | 'tiktok_shop' | 'manual';
          imageUrl?: string;
          currentPrice: number;
          targetPrice?: number;
          currency?: string;
        };
      }>,
      reply: FastifyReply
    ) => {
      const { name, url, platform, imageUrl, currentPrice, targetPrice, currency } =
        request.body;

      app.logger.info(
        { name, platform, currentPrice, url },
        'Creating tracked product'
      );

      try {
        // Check for duplicate URL if provided
        if (url && url.trim()) {
          const existing = await app.db
            .select()
            .from(schema.trackedProducts)
            .where(eq(schema.trackedProducts.url, url.trim()));

          if (existing.length > 0) {
            app.logger.info(
              { productId: existing[0].id, url },
              'Product with this URL already exists'
            );
            reply.status(200);
            const product = existing[0];
            const priceChange = parseFloat(product.currentPrice) - parseFloat(product.originalPrice);
            const priceChangePct = (priceChange / parseFloat(product.originalPrice)) * 100;
            return {
              ...product,
              price_change: priceChange,
              price_change_pct: priceChangePct,
            };
          }
        }

        const trackingId = await getNextTrackingId(app);

        const [product] = await app.db
          .insert(schema.trackedProducts)
          .values({
            trackingId,
            name,
            url: url && url.trim() ? url.trim() : null,
            platform,
            imageUrl: imageUrl || null,
            currentPrice: currentPrice.toString(),
            originalPrice: currentPrice.toString(),
            targetPrice: targetPrice ? targetPrice.toString() : null,
            currency: currency || 'MYR',
            lastCheckedAt: sql`now()`,
            checkIntervalMinutes: 60,
            fetchErrorCount: 0,
            lastFetchError: null,
            lastUpdatedAt: sql`now()`,
          })
          .returning();

        // Generate price history
        const priceHistory = generatePriceHistory(currentPrice);
        const now = new Date();

        for (let i = 0; i < priceHistory.length; i++) {
          const { price, daysAgo } = priceHistory[i];
          const recordedAt = new Date(now);
          recordedAt.setDate(recordedAt.getDate() - daysAgo);

          await app.db.insert(schema.priceHistory).values({
            trackedProductId: product.id,
            price: price.toString(),
            recordedAt,
          });
        }

        const priceChange = 0;
        const priceChangePct = 0;

        const result = {
          ...product,
          price_change: priceChange,
          price_change_pct: priceChangePct,
        };

        app.logger.info({ productId: product.id }, 'Product created successfully');
        reply.status(201);
        return result;
      } catch (error) {
        app.logger.error(
          { err: error, name, platform, currentPrice },
          'Failed to create tracked product'
        );
        throw error;
      }
    }
  );

  // DELETE /api/tracked-products/:id - Delete a product
  fastify.delete<{
    Params: { id: string };
  }>(
    '/api/tracked-products/:id',
    {
      schema: {
        description: 'Delete a tracked product',
        tags: ['tracked-products'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        response: {
          200: {
            description: 'Product deleted successfully',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { id } = request.params as { id: string };

      app.logger.info({ productId: id }, 'Deleting tracked product');

      try {
        // Check if product exists
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        if (product.length === 0) {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Not found' });
        }

        // Delete the product (cascade will handle price_history and alerts)
        await app.db
          .delete(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        app.logger.info({ productId: id }, 'Product deleted successfully');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, productId: id }, 'Failed to delete product');
        throw error;
      }
    }
  );

  // GET /api/tracked-products/:id/history - Get price history for a product
  fastify.get<{
    Params: { id: string };
  }>(
    '/api/tracked-products/:id/history',
    {
      schema: {
        description: 'Get price history for a tracked product',
        tags: ['tracked-products'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        response: {
          200: {
            description: 'Price history for the product',
            type: 'object',
            properties: {
              history: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    price: { type: 'string' },
                    recordedAt: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { id } = request.params as { id: string };

      app.logger.info({ productId: id }, 'Getting price history');

      try {
        // Check if product exists
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        if (product.length === 0) {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Not found' });
        }

        // Get price history
        const history = await app.db
          .select({
            id: schema.priceHistory.id,
            price: schema.priceHistory.price,
            recordedAt: schema.priceHistory.recordedAt,
          })
          .from(schema.priceHistory)
          .where(eq(schema.priceHistory.trackedProductId, id))
          .orderBy(asc(schema.priceHistory.recordedAt));

        app.logger.info(
          { productId: id, count: history.length },
          'Price history retrieved successfully'
        );
        return { history };
      } catch (error) {
        app.logger.error(
          { err: error, productId: id },
          'Failed to get price history'
        );
        throw error;
      }
    }
  );

  // PATCH /api/tracked-products/:id - Update a tracked product
  fastify.patch<{
    Params: { id: string };
    Body: {
      target_price?: number | null;
      in_stock?: boolean;
    };
  }>(
    '/api/tracked-products/:id',
    {
      schema: {
        description: 'Update a tracked product (partial update)',
        tags: ['tracked-products'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        body: {
          type: 'object',
          properties: {
            target_price: { type: ['number', 'null'] },
            in_stock: { type: 'boolean' },
          },
        },
        response: {
          200: {
            description: 'Product updated successfully',
            type: 'object',
            properties: {
              id: { type: 'string' },
              name: { type: 'string' },
              url: { type: 'string' },
              platform: { type: 'string' },
              imageUrl: { type: 'string' },
              currentPrice: { type: 'string' },
              originalPrice: { type: 'string' },
              targetPrice: { type: 'string' },
              currency: { type: 'string' },
              inStock: { type: 'boolean' },
              lastCheckedAt: { type: 'string', format: 'date-time' },
              createdAt: { type: 'string', format: 'date-time' },
              price_change: { type: 'number' },
              price_change_pct: { type: 'number' },
              fetchErrorCount: { type: 'integer' },
              lastFetchError: { type: ['string', 'null'] },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (
      request: FastifyRequest<{
        Params: { id: string };
        Body: {
          target_price?: number | null;
          in_stock?: boolean;
        };
      }>,
      reply: FastifyReply
    ) => {
      const { id } = request.params;
      const { target_price, in_stock } = request.body;

      app.logger.info(
        { productId: id, targetPrice: target_price, inStock: in_stock },
        'Updating tracked product'
      );

      try {
        // Check if product exists
        const existingProduct = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        if (existingProduct.length === 0) {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Not found' });
        }

        // Build update object with only provided fields
        const updateData: Record<string, any> = {};

        if (target_price !== undefined) {
          updateData.targetPrice = target_price === null ? null : target_price.toString();
        }
        if (in_stock !== undefined) {
          updateData.inStock = in_stock;
        }

        // If no fields to update, return the existing product
        if (Object.keys(updateData).length === 0) {
          const product = existingProduct[0];
          const current = parseFloat(product.currentPrice);
          const original = parseFloat(product.originalPrice);
          const priceChange = current - original;
          const priceChangePct = (priceChange / original) * 100;

          return {
            ...product,
            price_change: priceChange,
            price_change_pct: parseFloat(priceChangePct.toFixed(2)),
          };
        }

        // Update the product
        const [updatedProduct] = await app.db
          .update(schema.trackedProducts)
          .set(updateData)
          .where(eq(schema.trackedProducts.id, id))
          .returning();

        // Calculate computed fields
        const current = parseFloat(updatedProduct.currentPrice);
        const original = parseFloat(updatedProduct.originalPrice);
        const priceChange = current - original;
        const priceChangePct = (priceChange / original) * 100;

        const result = {
          ...updatedProduct,
          price_change: priceChange,
          price_change_pct: parseFloat(priceChangePct.toFixed(2)),
        };

        app.logger.info(
          { productId: id, updatedFields: Object.keys(updateData) },
          'Product updated successfully'
        );
        return result;
      } catch (error) {
        app.logger.error(
          { err: error, productId: id },
          'Failed to update product'
        );
        throw error;
      }
    }
  );

  // POST /api/tracked-products/:id/check - Check price for a single product
  fastify.post<{
    Params: { id: string };
  }>(
    '/api/tracked-products/:id/check',
    {
      schema: {
        description: 'Check price for a single tracked product',
        tags: ['tracked-products'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        response: {
          200: {
            description: 'Price check completed',
            type: 'object',
            properties: {
              product: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  name: { type: 'string' },
                  platform: { type: 'string' },
                  currentPrice: { type: 'string' },
                  originalPrice: { type: 'string' },
                  targetPrice: { type: 'string' },
                  currency: { type: 'string' },
                  inStock: { type: 'boolean' },
                  lastCheckedAt: { type: 'string', format: 'date-time' },
                  createdAt: { type: 'string', format: 'date-time' },
                  fetchErrorCount: { type: 'integer' },
                  lastFetchError: { type: ['string', 'null'] },
                },
              },
              price_changed: { type: 'boolean' },
              new_price: { type: 'number' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { id } = request.params as { id: string };

      app.logger.info({ productId: id }, 'Checking price for product');

      try {
        const result = await performPriceCheck(app, id);

        const updatedProduct = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        if (updatedProduct.length === 0) {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Not found' });
        }

        app.logger.info(
          { productId: id, priceChanged: result.priceChanged },
          'Price check completed'
        );

        return {
          product: updatedProduct[0],
          price_changed: result.priceChanged,
          new_price: result.newPrice,
        };
      } catch (error) {
        if ((error as Error).message === 'Product not found') {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Not found' });
        }
        app.logger.error({ err: error, productId: id }, 'Failed to check price');
        throw error;
      }
    }
  );

  // POST /api/tracked-products/:id/view - Record a product view
  fastify.post<{
    Params: { id: string };
  }>(
    '/api/tracked-products/:id/view',
    {
      schema: {
        description: 'Record a product view',
        tags: ['tracked-products'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        response: {
          200: {
            description: 'Product view recorded successfully',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
            },
          },
          404: {
            description: 'Product not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { id } = request.params as { id: string };

      app.logger.info({ productId: id }, 'Recording product view');

      try {
        // Check if product exists
        const product = await app.db
          .select()
          .from(schema.trackedProducts)
          .where(eq(schema.trackedProducts.id, id));

        if (product.length === 0) {
          app.logger.warn({ productId: id }, 'Product not found');
          return reply.status(404).send({ error: 'Product not found' });
        }

        // Insert product view
        await app.db.insert(schema.productViews).values({
          trackedProductId: id,
        });

        app.logger.info({ productId: id }, 'Product view recorded successfully');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, productId: id }, 'Failed to record product view');
        throw error;
      }
    }
  );
}
