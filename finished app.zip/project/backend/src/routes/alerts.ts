import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc, count } from 'drizzle-orm';
import * as schema from '../db/schema/schema.js';
import type { App } from '../index.js';

export function register(app: App, fastify: FastifyInstance) {
  // GET /api/alerts - List all alerts
  fastify.get(
    '/api/alerts',
    {
      schema: {
        description: 'List all alerts with unread count',
        tags: ['alerts'],
        response: {
          200: {
            description: 'List of all alerts',
            type: 'object',
            properties: {
              alerts: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    id: { type: 'string' },
                    trackedProductId: { type: 'string' },
                    type: { type: 'string' },
                    message: { type: 'string' },
                    oldPrice: { type: 'string' },
                    newPrice: { type: 'string' },
                    savings: { type: 'string' },
                    isRead: { type: 'boolean' },
                    createdAt: { type: 'string', format: 'date-time' },
                    productName: { type: 'string' },
                  },
                },
              },
              unread_count: { type: 'integer' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      app.logger.info('Listing all alerts');
      try {
        const alerts = await app.db
          .select({
            id: schema.alerts.id,
            trackedProductId: schema.alerts.trackedProductId,
            type: schema.alerts.type,
            message: schema.alerts.message,
            oldPrice: schema.alerts.oldPrice,
            newPrice: schema.alerts.newPrice,
            savings: schema.alerts.savings,
            isRead: schema.alerts.isRead,
            createdAt: schema.alerts.createdAt,
            productName: schema.trackedProducts.name,
          })
          .from(schema.alerts)
          .leftJoin(
            schema.trackedProducts,
            eq(schema.alerts.trackedProductId, schema.trackedProducts.id)
          )
          .orderBy(desc(schema.alerts.createdAt));

        const unreadCountResult = await app.db
          .select({ value: count() })
          .from(schema.alerts)
          .where(eq(schema.alerts.isRead, false));

        const unreadCount = unreadCountResult[0]?.value || 0;

        app.logger.info(
          { count: alerts.length, unreadCount },
          'Alerts listed successfully'
        );
        return { alerts, unread_count: unreadCount };
      } catch (error) {
        app.logger.error({ err: error }, 'Failed to list alerts');
        throw error;
      }
    }
  );

  // POST /api/alerts/:id/read - Mark an alert as read
  fastify.post<{
    Params: { id: string };
  }>(
    '/api/alerts/:id/read',
    {
      schema: {
        description: 'Mark an alert as read',
        tags: ['alerts'],
        params: {
          type: 'object',
          required: ['id'],
          properties: {
            id: { type: 'string', format: 'uuid' },
          },
        },
        response: {
          200: {
            description: 'Alert marked as read',
            type: 'object',
            properties: {
              success: { type: 'boolean' },
            },
          },
          404: {
            description: 'Alert not found',
            type: 'object',
            properties: {
              error: { type: 'string' },
            },
          },
        },
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const { id } = request.params as { id: string };

      app.logger.info({ alertId: id }, 'Marking alert as read');

      try {
        // Check if alert exists
        const alert = await app.db
          .select()
          .from(schema.alerts)
          .where(eq(schema.alerts.id, id));

        if (alert.length === 0) {
          app.logger.warn({ alertId: id }, 'Alert not found');
          return reply.status(404).send({ error: 'Not found' });
        }

        // Update the alert
        await app.db
          .update(schema.alerts)
          .set({ isRead: true })
          .where(eq(schema.alerts.id, id));

        app.logger.info({ alertId: id }, 'Alert marked as read successfully');
        return { success: true };
      } catch (error) {
        app.logger.error({ err: error, alertId: id }, 'Failed to mark alert as read');
        throw error;
      }
    }
  );
}
