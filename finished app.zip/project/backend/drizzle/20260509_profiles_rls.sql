-- ============================================================
-- Migration: profiles table with Row Level Security
-- Compatible with: Supabase (PostgreSQL + auth.users)
-- ============================================================

-- ------------------------------------------------------------
-- 1. Table
-- ------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid        primary key references auth.users (id) on delete cascade,
  username    text        not null unique,
  avatar_url  text,
  bio         text,
  created_at  timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 2. Indexes
-- ------------------------------------------------------------
create unique index if not exists profiles_username_idx on public.profiles (username);

-- ------------------------------------------------------------
-- 3. Auto-create a profile row whenever a new user signs up
--    Keeps auth.users and public.profiles in sync automatically.
-- ------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username)
  values (
    new.id,
    -- Use the email prefix as a default username; users can update it later
    split_part(new.email, '@', 1)
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute procedure public.handle_new_user();

-- ------------------------------------------------------------
-- 4. Enable Row Level Security
-- ------------------------------------------------------------
alter table public.profiles enable row level security;

-- ------------------------------------------------------------
-- 5. RLS Policies
-- ------------------------------------------------------------

-- Policy: anyone authenticated (or anonymous) can read all profiles
create policy "Profiles are publicly readable"
  on public.profiles
  for select
  using (true);

-- Policy: a user may only update their own profile row
create policy "Users can update their own profile"
  on public.profiles
  for update
  using  (auth.uid() = id)   -- who can attempt the update
  with check (auth.uid() = id); -- row must still belong to them after update

-- Policy: only the trigger (security definer) inserts on signup;
--         lock direct inserts down to the owner as a safety net
create policy "Users can insert their own profile"
  on public.profiles
  for insert
  with check (auth.uid() = id);

-- Policy: users can delete only their own profile (optional; remove if unwanted)
create policy "Users can delete their own profile"
  on public.profiles
  for delete
  using (auth.uid() = id);
