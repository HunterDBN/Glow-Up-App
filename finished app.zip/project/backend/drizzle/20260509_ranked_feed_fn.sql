-- ============================================================
-- Migration: ranked_feed — scored, paginated feed function
-- score = (likes_count * 2) + (is_following * 5) - (age_in_hours * 0.5)
-- ============================================================

create or replace function public.ranked_feed(
  p_user_id   uuid,           -- signed-in user (null = anonymous)
  p_limit     int  default 8,
  p_offset    int  default 0
)
returns table (
  id          uuid,
  user_id     uuid,
  media_url   text,
  caption     text,
  created_at  timestamptz,
  username    text,
  avatar_url  text,
  like_count  bigint,
  user_liked  boolean,
  score       numeric
)
language sql
stable  -- no side effects; result can be cached within a transaction
security definer
set search_path = public
as $$
  select
    p.id,
    p.user_id,
    p.media_url,
    p.caption,
    p.created_at,

    -- Profile fields (flattened to avoid nested join in client)
    pr.username,
    pr.avatar_url,

    -- Like count for this post
    count(distinct l.id)::bigint                          as like_count,

    -- Whether the calling user has liked this post
    bool_or(l.user_id = p_user_id)                        as user_liked,

    -- Ranking score:
    --   each like adds 2 points
    --   being followed by the viewer adds 5 points
    --   each hour of age subtracts 0.5 points (floor at 0)
    greatest(
      (count(distinct l.id)::numeric * 2)
      + (case when f.follower_id is not null then 5 else 0 end)
      - (extract(epoch from (now() - p.created_at)) / 3600 * 0.5),
      0
    )                                                      as score

  from posts p

  -- Profile (always present — enforced by FK)
  join profiles pr on pr.id = p.user_id

  -- All likes for this post (left: posts with no likes still appear)
  left join likes l on l.post_id = p.id

  -- Is the post author followed by the requesting user?
  left join follows f
    on  f.follower_id  = p_user_id
    and f.following_id = p.user_id

  group by p.id, pr.username, pr.avatar_url, f.follower_id

  order by score desc, p.created_at desc  -- score first; recency breaks ties
  limit  p_limit
  offset p_offset;
$$;

-- Allow any authenticated (or anon) role to call this function
grant execute on function public.ranked_feed(uuid, int, int) to anon, authenticated;

-- ── Index support ────────────────────────────────────────────────────────────
-- These let Postgres do a fast index scan for the joins / group-by
-- (some may already exist from previous migrations)

create index if not exists likes_post_id_user_id_idx  on public.likes   (post_id, user_id);
create index if not exists follows_follower_following  on public.follows (follower_id, following_id);
create index if not exists posts_created_at_desc_idx  on public.posts   (created_at desc);
