-- ============================================================
-- Migration: posts table with Row Level Security
-- Compatible with: Supabase (PostgreSQL + auth.users)
-- ============================================================

-- ------------------------------------------------------------
-- 1. Table
-- ------------------------------------------------------------
create table if not exists public.posts (
  id          uuid        primary key default gen_random_uuid(),
  user_id     uuid        not null references public.profiles (id) on delete cascade,
  media_url   text,
  caption     text,
  created_at  timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 2. Indexes
-- ------------------------------------------------------------
create index if not exists posts_user_id_idx on public.posts (user_id);
create index if not exists posts_created_at_idx on public.posts (created_at desc);

-- ------------------------------------------------------------
-- 3. Enable Row Level Security
-- ------------------------------------------------------------
alter table public.posts enable row level security;

-- ------------------------------------------------------------
-- 4. RLS Policies
-- ------------------------------------------------------------

-- Policy: anyone (including anonymous) can read all posts
create policy "Posts are publicly readable"
  on public.posts
  for select
  using (true);

-- Policy: only authenticated users can insert posts
create policy "Authenticated users can insert posts"
  on public.posts
  for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Policy: users can only delete their own posts
create policy "Users can delete their own posts"
  on public.posts
  for delete
  using (auth.uid() = user_id);
