ALTER TABLE "tracked_products" ADD COLUMN "description" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "brand" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "category" text;