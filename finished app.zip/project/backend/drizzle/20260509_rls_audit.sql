-- ============================================================
-- Migration: RLS audit — hardened policies for all tables
--
-- Run this after all previous migrations. It drops every existing
-- policy and replaces it with an audited, best-practice version.
--
-- Tables covered:
--   profiles · posts · likes · follows · comments · notifications
--
-- Principles applied:
--   1. Deny by default — RLS is already ON; no residual open policies.
--   2. Separate policies per operation — one policy per (table, command)
--      pair is clearer and easier to audit than combined policies.
--   3. Lock user_id on INSERT and prevent it being changed on UPDATE
--      using both USING (pre-check) and WITH CHECK (post-check).
--   4. Authenticated-only writes — every mutating policy is scoped to
--      the `authenticated` role, blocking anon keys entirely.
--   5. Immutable ownership — user_id / follower_id / actor_id columns
--      cannot be changed after INSERT via UPDATE policies.
--   6. No UPDATE on likes/follows — these are append-only join tables;
--      UPDATE is not needed and is therefore not granted.
--   7. Notifications are INSERT-only via security definer triggers —
--      the client never writes directly; the policy enforces this.
-- ============================================================


-- ────────────────────────────────────────────────────────────
-- HELPER: a reusable function that returns true only for rows
-- whose user_id matches the calling user.  Inlined in each policy
-- for clarity, but defined here for documentation purposes.
-- ────────────────────────────────────────────────────────────
-- auth.uid() = <user_id column>   ← used inline in every policy below


-- ============================================================
-- 1. PROFILES
-- ============================================================

-- Drop all existing profile policies
drop policy if exists "Profiles are publicly readable"    on public.profiles;
drop policy if exists "Users can update their own profile" on public.profiles;
drop policy if exists "Users can insert their own profile" on public.profiles;
drop policy if exists "Users can delete their own profile" on public.profiles;

-- SELECT: all profiles are publicly readable (needed for @ mentions, search, etc.)
create policy "profiles:select:public"
  on public.profiles
  for select
  using (true);

-- INSERT: only the trigger (security definer) should create profiles.
-- This policy acts as a fallback — it lets a user create their own row
-- if the trigger somehow missed it, but prevents spoofing another user's id.
create policy "profiles:insert:own"
  on public.profiles
  for insert
  to authenticated
  with check (auth.uid() = id);

-- UPDATE: users may only update their own row.
-- WITH CHECK prevents changing `id` to impersonate another user.
-- Columns like `created_at` should be managed via DB defaults (not locked
-- here because Postgres column-level grants are outside RLS scope).
create policy "profiles:update:own"
  on public.profiles
  for update
  to authenticated
  using     (auth.uid() = id)   -- they must own the current row
  with check (auth.uid() = id); -- and still own it after the update

-- DELETE: users may delete their own profile.
-- Cascade on auth.users → profiles handles cleanup when auth account is removed.
-- Explicitly granting DELETE here allows self-service account deletion.
create policy "profiles:delete:own"
  on public.profiles
  for delete
  to authenticated
  using (auth.uid() = id);


-- ============================================================
-- 2. POSTS
-- ============================================================

drop policy if exists "Posts are publicly readable"        on public.posts;
drop policy if exists "Authenticated users can insert posts" on public.posts;
drop policy if exists "Users can delete their own posts"   on public.posts;

-- SELECT: all posts are publicly readable
create policy "posts:select:public"
  on public.posts
  for select
  using (true);

-- INSERT: authenticated users only; user_id must match caller.
-- Prevents a user from posting on behalf of someone else.
create policy "posts:insert:own"
  on public.posts
  for insert
  to authenticated
  with check (auth.uid() = user_id);

-- UPDATE: users may only edit their own post's caption.
-- USING ensures they can only target rows they own.
-- WITH CHECK ensures user_id cannot be changed (ownership transfer blocked).
create policy "posts:update:own"
  on public.posts
  for update
  to authenticated
  using     (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- DELETE: users may only delete their own posts.
create policy "posts:delete:own"
  on public.posts
  for delete
  to authenticated
  using (auth.uid() = user_id);


-- ============================================================
-- 3. LIKES
-- ============================================================

drop policy if exists "Likes are publicly readable"          on public.likes;
drop policy if exists "Authenticated users can insert likes" on public.likes;
drop policy if exists "Users can delete their own likes"     on public.likes;

-- SELECT: like counts are public
create policy "likes:select:public"
  on public.likes
  for select
  using (true);

-- INSERT: authenticated users only; user_id must match caller.
-- The DB-level UNIQUE(user_id, post_id) constraint handles idempotency.
create policy "likes:insert:own"
  on public.likes
  for insert
  to authenticated
  with check (auth.uid() = user_id);

-- UPDATE: intentionally omitted — likes are immutable after creation.
-- A user cannot change a like's user_id or post_id.

-- DELETE: users may only remove their own likes.
create policy "likes:delete:own"
  on public.likes
  for delete
  to authenticated
  using (auth.uid() = user_id);


-- ============================================================
-- 4. FOLLOWS
-- ============================================================

drop policy if exists "Follows are publicly readable"          on public.follows;
drop policy if exists "Authenticated users can insert follows" on public.follows;
drop policy if exists "Users can delete their own follows"     on public.follows;

-- SELECT: follow graph is public (needed for follower/following counts)
create policy "follows:select:public"
  on public.follows
  for select
  using (true);

-- INSERT: caller must be the follower.
-- Prevents user A from creating a follow on behalf of user B.
-- DB CHECK constraint prevents self-follows independently.
create policy "follows:insert:own"
  on public.follows
  for insert
  to authenticated
  with check (auth.uid() = follower_id);

-- UPDATE: intentionally omitted — follows are immutable after creation.
-- Changing follower_id or following_id after insert makes no semantic sense.

-- DELETE: only the follower may unfollow.
create policy "follows:delete:own"
  on public.follows
  for delete
  to authenticated
  using (auth.uid() = follower_id);


-- ============================================================
-- 5. COMMENTS
-- ============================================================

drop policy if exists "Comments are publicly readable"    on public.comments;
drop policy if exists "Authenticated users can comment"   on public.comments;
drop policy if exists "Users can delete their own comments" on public.comments;

-- SELECT: all comments on public posts are readable
create policy "comments:select:public"
  on public.comments
  for select
  using (true);

-- INSERT: authenticated users only; user_id must match caller.
-- The DB CHECK on body length (1–1000 chars) is enforced separately.
create policy "comments:insert:own"
  on public.comments
  for insert
  to authenticated
  with check (auth.uid() = user_id);

-- UPDATE: users may edit only their own comment body.
-- user_id and post_id are immutable after insert.
create policy "comments:update:own"
  on public.comments
  for update
  to authenticated
  using     (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- DELETE: users may only delete their own comments.
create policy "comments:delete:own"
  on public.comments
  for delete
  to authenticated
  using (auth.uid() = user_id);


-- ============================================================
-- 6. NOTIFICATIONS
-- ============================================================

drop policy if exists "Users can read their own notifications"   on public.notifications;
drop policy if exists "No direct client inserts"                 on public.notifications;
drop policy if exists "Users can update their own notifications" on public.notifications;
drop policy if exists "Users can delete their own notifications" on public.notifications;

-- SELECT: users can only read their own notifications.
-- actor_id is NOT exposed here — the joined profile fetch handles display.
create policy "notifications:select:own"
  on public.notifications
  for select
  to authenticated
  using (auth.uid() = user_id);

-- INSERT: blocked for all roles.
-- All notifications are created exclusively by security definer trigger
-- functions (notify_on_like, notify_on_follow, notify_on_comment).
-- A client that tries to insert directly will receive a policy violation error.
create policy "notifications:insert:deny_all"
  on public.notifications
  for insert
  with check (false);

-- UPDATE: users may mark their own notifications as read (read = true).
-- They cannot change user_id, actor_id, type, or reference_id.
-- WITH CHECK mirrors USING to block ownership transfer.
create policy "notifications:update:own"
  on public.notifications
  for update
  to authenticated
  using     (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- DELETE: users may dismiss (delete) their own notifications.
create policy "notifications:delete:own"
  on public.notifications
  for delete
  to authenticated
  using (auth.uid() = user_id);


-- ============================================================
-- 7. STORAGE — posts bucket
-- ============================================================
-- Supabase Storage uses its own policy system (storage.objects),
-- separate from table RLS. These policies lock down the posts bucket.

-- Allow public read access to all files in the posts bucket
insert into storage.buckets (id, name, public)
values ('posts', 'posts', true)
on conflict (id) do update set public = true;

-- Authenticated users can upload to their own folder (user_id/filename)
drop policy if exists "posts bucket: authenticated upload" on storage.objects;
create policy "posts bucket: authenticated upload"
  on storage.objects
  for insert
  to authenticated
  with check (
    bucket_id = 'posts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Users can update (replace) only their own files
drop policy if exists "posts bucket: owner update" on storage.objects;
create policy "posts bucket: owner update"
  on storage.objects
  for update
  to authenticated
  using (
    bucket_id = 'posts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Users can delete only their own files
drop policy if exists "posts bucket: owner delete" on storage.objects;
create policy "posts bucket: owner delete"
  on storage.objects
  for delete
  to authenticated
  using (
    bucket_id = 'posts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Public read for all files (bucket is public, but explicit policy is belt-and-suspenders)
drop policy if exists "posts bucket: public read" on storage.objects;
create policy "posts bucket: public read"
  on storage.objects
  for select
  using (bucket_id = 'posts');


-- ============================================================
-- 8. SECURITY AUDIT ASSERTIONS
--    These queries verify the policies are installed correctly.
--    Run them manually after applying this migration to confirm.
-- ============================================================

-- Expected: 4 policies on profiles, 4 on posts, 3 on likes, 3 on follows,
--           4 on comments, 4 on notifications
--
-- select tablename, policyname, cmd, roles
-- from pg_policies
-- where schemaname = 'public'
--   and tablename in ('profiles','posts','likes','follows','comments','notifications')
-- order by tablename, cmd;
--
-- Expected: no anon writes on any table (all mutating policies use `to authenticated`)
--
-- select tablename, policyname, roles
-- from pg_policies
-- where schemaname = 'public'
--   and cmd != 'SELECT'
--   and (roles = '{public}' or roles = '{}' or roles is null)
-- order by tablename;
-- (should return 0 rows — only notifications:insert:deny_all is an exception,
--  and it uses `with check (false)` which blocks everyone including authenticated)
