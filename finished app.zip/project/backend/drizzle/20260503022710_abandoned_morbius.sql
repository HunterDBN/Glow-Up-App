ALTER TYPE "public"."platform" ADD VALUE 'other';--> statement-breakpoint
ALTER TABLE "price_history" ADD COLUMN "note" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "tracking_id" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "previous_price" numeric(10, 2);--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "store_name" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "notes" text;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "last_updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
-- Backfill tracking_id for existing rows using CTE (window functions not allowed in UPDATE)
WITH numbered_rows AS (
  SELECT id, 'PW-' || LPAD(ROW_NUMBER() OVER (ORDER BY "created_at")::text, 6, '0') AS new_tracking_id
  FROM "tracked_products"
  WHERE "tracking_id" IS NULL
)
UPDATE "tracked_products"
SET "tracking_id" = numbered_rows.new_tracking_id
FROM numbered_rows
WHERE "tracked_products".id = numbered_rows.id;--> statement-breakpoint
-- Now make tracking_id NOT NULL and add unique constraint
ALTER TABLE "tracked_products" ALTER COLUMN "tracking_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD CONSTRAINT "tracked_products_tracking_id_unique" UNIQUE("tracking_id");