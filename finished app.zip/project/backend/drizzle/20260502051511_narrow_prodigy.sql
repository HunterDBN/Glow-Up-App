CREATE TYPE "public"."alert_type" AS ENUM('price_drop', 'restock', 'target_reached');--> statement-breakpoint
CREATE TYPE "public"."platform" AS ENUM('shopee', 'lazada', 'tokopedia', 'tiktok_shop', 'manual');--> statement-breakpoint
CREATE TABLE "alerts" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tracked_product_id" text NOT NULL,
	"type" "alert_type" NOT NULL,
	"message" text NOT NULL,
	"old_price" numeric(10, 2),
	"new_price" numeric(10, 2),
	"savings" numeric(10, 2),
	"is_read" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "price_history" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tracked_product_id" text NOT NULL,
	"price" numeric(10, 2) NOT NULL,
	"recorded_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tracked_products" (
	"id" text PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"url" text,
	"platform" "platform" NOT NULL,
	"image_url" text,
	"current_price" numeric(10, 2) NOT NULL,
	"original_price" numeric(10, 2) NOT NULL,
	"target_price" numeric(10, 2),
	"currency" text DEFAULT 'MYR' NOT NULL,
	"in_stock" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "alerts" ADD CONSTRAINT "alerts_tracked_product_id_tracked_products_id_fk" FOREIGN KEY ("tracked_product_id") REFERENCES "public"."tracked_products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "price_history" ADD CONSTRAINT "price_history_tracked_product_id_tracked_products_id_fk" FOREIGN KEY ("tracked_product_id") REFERENCES "public"."tracked_products"("id") ON DELETE cascade ON UPDATE no action;