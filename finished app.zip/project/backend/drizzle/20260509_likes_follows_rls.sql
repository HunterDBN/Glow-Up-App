-- ============================================================
-- Migration: likes and follows tables with Row Level Security
-- Compatible with: Supabase (PostgreSQL + auth.users)
-- ============================================================

-- ------------------------------------------------------------
-- 1. likes table
-- ------------------------------------------------------------
create table if not exists public.likes (
  id          uuid        primary key default gen_random_uuid(),
  user_id     uuid        not null references public.profiles (id) on delete cascade,
  post_id     uuid        not null references public.posts (id) on delete cascade,
  created_at  timestamptz not null default now(),

  -- Prevent a user from liking the same post more than once
  constraint likes_user_post_unique unique (user_id, post_id)
);

create index if not exists likes_post_id_idx on public.likes (post_id);
create index if not exists likes_user_id_idx on public.likes (user_id);

-- ------------------------------------------------------------
-- 2. follows table
-- ------------------------------------------------------------
create table if not exists public.follows (
  id            uuid        primary key default gen_random_uuid(),
  follower_id   uuid        not null references public.profiles (id) on delete cascade,
  following_id  uuid        not null references public.profiles (id) on delete cascade,
  created_at    timestamptz not null default now(),

  -- Prevent duplicate follow relationships
  constraint follows_unique unique (follower_id, following_id),

  -- Prevent users from following themselves
  constraint follows_no_self_follow check (follower_id <> following_id)
);

create index if not exists follows_follower_id_idx  on public.follows (follower_id);
create index if not exists follows_following_id_idx on public.follows (following_id);

-- ------------------------------------------------------------
-- 3. Enable Row Level Security
-- ------------------------------------------------------------
alter table public.likes   enable row level security;
alter table public.follows enable row level security;

-- ------------------------------------------------------------
-- 4. RLS Policies — likes
-- ------------------------------------------------------------

-- Anyone can read likes (e.g. show like counts publicly)
create policy "Likes are publicly readable"
  on public.likes
  for select
  using (true);

-- Authenticated users can like a post, but only as themselves
create policy "Authenticated users can insert likes"
  on public.likes
  for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Users can only remove their own likes
create policy "Users can delete their own likes"
  on public.likes
  for delete
  using (auth.uid() = user_id);

-- ------------------------------------------------------------
-- 5. RLS Policies — follows
-- ------------------------------------------------------------

-- Anyone can read follow relationships (e.g. follower/following counts)
create policy "Follows are publicly readable"
  on public.follows
  for select
  using (true);

-- Authenticated users can follow others, but only as themselves
create policy "Authenticated users can insert follows"
  on public.follows
  for insert
  to authenticated
  with check (auth.uid() = follower_id);

-- Users can only unfollow (delete) relationships they created
create policy "Users can delete their own follows"
  on public.follows
  for delete
  using (auth.uid() = follower_id);
