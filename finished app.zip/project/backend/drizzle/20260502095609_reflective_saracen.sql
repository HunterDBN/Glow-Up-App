ALTER TABLE "tracked_products" ALTER COLUMN "last_checked_at" DROP DEFAULT;--> statement-breakpoint
ALTER TABLE "tracked_products" ALTER COLUMN "last_checked_at" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "tracked_products" ALTER COLUMN "check_interval_minutes" SET DEFAULT 60;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "fetch_error_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "tracked_products" ADD COLUMN "last_fetch_error" text;