-- ============================================================
-- Migration: notifications system
-- Triggers: likes, follows, comments (future-ready)
-- ============================================================

-- ------------------------------------------------------------
-- 1. Notifications table
-- ------------------------------------------------------------
create type if not exists public.notification_type
  as enum ('like', 'follow', 'comment');

create table if not exists public.notifications (
  id           uuid                      primary key default gen_random_uuid(),
  -- The user who receives this notification
  user_id      uuid                      not null references public.profiles (id) on delete cascade,
  -- The user who triggered the action (liker, follower, commenter)
  actor_id     uuid                      not null references public.profiles (id) on delete cascade,
  type         public.notification_type  not null,
  -- Generic reference: post_id for likes/comments, actor_id copy for follows
  reference_id uuid,
  read         boolean                   not null default false,
  created_at   timestamptz               not null default now(),

  -- Prevent duplicate notifications for the same action
  -- (e.g. user likes the same post twice — only one notification row)
  constraint notifications_unique unique (user_id, actor_id, type, reference_id)
);

create index if not exists notifications_user_id_created_idx
  on public.notifications (user_id, created_at desc);

create index if not exists notifications_unread_idx
  on public.notifications (user_id, read)
  where read = false;

-- ------------------------------------------------------------
-- 2. Enable RLS
-- ------------------------------------------------------------
alter table public.notifications enable row level security;

-- Users can only read their own notifications
create policy "Users can read their own notifications"
  on public.notifications for select
  using (auth.uid() = user_id);

-- System triggers insert notifications (security definer functions below)
-- Block direct inserts from the client
create policy "No direct client inserts"
  on public.notifications for insert
  with check (false);

-- Users can mark their own notifications as read
create policy "Users can update their own notifications"
  on public.notifications for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Users can delete their own notifications
create policy "Users can delete their own notifications"
  on public.notifications for delete
  using (auth.uid() = user_id);

-- ------------------------------------------------------------
-- 3. Trigger: notify on like
--    Fires after INSERT on likes
-- ------------------------------------------------------------
create or replace function public.notify_on_like()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author uuid;
begin
  -- Find who owns the post being liked
  select user_id into post_author from posts where id = new.post_id;

  -- Don't notify if the user likes their own post
  if post_author is null or post_author = new.user_id then
    return new;
  end if;

  insert into notifications (user_id, actor_id, type, reference_id)
  values (post_author, new.user_id, 'like', new.post_id)
  on conflict (user_id, actor_id, type, reference_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_like_created on public.likes;
create trigger on_like_created
  after insert on public.likes
  for each row execute procedure public.notify_on_like();

-- ------------------------------------------------------------
-- 4. Trigger: notify on follow
--    Fires after INSERT on follows
-- ------------------------------------------------------------
create or replace function public.notify_on_follow()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Don't notify on self-follow (shouldn't happen, but guard anyway)
  if new.follower_id = new.following_id then
    return new;
  end if;

  insert into notifications (user_id, actor_id, type, reference_id)
  values (new.following_id, new.follower_id, 'follow', new.follower_id)
  on conflict (user_id, actor_id, type, reference_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_follow_created on public.follows;
create trigger on_follow_created
  after insert on public.follows
  for each row execute procedure public.notify_on_follow();

-- ------------------------------------------------------------
-- 5. Helper RPC: mark all notifications read for a user
-- ------------------------------------------------------------
create or replace function public.mark_all_notifications_read(p_user_id uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update notifications
  set    read = true
  where  user_id = p_user_id
  and    read    = false;
$$;

grant execute on function public.mark_all_notifications_read(uuid) to authenticated;

-- ------------------------------------------------------------
-- 6. Helper RPC: unread notification count
-- ------------------------------------------------------------
create or replace function public.unread_notification_count(p_user_id uuid)
returns bigint
language sql
stable
security definer
set search_path = public
as $$
  select count(*) from notifications
  where user_id = p_user_id and read = false;
$$;

grant execute on function public.unread_notification_count(uuid) to authenticated;
