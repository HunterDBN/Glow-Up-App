-- ============================================================
-- Migration: comments system
-- ============================================================

-- ------------------------------------------------------------
-- 1. Table
-- ------------------------------------------------------------
create table if not exists public.comments (
  id         uuid        primary key default gen_random_uuid(),
  post_id    uuid        not null references public.posts    (id) on delete cascade,
  user_id    uuid        not null references public.profiles (id) on delete cascade,
  body       text        not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

-- Fast lookup: all comments for a post, newest-first
create index if not exists comments_post_id_created_idx
  on public.comments (post_id, created_at asc);

-- User's own comments (profile page, delete checks)
create index if not exists comments_user_id_idx
  on public.comments (user_id);

-- ------------------------------------------------------------
-- 2. Enable Row Level Security
-- ------------------------------------------------------------
alter table public.comments enable row level security;

-- Anyone can read comments on public posts
create policy "Comments are publicly readable"
  on public.comments for select
  using (true);

-- Authenticated users can insert their own comments
create policy "Authenticated users can comment"
  on public.comments for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Users can only delete their own comments
create policy "Users can delete their own comments"
  on public.comments for delete
  using (auth.uid() = user_id);

-- ------------------------------------------------------------
-- 3. Notification trigger: notify post author on new comment
-- ------------------------------------------------------------
create or replace function public.notify_on_comment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author uuid;
begin
  select user_id into post_author from posts where id = new.post_id;

  -- Skip if commenter is the post author
  if post_author is null or post_author = new.user_id then
    return new;
  end if;

  insert into notifications (user_id, actor_id, type, reference_id)
  values (post_author, new.user_id, 'comment', new.post_id)
  on conflict (user_id, actor_id, type, reference_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_comment_created on public.comments;
create trigger on_comment_created
  after insert on public.comments
  for each row execute procedure public.notify_on_comment();

-- ------------------------------------------------------------
-- 4. Helper: comment count per post (used in ranked_feed)
-- ------------------------------------------------------------
create or replace function public.post_comment_count(p_post_id uuid)
returns bigint
language sql
stable
security definer
set search_path = public
as $$
  select count(*) from comments where post_id = p_post_id;
$$;

grant execute on function public.post_comment_count(uuid) to anon, authenticated;
