import React, { memo } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  ScrollView,
  StatusBar,
} from 'react-native';
import Skeleton from './Skeleton';

// ─── Constants ────────────────────────────────────────────────────────────────

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
const COLUMN_COUNT = 3;
const GAP          = 2;
const CELL_SIZE    = (SCREEN_W - GAP * (COLUMN_COUNT - 1)) / COLUMN_COUNT;

// ─── FeedPostSkeleton — full-screen card with action rail overlay ─────────────

/**
 * Mimics a single post in the vertical feed.
 * Shown stacked during initial feed load.
 */
export const FeedPostSkeleton = memo(({ dark = true }: { dark?: boolean }) => (
  <View style={[feedStyles.card, { height: SCREEN_H }]}>
    {/* Full-bleed media area */}
    <Skeleton width="100%" height={SCREEN_H} borderRadius={0} dark={dark} style={feedStyles.media} />

    {/* Right-side action rail */}
    <View style={feedStyles.actions}>
      {/* Avatar circle */}
      <Skeleton width={48} height={48} borderRadius={24} dark={!dark} />

      {/* Like */}
      <View style={feedStyles.actionItem}>
        <Skeleton width={30} height={30} borderRadius={15} dark={!dark} />
        <Skeleton width={28} height={10} borderRadius={5} dark={!dark} />
      </View>

      {/* Comment */}
      <View style={feedStyles.actionItem}>
        <Skeleton width={30} height={30} borderRadius={15} dark={!dark} />
        <Skeleton width={28} height={10} borderRadius={5} dark={!dark} />
      </View>

      {/* Bookmark */}
      <View style={feedStyles.actionItem}>
        <Skeleton width={30} height={30} borderRadius={15} dark={!dark} />
        <Skeleton width={28} height={10} borderRadius={5} dark={!dark} />
      </View>
    </View>

    {/* Bottom meta — username + caption */}
    <View style={feedStyles.meta}>
      <Skeleton width={120} height={14} borderRadius={7} dark={!dark} />
      <Skeleton width={200} height={12} borderRadius={6} dark={!dark} style={{ marginTop: 8 }} />
      <Skeleton width={160} height={12} borderRadius={6} dark={!dark} style={{ marginTop: 4 }} />
    </View>
  </View>
));

// ─── FeedSkeleton — 3 stacked cards (simulates first scroll view) ─────────────

export const FeedSkeleton = memo(() => (
  <View style={{ flex: 1, backgroundColor: '#111' }}>
    <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
    <FeedPostSkeleton dark />
  </View>
));

// ─── ProfileHeaderSkeleton — avatar + stats + bio + button ───────────────────

export const ProfileHeaderSkeleton = memo(() => (
  <View style={profileStyles.header}>
    {/* Top bar */}
    <View style={profileStyles.topBar}>
      <Skeleton width={120} height={16} borderRadius={8} />
      <Skeleton width={24}  height={24} borderRadius={12} />
    </View>

    {/* Avatar + stats */}
    <View style={profileStyles.avatarRow}>
      {/* Circular avatar */}
      <Skeleton width={86} height={86} borderRadius={43} />

      {/* Three stat pills */}
      <View style={profileStyles.stats}>
        {[0, 1, 2].map(i => (
          <View key={i} style={profileStyles.statPill}>
            <Skeleton width={36} height={18} borderRadius={9} />
            <Skeleton width={52} height={11} borderRadius={5} style={{ marginTop: 4 }} />
          </View>
        ))}
      </View>
    </View>

    {/* Bio lines */}
    <View style={profileStyles.bio}>
      <Skeleton width="85%" height={13} borderRadius={6} />
      <Skeleton width="65%" height={13} borderRadius={6} style={{ marginTop: 6 }} />
    </View>

    {/* CTA button */}
    <Skeleton width="100%" height={38} borderRadius={8} style={profileStyles.btn} />

    {/* Tab divider */}
    <View style={profileStyles.tabRow}>
      <View style={profileStyles.tabActive}>
        <Skeleton width={20} height={20} borderRadius={4} />
      </View>
    </View>
  </View>
));

// ─── GridSkeleton — NxM grid of post thumbnails ───────────────────────────────

export const GridSkeleton = memo(({ rows = 4 }: { rows?: number }) => {
  const cells = Array.from({ length: rows * COLUMN_COUNT });
  return (
    <View style={gridStyles.grid}>
      {cells.map((_, i) => (
        <Skeleton
          key={i}
          width={CELL_SIZE}
          height={CELL_SIZE}
          borderRadius={0}
          style={gridStyles.cell}
        />
      ))}
    </View>
  );
});

// ─── ProfileSkeleton — full profile screen ────────────────────────────────────

export const ProfileSkeleton = memo(() => (
  <ScrollView
    style={profileStyles.screen}
    scrollEnabled={false}
    showsVerticalScrollIndicator={false}
  >
    <ProfileHeaderSkeleton />
    <GridSkeleton rows={4} />
  </ScrollView>
));

// ─── PostDetailSkeleton — single expanded post ────────────────────────────────

export const PostDetailSkeleton = memo(({ dark = false }: { dark?: boolean }) => (
  <View style={postStyles.container}>
    {/* Media */}
    <Skeleton width="100%" height={SCREEN_W} borderRadius={0} dark={dark} />

    {/* User row */}
    <View style={postStyles.userRow}>
      <Skeleton width={40} height={40} borderRadius={20} dark={dark} />
      <View style={{ flex: 1, gap: 6 }}>
        <Skeleton width={100} height={13} borderRadius={6} dark={dark} />
        <Skeleton width={60}  height={10} borderRadius={5} dark={dark} />
      </View>
      <Skeleton width={80} height={32} borderRadius={16} dark={dark} />
    </View>

    {/* Caption */}
    <View style={postStyles.captionBlock}>
      <Skeleton width="100%" height={13} borderRadius={6} dark={dark} />
      <Skeleton width="78%"  height={13} borderRadius={6} dark={dark} style={{ marginTop: 6 }} />
    </View>

    {/* Action row */}
    <View style={postStyles.actionRow}>
      {[64, 56, 56, 44].map((w, i) => (
        <Skeleton key={i} width={w} height={13} borderRadius={6} dark={dark} />
      ))}
    </View>
  </View>
));

// ─── Styles ───────────────────────────────────────────────────────────────────

const feedStyles = StyleSheet.create({
  card:  { width: SCREEN_W, overflow: 'hidden', backgroundColor: '#1A1A1A' },
  media: { opacity: 0.6 },

  actions: {
    position:  'absolute',
    right:     12,
    bottom:    100,
    alignItems: 'center',
    gap:        22,
  },
  actionItem: { alignItems: 'center', gap: 6 },

  meta: {
    position: 'absolute',
    left:     16,
    right:    80,
    bottom:   100,
  },
});

const profileStyles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: '#fff', paddingBottom: 4 },

  topBar: {
    flexDirection:  'row',
    alignItems:     'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical:   14,
  },

  avatarRow: {
    flexDirection:     'row',
    alignItems:        'center',
    paddingHorizontal: 16,
    gap:               20,
    marginBottom:      14,
  },
  stats: { flex: 1, flexDirection: 'row', justifyContent: 'space-around' },
  statPill: { alignItems: 'center' },

  bio: { paddingHorizontal: 16, gap: 0, marginBottom: 14 },
  btn: { marginHorizontal: 16, marginBottom: 14 },

  tabRow:   { borderTopWidth: 1, borderTopColor: '#F0F0F0', paddingVertical: 10, alignItems: 'center' },
  tabActive:{ alignItems: 'center' },
});

const gridStyles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: GAP },
  cell: { marginBottom: 0 },
});

const postStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },

  userRow: {
    flexDirection:  'row',
    alignItems:     'center',
    gap:            12,
    paddingHorizontal: 16,
    paddingVertical:   14,
  },

  captionBlock: {
    paddingHorizontal: 16,
    paddingBottom:     14,
    gap:               0,
  },

  actionRow: {
    flexDirection:  'row',
    paddingHorizontal: 16,
    paddingVertical:   14,
    gap:            20,
  },
});
