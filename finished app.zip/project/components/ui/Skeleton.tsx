import React, { useEffect, memo } from 'react';
import { StyleSheet, ViewStyle, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  interpolate,
  Easing,
} from 'react-native-reanimated';

// ─── Constants ────────────────────────────────────────────────────────────────

const SCREEN_W = Dimensions.get('window').width;

// How many ms for one shimmer sweep across the element
const SHIMMER_DURATION = 1100;

// Base skeleton colour — slightly warm grey so it doesn't clash with
// either a white or dark background
const BASE_COLOR    = '#E8E8E8';
const SHIMMER_COLOR = '#F5F5F5';

// Dark-mode equivalents
const BASE_DARK    = '#2A2A2A';
const SHIMMER_DARK = '#3A3A3A';

// ─── Types ────────────────────────────────────────────────────────────────────

interface SkeletonProps {
  width?:        number | string;
  height?:       number;
  borderRadius?: number;
  style?:        ViewStyle;
  dark?:         boolean;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

/**
 * Skeleton — a single animated shimmer block.
 *
 * The shimmer is a translucent overlay that slides left-to-right using
 * a Reanimated shared value driven entirely on the UI thread — zero JS
 * frame budget consumed during the animation.
 *
 * Usage:
 *   <Skeleton width={200} height={16} borderRadius={8} />
 *   <Skeleton width="100%" height={200} borderRadius={12} />
 */
const Skeleton = memo(({
  width        = '100%',
  height       = 16,
  borderRadius = 8,
  style,
  dark         = false,
}: SkeletonProps) => {
  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, { duration: SHIMMER_DURATION, easing: Easing.inOut(Easing.ease) }),
      -1,   // infinite
      false // do not reverse — one-directional sweep
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => {
    // translateX goes from -100% width to +100% width
    const translateX = interpolate(progress.value, [0, 1], [-SCREEN_W, SCREEN_W]);
    return { transform: [{ translateX }] };
  });

  const baseColor    = dark ? BASE_DARK    : BASE_COLOR;
  const shimmerColor = dark ? SHIMMER_DARK : SHIMMER_COLOR;

  return (
    <Animated.View
      style={[
        styles.base,
        { width, height, borderRadius, backgroundColor: baseColor },
        style,
      ]}
    >
      {/* Shimmer overlay — slides across the base */}
      <Animated.View
        style={[
          StyleSheet.absoluteFill,
          styles.shimmer,
          { backgroundColor: shimmerColor },
          animatedStyle,
        ]}
      />
    </Animated.View>
  );
});

export default Skeleton;

const styles = StyleSheet.create({
  base: {
    overflow: 'hidden',
  },
  shimmer: {
    // Semi-transparent so the base colour bleeds through on the edges,
    // creating a soft gradient feel without needing LinearGradient
    opacity: 0.6,
    width:   '40%', // shimmer band is 40% the width of the element
  },
});
